define(
//begin v1.x content
{
	"dateFormat-long": "dd 'de' MMMM 'de' y G",
	"dateFormat-full": "EEEE dd 'de' MMMM 'de' y G"
}
//end v1.x content
);