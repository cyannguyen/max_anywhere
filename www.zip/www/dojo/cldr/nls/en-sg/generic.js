define(
//begin v1.x content
{
	"timeFormat-full": "h:mm:ss a zzzz",
	"timeFormat-medium": "h:mm:ss a",
	"dateFormat-medium": "d MMM, y G",
	"dateFormat-full": "EEEE, d MMMM, y G",
	"timeFormat-long": "h:mm:ss a z",
	"timeFormat-short": "h:mm a",
	"dateFormat-short": "d/M/yy GGGGG",
	"dateFormat-long": "d MMMM, y G",
	"dateFormatItem-MMMEd": "E, d MMM"
}
//end v1.x content
);