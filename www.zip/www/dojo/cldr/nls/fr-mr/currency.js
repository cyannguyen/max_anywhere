define(
//begin v1.x content
{
	"MRO_symbol": "UM"
}
//end v1.x content
);