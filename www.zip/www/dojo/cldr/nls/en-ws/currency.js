define(
//begin v1.x content
{
	"WST_symbol": "WS$",
	"USD_symbol": "US$"
}
//end v1.x content
);