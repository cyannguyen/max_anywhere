define(
//begin v1.x content
{
	"SYP_symbol": "LS"
}
//end v1.x content
);