define(
//begin v1.x content
{
	"USD_symbol": "US$"
}
//end v1.x content
);