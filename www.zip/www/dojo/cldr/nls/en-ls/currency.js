define(
//begin v1.x content
{
	"ZAR_symbol": "R",
	"USD_symbol": "US$"
}
//end v1.x content
);