define(
//begin v1.x content
{
	"SRD_symbol": "$"
}
//end v1.x content
);