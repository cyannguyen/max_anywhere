define(
//begin v1.x content
{
	"VEF_symbol": "Bs."
}
//end v1.x content
);