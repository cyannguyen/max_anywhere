define(
//begin v1.x content
{
	"PYG_symbol": "₲"
}
//end v1.x content
);