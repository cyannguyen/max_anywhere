define(
//begin v1.x content
{
	"HTG_symbol": "G"
}
//end v1.x content
);