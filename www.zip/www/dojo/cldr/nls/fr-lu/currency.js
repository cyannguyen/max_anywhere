define(
//begin v1.x content
{
	"FRF_symbol": "FRF",
	"LUF_symbol": "F"
}
//end v1.x content
);