define(
//begin v1.x content
{
	"dateFormatItem-yMMMEd": "E d MMM y",
	"dateFormatItem-Md": "d/M",
	"dateFormatItem-yMEd": "E, d/M/y",
	"dateFormatItem-MEd": "E, d/M",
	"dateFormat-medium": "d MMM y G",
	"dateFormatItem-yMd": "d/M/y",
	"dateFormat-full": "EEEE d MMMM y G",
	"dayPeriods-format-wide-am": "a.m.",
	"dateFormat-short": "dd/MM/y GGGGG",
	"dayPeriods-format-wide-pm": "p.m.",
	"dateFormat-long": "d MMMM y G"
}
//end v1.x content
);