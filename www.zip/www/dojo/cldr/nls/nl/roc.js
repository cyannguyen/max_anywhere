define(
//begin v1.x content
{
	"field-second": "Seconde",
	"field-year-relative+-1": "Vorig jaar",
	"field-week": "week",
	"field-month-relative+-1": "Vorige maand",
	"field-day-relative+-1": "Gisteren",
	"field-day-relative+-2": "Eergisteren",
	"field-year": "Jaar",
	"field-week-relative+0": "Deze week",
	"field-week-relative+1": "Volgende week",
	"field-minute": "Minuut",
	"field-week-relative+-1": "Vorige week",
	"field-day-relative+0": "Vandaag",
	"field-hour": "Uur",
	"field-day-relative+1": "Morgen",
	"field-day-relative+2": "Overmorgen",
	"field-day": "Dag",
	"field-month-relative+0": "Deze maand",
	"field-month-relative+1": "Volgende maand",
	"field-dayperiod": "AM/PM",
	"field-month": "Maand",
	"field-era": "Tijdperk",
	"field-year-relative+0": "Dit jaar",
	"field-year-relative+1": "Volgend jaar",
	"eraAbbr": [
		"Before R.O.C.",
		"Minguo"
	],
	"field-weekday": "Dag van de week",
	"field-zone": "Zone"
}
//end v1.x content
);