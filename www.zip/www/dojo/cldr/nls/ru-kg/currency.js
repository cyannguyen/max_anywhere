define(
//begin v1.x content
{
	"KGS_symbol": "сом"
}
//end v1.x content
);