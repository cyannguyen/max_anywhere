define(
//begin v1.x content
{
	"KYD_displayName": "开曼群岛元",
	"RUB_displayName": "俄罗斯卢布",
	"KZT_displayName": "哈萨克斯坦腾格",
	"HKD_symbol": "$",
	"XAG_displayName": "白银",
	"HNL_displayName": "洪都拉斯拉伦皮拉",
	"BAM_displayName": "波斯尼亚-黑塞哥维那可兑换马克",
	"FKP_displayName": "福克兰群岛镑",
	"NIO_displayName": "尼加拉瓜科多巴",
	"AWG_displayName": "阿鲁巴弗罗林",
	"UAH_displayName": "乌克兰赫夫纳"
}
//end v1.x content
);