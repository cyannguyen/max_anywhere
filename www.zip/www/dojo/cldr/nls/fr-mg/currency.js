define(
//begin v1.x content
{
	"MGA_symbol": "Ar"
}
//end v1.x content
);