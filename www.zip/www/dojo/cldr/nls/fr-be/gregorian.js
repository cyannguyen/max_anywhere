define(
//begin v1.x content
{
	"timeFormat-full": "H 'h' mm 'min' ss 's' zzzz",
	"dateFormat-short": "d/MM/yy"
}
//end v1.x content
);