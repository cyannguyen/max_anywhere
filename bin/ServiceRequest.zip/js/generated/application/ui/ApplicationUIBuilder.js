/* 
 * Licensed Materials - Property of IBM
 * "Restricted Materials of IBM"
 *
 * 5725-M39
 *
 * (C) COPYRIGHT IBM CORP. 2021 All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with
 * IBM Corp. 
 *
 */
 
//----------------------------------------------------------------//
// This is auto generated code. Do not modify it manually.
// Product and Version: IBM Maximo Anywhere Version 7.5
// Build: 2021-06-01 07:37:20
//----------------------------------------------------------------//
define(   "generated/application/ui/ApplicationUIBuilder", 
      [
         "dojo/_base/declare", 
         "dojo/promise/all", 
         "platform/ui/builder/_UIBuilderBase", 
         "dojo/_base/window", 
         "dojo/_base/array", 
         "dojo/io-query", 
         "platform/model/AdditionalDataManager", 
         "platform/model/AdditionalDataUIManager", 
         "platform/translation/MessageService", 
         "platform/ui/control/Application", 
         "platform/ui/control/UserInterface", 
         "platform/ui/control/Dialog", 
         "platform/ui/control/Container", 
         "platform/ui/control/Text", 
         "platform/ui/control/Button", 
         "platform/handlers/SSOHandler", 
         "platform/handlers/LoginHandler", 
         "platform/ui/control/View", 
         "platform/ui/control/Image", 
         "platform/handlers/_ApplicationHandlerBase", 
         "platform/ui/control/ProgressIndicator", 
         "platform/ui/control/Actions", 
         "platform/ui/control/Action", 
         "platform/handlers/WorkOfflineHandler", 
         "platform/ui/control/Link", 
         "application/handlers/SRDetailHandler", 
         "platform/ui/control/Group", 
         "platform/ui/control/GroupItem", 
         "platform/ui/control/Queries", 
         "platform/ui/control/Query", 
         "platform/ui/control/List", 
         "platform/ui/control/SortOptions", 
         "platform/ui/control/SortOption", 
         "platform/ui/control/SortAttribute", 
         "platform/ui/control/ListItemTemplate", 
         "platform/ui/control/ListText", 
         "platform/ui/control/Footer", 
         "platform/handlers/AttachmentHandler", 
         "application/handlers/SRAttachmentHandler", 
         "platform/ui/control/TextArea", 
         "platform/ui/control/CheckBox", 
         "application/handlers/WorkLogHandler", 
         "platform/ui/control/ErrorIndicator", 
         "platform/ui/control/LastUpdateText", 
         "platform/ui/control/Lookup", 
         "platform/ui/control/SearchAttributes", 
         "platform/ui/control/SearchAttribute", 
         "platform/ui/control/ReturnAttributes", 
         "platform/ui/control/ReturnAttribute", 
         "platform/handlers/PseudoOfflineModeHandler", 
         "platform/handlers/CreateQueryBaseHandler", 
         "platform/ui/control/ErrorActions", 
         "platform/handlers/LookupHandler", 
         "platform/handlers/PushNotificationDialogHandler", 
         "platform/ui/control/DateTimePicker", 
         "platform/handlers/SettingsHandler", 
         "platform/handlers/ChangePasswordHandler", 
         "platform/handlers/AdditionalDataDialogHandler", 
         "platform/ui/control/RadioButton", 
         "platform/logging/handler/LoggerReportHandler", 
         "platform/performance/handler/TimeTrackHandler", 
         "platform/handlers/DialogHandler", 
         "platform/ui/control/DurationPicker", 
         "platform/handlers/EsigHandler", 
         "platform/signature/handler/SignatureHandler"
      ],

function(declare, all, BuilderBase, window, array, ioQuery, AdditionalDataManager, AdditionalDataUIManager, MessageService, Application, UserInterface, Dialog, Container, Text, Button, SSOHandler, LoginHandler, View, Image, _ApplicationHandlerBase, ProgressIndicator, Actions, Action, WorkOfflineHandler, Link, SRDetailHandler, Group, GroupItem, Queries, Query, List, SortOptions, SortOption, SortAttribute, ListItemTemplate, ListText, Footer, AttachmentHandler, SRAttachmentHandler, TextArea, CheckBox, WorkLogHandler, ErrorIndicator, LastUpdateText, Lookup, SearchAttributes, SearchAttribute, ReturnAttributes, ReturnAttribute, PseudoOfflineModeHandler, CreateQueryBaseHandler, ErrorActions, LookupHandler, PushNotificationDialogHandler, DateTimePicker, SettingsHandler, ChangePasswordHandler, AdditionalDataDialogHandler, RadioButton, LoggerReportHandler, TimeTrackHandler, DialogHandler, DurationPicker, EsigHandler, SignatureHandler) {
      return declare("generated.application.ui.ApplicationUIBuilder", BuilderBase, {

         build : function() {
            console.log('Creating App');

            MessageService.init('artifact');


            var app001 = new Application({
               'logLevel' : 0,
               'xsi:noNamespaceSchemaLocation' : '..\/..\/..\/build\/app.xsd',
               'xmlns:xsi' : 'http:\/\/www.w3.org\/2001\/XMLSchema-instance',
               'id' : 'ServiceRequest',
               'version' : '201509021457',
               'requiredRole' : 'ANYWHERE_SERVICE_REQUEST',
            });
            app001.setFeatures({
            'update.artifact.timestamps' : false,
            'esig.enabled' : true,
            'gps.enabled' : true,
            'enableDataEncryption' : true,
            'barcode.enabled' : true,
            'attachments.enabled' : true,
            'globalization.use.mock' : false,
            'run.bvt.scripts' : false,
            'build.update.check.enabled' : true,
            'pushnotification.enabled' : false,
            'map.enabled' : false,

            });

            var ui001 = new UserInterface({
               'artifactId' : 'ui',
               'id' : 'aw27ff46b0',
            });
            app001.addChild( ui001 );
            AdditionalDataManager._setAdditionalDataUIManager(new AdditionalDataUIManager(ui001));

            var dialog001 = new Dialog({
               'id' : 'Platform.SSOError',
               'label' : MessageService.createStaticMessage('SSO Login Error'),
            });
            ui001.addChild( dialog001 );


            var container001 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'resource' : 'SSODialogResource',
               'artifactId' : 'Platform.SSOError_SSODialogResource_container_0',
               'id' : 'aw8b213d94',
            });
            dialog001.addChild( container001 );


            var text001 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.SSOError_SSODialogResource_container_0_ErrorusingSSOLogi',
               'id' : 'awa51c0f06',
               'value' : MessageService.createStaticMessage('Error using SSO Login'),
            });
            container001.addChild( text001 );


            var text002 = new Text({
               'resourceAttribute' : 'errorMsg',
               'editable' : false,
               'artifactId' : 'Platform.SSOError_SSODialogResource_container_0_errorMsg',
               'id' : 'awf2a9265',
            });
            container001.addChild( text002 );


            var container002 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.SSOError_container_0',
               'id' : 'awbf273d01',
            });
            dialog001.addChild( container002 );


            var button001 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'Platform.SSOError_Retry_button',
               'id' : 'aw7e9aa474',
               'label' : MessageService.createStaticMessage('Retry'),
            });
            var eventHandlers001 = [
               {
                     'method' : 'performSSOLogin',
                     'artifactId' : 'Platform.SSOError_Retry_button_eventHandlers_click_performSSOLogin',
                     'id' : 'aw18912c1f',
                     'event' : 'click',
                     'class' : 'platform.handlers.SSOHandler',
               }
            ];
            button001.eventHandlers = eventHandlers001;
            container002.addChild( button001 );


            var dialog002 = new Dialog({
               'id' : 'Platform.SSOUserNameError',
               'label' : MessageService.createStaticMessage('SSO User Name Error'),
            });
            ui001.addChild( dialog002 );


            var container003 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'resource' : 'SSODialogResource',
               'artifactId' : 'Platform.SSOUserNameError_SSODialogResource_container_0',
               'id' : 'awe49a2936',
            });
            dialog002.addChild( container003 );


            var text003 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.SSOUserNameError_SSODialogResource_container_0_Errorretrievingthe',
               'id' : 'aw1211d176',
               'value' : MessageService.createStaticMessage('Error retrieving the user name from the device'),
            });
            container003.addChild( text003 );


            var text004 = new Text({
               'resourceAttribute' : 'errorMsg',
               'editable' : false,
               'artifactId' : 'Platform.SSOUserNameError_SSODialogResource_container_0_errorMsg',
               'id' : 'awe659a10b',
            });
            container003.addChild( text004 );


            var container004 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.SSOUserNameError_container_0',
               'id' : 'awd7539907',
            });
            dialog002.addChild( container004 );


            var button002 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'Platform.SSOUserNameError_Retry_button',
               'id' : 'aw979175e5',
               'label' : MessageService.createStaticMessage('Retry'),
            });
            var eventHandlers002 = [
               {
                     'method' : 'performSSOLogin',
                     'artifactId' : 'Platform.SSOUserNameError_Retry_button_eventHandlers_click_performSSOLogin',
                     'id' : 'aw74e4917c',
                     'event' : 'click',
                     'class' : 'platform.handlers.SSOHandler',
               }
            ];
            button002.eventHandlers = eventHandlers002;
            container004.addChild( button002 );


            var dialog003 = new Dialog({
               'id' : 'Platform.DownloadError',
               'label' : MessageService.createStaticMessage('System Data Download Error'),
            });
            ui001.addChild( dialog003 );


            var container005 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.DownloadError.container',
               'id' : 'awb89e88b',
            });
            dialog003.addChild( container005 );


            var text005 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.DownloadError.text',
               'id' : 'aw63a3744e',
               'value' : MessageService.createStaticMessage('Error downloading System Data'),
            });
            container005.addChild( text005 );


            var container006 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.DownloadError.container2',
               'id' : 'aw60b46d4d',
            });
            dialog003.addChild( container006 );


            var button003 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'Platform.DownloadError.button',
               'id' : 'awcf9d5479',
               'label' : MessageService.createStaticMessage('Retry'),
            });
            var eventHandlers003 = [
               {
                     'method' : 'retrySystemDownload',
                     'artifactId' : 'Platform.DownloadError.eventHandler',
                     'id' : 'awa24338f8',
                     'event' : 'click',
                     'class' : 'platform.handlers.LoginHandler',
               }
            ];
            button003.eventHandlers = eventHandlers003;
            container006.addChild( button003 );


            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'platform.LoginView', false);
               trackTimer.startTracking();
            }

            var view001 = new View({
               'cssClass' : 'mainLogin',
               'resource' : 'PlatformLoginResource',
               'showHeader' : false,
               'id' : 'platform.LoginView',
            });
            ui001.addChild( view001 );

            var requiredResources001 = {
               'PlatformLongPressResource' : {
                  'artifactId' : 'platform.LoginView_PlatformLongPressResource',
                  'id' : 'aw9dc81534',
               },
               'PlatformProgressResource' : {
                  'artifactId' : 'platform.LoginView_PlatformProgressResource',
                  'id' : 'aw80cf2a6f',
               },
               'PlatformChangePasswordForm' : {
                  'artifactId' : 'platform.LoginView_PlatformChangePasswordForm',
                  'id' : 'aw950ff29',
               },
            };
            view001.addRequiredResources( requiredResources001 );

            var container007 = new Container({
               'cssClass' : 'loginForm',
               'artifactId' : 'platform.LoginView_container_0',
               'id' : 'aw1429aadd',
            });
            view001.addChild( container007 );


            var image001 = new Image({
               'image' : '..\/..\/..\/..\/..\/..\/images\/mdpi\/app_icon_main.svg',
               'cssClass' : 'productLogo',
               'artifactId' : 'platform.LoginView_image_0',
               'id' : 'aw9576ccdf',
            });
            container007.addChild( image001 );


            var text006 = new Text({
               'resourceAttribute' : 'appName',
               'cssClass' : 'productName',
               'editable' : false,
               'artifactId' : 'platform.LoginView_container_0_appName',
               'id' : 'aw22401029',
            });
            container007.addChild( text006 );


            var text007 = new Text({
               'resourceAttribute' : 'errorMsg',
               'cssClass' : 'errorMsg',
               'editable' : false,
               'artifactId' : 'platform.LoginView_container_0_errorMsg',
               'id' : 'aw87817020',
            });
            container007.addChild( text007 );


            var text008 = new Text({
               'border' : 'true',
               'resourceAttribute' : 'username',
               'cssClass' : 'loginUsername',
               'editable' : true,
               'artifactId' : 'platform.LoginView_container_0_username',
               'id' : 'awca3922ff',
               'placeHolder' : MessageService.createStaticMessage('Username'),
            });
            container007.addChild( text008 );


            var text009 = new Text({
               'border' : 'true',
               'resourceAttribute' : 'password',
               'cssClass' : 'loginPassword',
               'editable' : true,
               'artifactId' : 'platform.LoginView_container_0_password',
               'id' : 'aw7a5625d',
               'type' : 'password',
               'placeHolder' : MessageService.createStaticMessage('Password'),
            });
            container007.addChild( text009 );


            var button004 = new Button({
               'cssClass' : 'loginBtn',
               'artifactId' : 'platform.LoginView_LogIn_button',
               'id' : 'awe0510eac',
               'label' : MessageService.createStaticMessage('Sign In'),
               'primary' : 'true',
            });
            var eventHandlers004 = [
               {
                     'method' : 'loginClickHandler',
                     'artifactId' : 'platform.LoginView_LogIn_button_eventHandlers_click_loginClickHandler',
                     'id' : 'awa8e7b081',
                     'event' : 'click',
                     'class' : 'platform.handlers.LoginHandler',
               }
            ];
            button004.eventHandlers = eventHandlers004;
            container007.addChild( button004 );


            var text010 = new Text({
               'labelCss' : 'loginLink',
               'artifactId' : 'PrivacyPolicy_link',
               'id' : 'aw8e500c53',
               'label' : MessageService.createStaticMessage('Privacy Policy'),
            });
            container007.addChild( text010 );

            var eventHandlers005 = [
               {
                     'method' : 'privacyPolicyLinkClicked',
                     'artifactId' : 'PrivacyPolicy_link_eventHandlers_click',
                     'id' : 'aw3c2baacc',
                     'event' : 'click',
                     'class' : 'platform.handlers.LoginHandler',
               }
            ];
            text010.eventHandlers = eventHandlers005;

            var image002 = new Image({
               'image' : 'IBMLogo.svg',
               'cssClass' : 'IBMLogo',
               'artifactId' : 'platform.LoginView_image_1',
               'id' : 'awe271fc49',
            });
            container007.addChild( image002 );

            var eventHandlers006 = [
               {
                     'method' : 'initializeLogin',
                     'artifactId' : 'platform.LoginView_eventHandlers_show_initializeLogin',
                     'id' : 'aw9137190b',
                     'event' : 'show',
                     'class' : 'platform.handlers.LoginHandler',
               },
               {
                     'method' : 'changeQueryBase',
                     'artifactId' : 'platform.LoginView_eventHandlers_initialize_changeQueryBase',
                     'id' : 'aw5f76d673',
                     'event' : 'initialize',
                     'class' : 'platform.handlers._ApplicationHandlerBase',
               }
            ];
            view001.eventHandlers = eventHandlers006;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'ServiceRequest.ActionPanel', false);
               trackTimer.startTracking();
            }

            var view002 = new View({
               'showBackButton' : 'false',
               'resource' : 'serviceRequest',
               'id' : 'ServiceRequest.ActionPanel',
               'label' : MessageService.createStaticMessage('Service Request'),
            });
            ui001.addChild( view002 );

            var requiredResources002 = {
               'serviceRequest' : {
                  'reload' : true,
                  'artifactId' : 'ServiceRequest.ActionPanel_serviceRequest',
                  'id' : 'aweecbed9d',
               },
               'errorResource' : {
                  'artifactId' : 'ServiceRequest.ActionPanel_requiredResource_errorResource',
                  'id' : 'aw1618eb4b',
               },
            };
            view002.addRequiredResources( requiredResources002 );

            var progressIndicator001 = new ProgressIndicator({
               'artifactId' : 'ServiceRequest.ActionPanel_0',
               'id' : 'aw767f3d10',
            });
            view002.addChild( progressIndicator001 );


            var actions001 = new Actions({
               'artifactId' : 'ServiceRequest.ActionPanel_actions',
               'id' : 'awb8c2f0e4',
            });
            view002.addChild( actions001 );


            var action001 = new Action({
               'overflow' : true,
               'artifactId' : 'ServiceRequest.ActionPanel_SynchronizeData_action',
               'id' : 'aw2da803f7',
               'label' : MessageService.createStaticMessage('Synchronize Data'),
            });
            actions001.addChild( action001 );

            var eventHandlers007 = [
               {
                     'method' : 'sync',
                     'artifactId' : 'ServiceRequest.ActionPanel_SynchronizeData_action_eventHandlers_click_sync',
                     'id' : 'awce000b97',
                     'event' : 'click',
                     'class' : 'platform.handlers.WorkOfflineHandler',
               },
               {
                     'method' : 'enableDisableSyncMenu',
                     'artifactId' : 'ServiceRequest.ActionPanelR_SynchronizeData_action_eventHandlers_render_enableDisableMenu',
                     'id' : 'awaf3b0e2b',
                     'event' : 'render',
                     'class' : 'platform.handlers.WorkOfflineHandler',
               }
            ];
            action001.eventHandlers = eventHandlers007;

            var container008 = new Container({
               'cssClass' : 'errorheader',
               'artifactId' : 'ServiceRequest.ActionPanel_container_0',
               'id' : 'awf8d69365',
            });
            view002.addChild( container008 );


            var link001 = new Link({
               'artifactId' : 'link',
               'id' : 'aw36ac99f1',
               'label' : MessageService.createStaticMessage(''),
            });
            container008.addChild( link001 );

            var eventHandlers008 = [
               {
                     'method' : 'hideShowErrorLink',
                     'artifactId' : 'link_eventHandlers_render_hideShowSelectLink',
                     'id' : 'aw6f7bdfb3',
                     'event' : 'render',
                     'class' : 'application.handlers.SRDetailHandler',
               },
               {
                     'method' : 'showErrorPage',
                     'artifactId' : 'link_eventHandlers_click',
                     'id' : 'aw2ea586b5',
                     'event' : 'click',
                     'class' : 'application.handlers.SRDetailHandler',
               }
            ];
            link001.eventHandlers = eventHandlers008;

            var container009 = new Container({
               'artifactId' : 'ServiceRequest.ActionPanel_container_1',
               'id' : 'aw8fd1a3f3',
            });
            view002.addChild( container009 );


            var group001 = new Group({
               'artifactId' : 'action1',
               'id' : 'aw9d9ad153',
            });
            container009.addChild( group001 );


            var groupitem001 = new GroupItem({
               'layout' : 'Button1Item1',
               'transitionTo' : 'ServiceRequest.CreateSR',
               'artifactId' : 'action1groupitem',
               'id' : 'awbacaf343',
            });
            group001.addChild( groupitem001 );


            var image003 = new Image({
               'image' : 'acBtn_createNew.svg',
               'cssClass' : 'actionButton',
               'layoutInsertAt' : 'button1',
               'artifactId' : 'sricon',
               'id' : 'awfbb69ba4',
               'label' : MessageService.createStaticMessage('Create New Request'),
               'platform' : 'false',
            });
            groupitem001.addChild( image003 );


            var text011 = new Text({
               'layoutInsertAt' : 'item1',
               'artifactId' : 'createsrtext',
               'id' : 'aw1b7e8145',
               'value' : MessageService.createStaticMessage('Create New Request'),
            });
            groupitem001.addChild( text011 );


            var groupitem002 = new GroupItem({
               'layout' : 'Button1Item1',
               'transitionTo' : 'ServiceRequest.MyReportedSR',
               'artifactId' : 'action2groupitem',
               'id' : 'aw51fd4840',
            });
            group001.addChild( groupitem002 );


            var image004 = new Image({
               'image' : 'acBtn_viewList.svg',
               'cssClass' : 'actionButton',
               'layoutInsertAt' : 'button1',
               'artifactId' : 'sricon2',
               'id' : 'awcb956f67',
               'label' : MessageService.createStaticMessage('My Request List'),
               'platform' : 'false',
            });
            groupitem002.addChild( image004 );


            var text012 = new Text({
               'layoutInsertAt' : 'item1',
               'artifactId' : 'createsrtext2',
               'id' : 'aw1c787593',
               'value' : MessageService.createStaticMessage('My Request List'),
            });
            groupitem002.addChild( text012 );

            var eventHandlers009 = [
               {
                     'method' : 'initActionPanel',
                     'artifactId' : 'ServiceRequest.ActionPanel_eventHandlers_initialize_initActionPanel',
                     'id' : 'awa6bc0680',
                     'event' : 'initialize',
                     'class' : 'application.handlers.SRDetailHandler',
               }
            ];
            view002.eventHandlers = eventHandlers009;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'ServiceRequest.MyReportedSR', false);
               trackTimer.startTracking();
            }

            var view003 = new View({
               'showBackButton' : 'true',
               'resource' : 'serviceRequest',
               'id' : 'ServiceRequest.MyReportedSR',
               'label' : MessageService.createStaticMessage('My Reported SRs'),
            });
            ui001.addChild( view003 );


            var queries001 = new Queries({
               'resource' : 'serviceRequest',
               'artifactId' : 'ServiceRequest.MyReportedSR_serviceRequest_queries',
               'id' : 'awb73764f8',
            });
            view003.addChild( queries001 );


            var query001 = new Query({
               'artifactId' : 'ServiceRequest.MyReportedSR_MY_REPORTED_SR',
               'id' : 'awdb14e285',
               'label' : MessageService.createStaticMessage('My Service Requests'),
               'queryBase' : 'MY_REPORTED_SR',
            });
            queries001.addChild( query001 );


            var query002 = new Query({
               'system' : 'true',
               'artifactId' : 'ServiceRequest.MyReportedSR__created__',
               'id' : 'awda6ed26d',
               'label' : MessageService.createStaticMessage('Service Requests Created Locally'),
               'queryBase' : '__created__',
            });
            queries001.addChild( query002 );


            var query003 = new Query({
               'system' : 'true',
               'artifactId' : 'ServiceRequest.MyReportedSR___errored__',
               'id' : 'awab7af76e',
               'label' : MessageService.createStaticMessage('Records with Errors'),
               'queryBase' : '__errored__',
            });
            queries001.addChild( query003 );

            var eventHandlers010 = [
               {
                     'method' : 'hideShowErrorMenu',
                     'artifactId' : 'ServiceRequest.MyReportedSR___errored___eventHandlers_render_hideShowErrorMenu',
                     'id' : 'awd9ed4a0a',
                     'event' : 'render',
                     'class' : 'application.handlers.SRDetailHandler',
               }
            ];
            query003.eventHandlers = eventHandlers010;
            var requiredResources003 = {
               'serviceRequest' : {
                  'reload' : true,
                  'artifactId' : 'ServiceRequest.MyReportedSR_serviceRequest',
                  'id' : 'aw14f7462',
               },
               'PlatformProgressResource' : {
                  'artifactId' : 'ServiceRequest.MyReportedSR_PlatformProgressResource',
                  'id' : 'aw66523d55',
               },
               'domainsrstatus' : {
                  'artifactId' : 'ServiceRequest.MyReportedSR_domainsrstatus',
                  'id' : 'aw52c69416',
               },
            };
            view003.addRequiredResources( requiredResources003 );
            var eventHandlers011 = [
               {
                     'method' : 'initMyReportedSR',
                     'artifactId' : 'ServiceRequest.MyReportedSR_eventHandlers_initialize_initMyReportedSR',
                     'id' : 'aw9c05ed35',
                     'event' : 'initialize',
                     'class' : 'application.handlers.SRDetailHandler',
               }
            ];
            view003.eventHandlers = eventHandlers011;

            var progressIndicator002 = new ProgressIndicator({
               'artifactId' : 'ServiceRequest.MyReportedSR_0',
               'id' : 'awea98c0ad',
            });
            view003.addChild( progressIndicator002 );



            var sortOptions001 = new SortOptions({
               'artifactId' : 'ServiceRequest.WorkItemsView_serviceRequest_list_sortOptions',
               'id' : 'awf8273967',
            });

            var sortOption001 = new SortOption({
               'artifactId' : 'ServiceRequest.WorkItemsView_sortOption_srnum',
               'id' : 'aw9a782eb9',
               'label' : MessageService.createStaticMessage('Request Number'),
            });
            sortOptions001.addChild( sortOption001 );


            var sortAttribute001 = new SortAttribute({
               'name' : 'srnum',
               'artifactId' : 'ServiceRequest.WorkItemsView_srnum_sortAttribute_srnum',
               'id' : 'aw42169704',
               'direction' : 'desc',
            });
            sortOption001.addChild( sortAttribute001 );



            var listItemTemplate001 = new ListItemTemplate({
               'layout' : 'WorkListItem',
               'artifactId' : 'ServiceRequest.MyReportedSR_serviceRequest_listItemTemplate_WorkListItem',
               'id' : 'awc6918449',
            });

            var listtext001 = new ListText({
               'resourceAttribute' : 'srnum',
               'cssClass' : 'bold textappearance-medium',
               'layoutInsertAt' : 'item1',
               'artifactId' : 'ServiceRequest.MyReportedSR_serviceRequest_WorkListItem_srnum',
               'id' : 'awc8f36010',
            });
            listItemTemplate001.addChild( listtext001 );


            var listtext002 = new ListText({
               'resourceAttribute' : 'summary',
               'layoutInsertAt' : 'item3',
               'artifactId' : 'ServiceRequest.MyReportedSR_serviceRequest_WorkListItem_description',
               'id' : 'aw2926d2be',
            });
            listItemTemplate001.addChild( listtext002 );


            var listtext003 = new ListText({
               'resourceAttribute' : 'statusdesc',
               'layoutInsertAt' : 'item2',
               'artifactId' : 'ServiceRequestMyReportedSR_serviceRequest_WorkListItem_statusdesc',
               'id' : 'awc63a3301',
               'cssAttributes' : 'status',
            });
            listItemTemplate001.addChild( listtext003 );


            var listtext004 = new ListText({
               'resourceAttribute' : 'asset',
               'layoutInsertAt' : 'item4',
               'artifactId' : 'ServiceRequest.MyReportedSR_serviceRequest_WorkListItem_asset',
               'id' : 'aw50384925',
            });
            listItemTemplate001.addChild( listtext004 );


            var listtext005 = new ListText({
               'resourceAttribute' : 'maxassetdesc',
               'layoutInsertAt' : 'item5',
               'artifactId' : 'ServiceRequest.MyReportedSR_serviceRequest_WorkListItem_assetdesc',
               'id' : 'aw9fe6a818',
            });
            listItemTemplate001.addChild( listtext005 );



            var list001 = new List({
               'resource' : 'serviceRequest',
               'transitionTo' : 'ServiceRequest.SRDetail',
               'sortOptions' : sortOptions001,
               'listItemTemplate' : listItemTemplate001,
               'artifactId' : 'ServiceRequest.MyReportedSR_serviceRequest_list',
               'id' : 'aw7c9f6059',
               'displayPageSize' : '20',
            });
            view003.addChild( list001 );


            var actions002 = new Actions({
               'artifactId' : 'ServiceRequest.MyReportedSR_actions',
               'id' : 'aw11935cb6',
            });
            view003.addChild( actions002 );


            var action002 = new Action({
               'overflow' : true,
               'transitionTo' : 'ServiceRequest.CreateSR',
               'artifactId' : 'ServiceRequest.MyReportedSR_CreateSR_action',
               'id' : 'aw208978ee',
               'label' : MessageService.createStaticMessage('Create New Request'),
            });
            actions002.addChild( action002 );


            var action003 = new Action({
               'overflow' : true,
               'artifactId' : 'ServiceRequest.MyReportedSR_SynchronizeData_action',
               'id' : 'aw5e16303e',
               'label' : MessageService.createStaticMessage('Synchronize Data'),
            });
            actions002.addChild( action003 );

            var eventHandlers012 = [
               {
                     'method' : 'sync',
                     'artifactId' : 'ServiceRequest.MyReportedSR_SynchronizeData_action_eventHandlers_click_sync',
                     'id' : 'awbf0a55e6',
                     'event' : 'click',
                     'class' : 'platform.handlers.WorkOfflineHandler',
               },
               {
                     'method' : 'enableDisableSyncMenu',
                     'artifactId' : 'ServiceRequest.MyReportedSR_SynchronizeData_action_eventHandlers_render_enableDisableMenu',
                     'id' : 'aw7129a7d',
                     'event' : 'render',
                     'class' : 'platform.handlers.WorkOfflineHandler',
               }
            ];
            action003.eventHandlers = eventHandlers012;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'ServiceRequest.EditAssetView', false);
               trackTimer.startTracking();
            }

            var view004 = new View({
               'id' : 'ServiceRequest.EditAssetView',
               'label' : MessageService.createStaticMessage('Asset'),
            });
            ui001.addChild( view004 );

            var requiredResources004 = {
               'serviceRequest' : {
                  'artifactId' : 'ServiceRequest.EditAssetView_serviceRequest',
                  'id' : 'aw953c4bf4',
               },
               'additionalasset' : {
                  'artifactId' : 'ServiceRequest.EditAssetView_additionalasset',
                  'id' : 'awe96a6e2a',
               },
               'domainAssetstatus' : {
                  'artifactId' : 'ServiceRequest.EditAssetView_domainAssetstatus',
                  'id' : 'awe07610ef',
               },
            };
            view004.addRequiredResources( requiredResources004 );

            var container010 = new Container({
               'resource' : 'serviceRequest',
               'artifactId' : 'ServiceRequest.EditAssetView_serviceRequest_container_0',
               'id' : 'aw443b5d5a',
            });
            view004.addChild( container010 );


            var group002 = new Group({
               'artifactId' : 'ServiceRequest.EditAssetView_group_0',
               'id' : 'aw830615f9',
            });
            container010.addChild( group002 );


            var groupitem003 = new GroupItem({
               'artifactId' : 'ServiceRequest.EditAssetView_serviceRequest_groupitem_0',
               'id' : 'aw1e0cc49',
            });
            group002.addChild( groupitem003 );


            var text013 = new Text({
               'resourceAttribute' : 'asset',
               'lookup' : 'ServiceRequest.AssetLookup',
               'editable' : true,
               'artifactId' : 'ServiceRequest.EditAssetView_serviceRequest_groupitem_0_asset',
               'id' : 'aw5b98c3b1',
               'codeScannable' : true,
               'lookupAttribute' : 'assetnum',
               'placeHolder' : MessageService.createStaticMessage('Tap to enter'),
            });
            groupitem003.addChild( text013 );

            var eventHandlers013 = [
               {
                     'method' : 'validateAsset',
                     'artifactId' : 'ServiceRequest.EditAssetView_serviceRequest_groupitem_0_asset_eventHandlers_validate_validateAsset',
                     'id' : 'aw1d8cf22f',
                     'event' : 'validate',
                     'class' : 'application.handlers.SRDetailHandler',
               }
            ];
            text013.eventHandlers = eventHandlers013;

            var text014 = new Text({
               'resourceAttribute' : 'assetdesc',
               'editable' : false,
               'artifactId' : 'ServiceRequest.EditAssetView_serviceRequest_groupitem_0_assetdesc',
               'id' : 'aw78b325dc',
            });
            groupitem003.addChild( text014 );


            var groupitem004 = new GroupItem({
               'artifactId' : 'ServiceRequest.EditAssetView_serviceRequest_groupitem_1',
               'id' : 'aw76e7fcdf',
            });
            group002.addChild( groupitem004 );


            var text015 = new Text({
               'resourceAttribute' : 'assetld',
               'cssClass' : 'richText',
               'editable' : false,
               'artifactId' : 'ServiceRequest.EditAssetView_serviceRequest_groupitem_1_assetld',
               'id' : 'aw2a86d03d',
            });
            groupitem004.addChild( text015 );


            var footer001 = new Footer({
               'artifactId' : 'ServiceRequest.EditAssetView_footer',
               'id' : 'awfa7e1ec1',
            });
            view004.addChild( footer001 );


            var button005 = new Button({
               'artifactId' : 'ServiceRequest.EditAssetView_Cancel_button',
               'id' : 'aw151759b7',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers014 = [
               {
                     'method' : 'handleBackButtonClickEditAssetView',
                     'artifactId' : 'ServiceRequest.EditAssetView_Cancel_button_eventHandlers_click_handleBackButtonClickEditAssetView',
                     'id' : 'aw3231f658',
                     'event' : 'click',
                     'class' : 'application.handlers.SRDetailHandler',
               }
            ];
            button005.eventHandlers = eventHandlers014;
            footer001.addChild( button005 );


            var button006 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'ServiceRequest.EditAssetView_Save_button',
               'id' : 'aw2416138d',
               'label' : MessageService.createStaticMessage('Save'),
               'primary' : 'true',
            });
            var eventHandlers015 = [
               {
                     'method' : 'commitAssetEntryView',
                     'artifactId' : 'ServiceRequest.EditAssetView_Save_button_eventHandlers_click_commitAssetEntryView',
                     'id' : 'aw2d1db5ed',
                     'event' : 'click',
                     'class' : 'application.handlers.SRDetailHandler',
               }
            ];
            button006.eventHandlers = eventHandlers015;
            footer001.addChild( button006 );

            var eventHandlers016 = [
               {
                     'method' : 'initEditAssetView',
                     'artifactId' : 'ServiceRequest.EditAssetView_eventHandlers_initialize_initEditAssetView',
                     'id' : 'awa878b6e1',
                     'event' : 'initialize',
                     'class' : 'application.handlers.SRDetailHandler',
               },
               {
                     'method' : 'cleanupEditAssetView',
                     'artifactId' : 'ServiceRequest.EditAssetView_eventHandlers_cleanup_cleanupEditAssetView',
                     'id' : 'awd7805d6',
                     'event' : 'cleanup',
                     'class' : 'application.handlers.SRDetailHandler',
               }
            ];
            view004.eventHandlers = eventHandlers016;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'ServiceRequest.EditLocationView', false);
               trackTimer.startTracking();
            }

            var view005 = new View({
               'id' : 'ServiceRequest.EditLocationView',
               'label' : MessageService.createStaticMessage('Location'),
            });
            ui001.addChild( view005 );

            var requiredResources005 = {
               'additionallocations' : {
                  'artifactId' : 'ServiceRequest.EditLocationView_additionallocations',
                  'id' : 'awed84184e',
               },
               'serviceRequest' : {
                  'artifactId' : 'ServiceRequest.EditLocationView_serviceRequest',
                  'id' : 'aw38fcd077',
               },
               'domainAssetstatus' : {
                  'artifactId' : 'ServiceRequest.EditLocationView_domainAssetstatus',
                  'id' : 'awad424fa',
               },
               'additionalasset' : {
                  'artifactId' : 'ServiceRequest.EditLocationView_additionalasset',
                  'id' : 'aw9d767c2b',
               },
            };
            view005.addRequiredResources( requiredResources005 );

            var container011 = new Container({
               'resource' : 'serviceRequest',
               'artifactId' : 'ServiceRequest.EditLocationView_serviceRequest_container_0',
               'id' : 'awc400fd40',
            });
            view005.addChild( container011 );


            var group003 = new Group({
               'artifactId' : 'ServiceRequest.EditLocationView_group_0',
               'id' : 'aw735ae764',
            });
            container011.addChild( group003 );


            var groupitem005 = new GroupItem({
               'artifactId' : 'ServiceRequest.EditLocationView_serviceRequest_groupitem_0',
               'id' : 'aw81db6c53',
            });
            group003.addChild( groupitem005 );


            var text016 = new Text({
               'resourceAttribute' : 'location',
               'lookup' : 'ServiceRequest.LocationLookup',
               'editable' : true,
               'artifactId' : 'ServiceRequest.EditLocationView_serviceRequest_groupitem_0_location_Location',
               'id' : 'aw1b4e94a4',
               'label' : MessageService.createStaticMessage('Location'),
               'codeScannable' : true,
               'lookupAttribute' : 'location',
               'placeHolder' : MessageService.createStaticMessage('Tap to enter'),
            });
            groupitem005.addChild( text016 );

            var eventHandlers017 = [
               {
                     'method' : 'validateLocation',
                     'artifactId' : 'ServiceRequest.EditLocationView_serviceRequest_groupitem_0_location_Location_eventHandlers_validate_validateLocation',
                     'id' : 'awe36a25b6',
                     'event' : 'validate',
                     'class' : 'application.handlers.SRDetailHandler',
               }
            ];
            text016.eventHandlers = eventHandlers017;

            var text017 = new Text({
               'resourceAttribute' : 'locationdesc',
               'editable' : false,
               'artifactId' : 'ServiceRequest.EditLocationView_serviceRequest_groupitem_0_locationdesc',
               'id' : 'awc1f62b64',
            });
            groupitem005.addChild( text017 );


            var groupitem006 = new GroupItem({
               'artifactId' : 'ServiceRequest.EditLocationView_serviceRequest_groupitem_1',
               'id' : 'awf6dc5cc5',
            });
            group003.addChild( groupitem006 );


            var text018 = new Text({
               'resourceAttribute' : 'locationld',
               'cssClass' : 'richText',
               'editable' : false,
               'artifactId' : 'ServiceRequest.EditLocationView_serviceRequest_groupitem_1_locationld',
               'id' : 'awa58e41e6',
            });
            groupitem006.addChild( text018 );


            var footer002 = new Footer({
               'artifactId' : 'ServiceRequest.EditLocationView_footer',
               'id' : 'awa91fc751',
            });
            view005.addChild( footer002 );


            var button007 = new Button({
               'layoutInsertAt' : 'button1',
               'artifactId' : 'ServiceRequest.EditLocationView_Cancel_button',
               'id' : 'awb2049cdd',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers018 = [
               {
                     'method' : 'discardView',
                     'artifactId' : 'ServiceRequest.EditLocationView_Cancel_button_eventHandlers_click_discardView',
                     'id' : 'awaeb314bd',
                     'event' : 'click',
                     'class' : 'application.handlers.SRDetailHandler',
               }
            ];
            button007.eventHandlers = eventHandlers018;
            footer002.addChild( button007 );


            var button008 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'layoutInsertAt' : 'button2',
               'artifactId' : 'ServiceRequest.EditLocationView_Save_button',
               'id' : 'aw76cf6d0e',
               'label' : MessageService.createStaticMessage('Save'),
               'primary' : 'true',
            });
            var eventHandlers019 = [
               {
                     'method' : 'commitActualLocationEntryView',
                     'artifactId' : 'ServiceRequest.EditLocationView_Save_button_eventHandlers_click_commitActualLocationEntryView',
                     'id' : 'aw368b692f',
                     'event' : 'click',
                     'class' : 'application.handlers.SRDetailHandler',
               }
            ];
            button008.eventHandlers = eventHandlers019;
            footer002.addChild( button008 );

            var eventHandlers020 = [
               {
                     'method' : 'cleanupEditLocationView',
                     'artifactId' : 'ServiceRequest.EditLocationView_eventHandlers_cleanup_cleanupEditLocationView',
                     'id' : 'aw2ed37248',
                     'event' : 'cleanup',
                     'class' : 'application.handlers.SRDetailHandler',
               },
               {
                     'method' : 'initEditLocationView',
                     'artifactId' : 'ServiceRequest.EditLocationView_eventHandlers_initialize_initEditLocationView',
                     'id' : 'awc01f7c83',
                     'event' : 'initialize',
                     'class' : 'application.handlers.SRDetailHandler',
               }
            ];
            view005.eventHandlers = eventHandlers020;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'ServiceRequest.CreateSR', false);
               trackTimer.startTracking();
            }

            var view006 = new View({
               'resource' : 'serviceRequest',
               'showKeyboard' : 'true',
               'id' : 'ServiceRequest.CreateSR',
               'label' : MessageService.createStaticMessage('Create New Request'),
            });
            ui001.addChild( view006 );

            var requiredResources006 = {
               'serviceRequest' : {
                  'artifactId' : 'ServiceRequest.CreateSR_serviceRequest',
                  'id' : 'aw599d308b',
               },
               'additionalasset' : {
                  'artifactId' : 'ServiceRequest.CreateSR_additionalasset',
                  'id' : 'aw291ca3fc',
               },
               'domainAssetstatus' : {
                  'artifactId' : 'ServiceRequest.CreateSR_domainAssetstatus',
                  'id' : 'awd2c10c0d',
               },
               'mylabor' : {
                  'artifactId' : 'ServiceRequest.CreateSR_mylabor',
                  'id' : 'aw9b0ce41d',
               },
               'priorityDomain' : {
                  'artifactId' : 'ServiceRequest.CreateSR_priorityDomain',
                  'id' : 'awbfb98141',
               },
            };
            view006.addRequiredResources( requiredResources006 );
            var eventHandlers021 = [
               {
                     'method' : 'initNewServiceRequestView',
                     'artifactId' : 'ServiceRequest.CreateSR_eventHandlers_initialize_initNewServiceRequestView',
                     'id' : 'aw2013282f',
                     'event' : 'initialize',
                     'class' : 'application.handlers.SRDetailHandler',
               },
               {
                     'method' : 'handleBackButton',
                     'artifactId' : 'ServiceRequest.CreateSR_eventHandlers_cleanup_handleBackButton',
                     'id' : 'aw5852b3ba',
                     'event' : 'cleanup',
                     'class' : 'application.handlers.SRDetailHandler',
               }
            ];
            view006.eventHandlers = eventHandlers021;

            var actions003 = new Actions({
               'artifactId' : 'ServiceRequest.CreateSR_actions',
               'id' : 'awd01c9bc',
            });
            view006.addChild( actions003 );


            var action004 = new Action({
               'image' : '\/images\/header_camera_off.svg',
               'enableFeatureByProperty' : 'attachments.enabled',
               'artifactId' : 'ServiceRequest.CreateSR_TakePhoto_action',
               'id' : 'aw8a8feda5',
               'label' : MessageService.createStaticMessage('Take Photo'),
            });
            actions003.addChild( action004 );

            var eventHandlers022 = [
               {
                     'method' : 'launchCameraForPhoto',
                     'artifactId' : 'ServiceRequest.CreateSR_TakePhoto_action_eventHandlers_click_launchCameraForPhoto',
                     'id' : 'aw42f41c08',
                     'event' : 'click',
                     'class' : 'platform.handlers.AttachmentHandler',
               },
               {
                     'method' : 'initCategory',
                     'artifactId' : 'ServiceRequest.CreateSR_TakePhoto_action_eventHandlers_render_initCategory',
                     'id' : 'aw1fb1d13f',
                     'event' : 'render',
                     'class' : 'application.handlers.SRAttachmentHandler',
               }
            ];
            action004.eventHandlers = eventHandlers022;

            var container012 = new Container({
               'resource' : 'serviceRequest',
               'artifactId' : 'ServiceRequest.CreateSR_serviceRequest_container_0',
               'id' : 'awd78f07db',
            });
            view006.addChild( container012 );


            var group004 = new Group({
               'artifactId' : 'ServiceRequest.CreateSR_group_0',
               'id' : 'aw955690d9',
            });
            container012.addChild( group004 );


            var groupitem007 = new GroupItem({
               'artifactId' : 'ServiceRequest.CreateSR_serviceRequest_groupitem_ServiceRequest_summary_0',
               'id' : 'aw3f7ae13',
            });
            group004.addChild( groupitem007 );


            var text019 = new Text({
               'resourceAttribute' : 'summary',
               'editable' : true,
               'artifactId' : 'ServiceRequest.CreateSR_serviceRequest_groupitem_ServiceRequest.summary_0',
               'id' : 'aw1a7c40b5',
               'label' : MessageService.createStaticMessage('Summary'),
            });
            groupitem007.addChild( text019 );


            var groupitem008 = new GroupItem({
               'artifactId' : 'ServiceRequest.CreateSR_serviceRequest_groupitem_0',
               'id' : 'aw925496c8',
            });
            group004.addChild( groupitem008 );


            var textarea001 = new TextArea({
               'resourceAttribute' : 'description',
               'editable' : true,
               'artifactId' : 'ServiceRequest.CreateSR_serviceRequest_groupitem_0_description_Description',
               'id' : 'aw90a830a6',
               'label' : MessageService.createStaticMessage('Description'),
               'placeHolder' : MessageService.createStaticMessage('Tap to enter'),
               'required' : true,
            });
            groupitem008.addChild( textarea001 );


            var groupitem009 = new GroupItem({
               'enableFeatureByProperty' : 'gps.enabled',
               'artifactId' : 'ServiceRequest.CreateSR_groupitem_ServiceRequest.GPS',
               'id' : 'awdd0ed93c',
            });
            group004.addChild( groupitem009 );


            var checkbox001 = new CheckBox({
               'resourceAttribute' : 'gpsLocation',
               'editable' : true,
               'artifactId' : 'ServiceRequest.CreateSR_checkbox_CreateSR.GPS',
               'id' : 'awe29345aa',
               'label' : MessageService.createStaticMessage('Capture GPS coordinates?'),
            });
            groupitem009.addChild( checkbox001 );

            var eventHandlers023 = [
               {
                     'method' : 'initGPSField',
                     'artifactId' : 'ServiceRequest.CreateSR_checkbox_eventHandlers_render_initGPSField',
                     'id' : 'awcdb45e50',
                     'event' : 'render',
                     'class' : 'application.handlers.SRDetailHandler',
               }
            ];
            checkbox001.eventHandlers = eventHandlers023;

            var groupitem010 = new GroupItem({
               'transitionTo' : 'ServiceRequest.EditLocationView',
               'artifactId' : 'ServiceRequest.CreateSR_serviceRequest_groupitem_ServiceRequest.EditLocationView_0',
               'id' : 'awe7b14e28',
            });
            group004.addChild( groupitem010 );


            var text020 = new Text({
               'resourceAttribute' : 'location',
               'lookup' : 'ServiceRequest.LocationLookup',
               'editable' : true,
               'artifactId' : 'ServiceRequest.CreateSR_serviceRequest_groupitem_ServiceRequest.EditLocationView_0_location_Location',
               'id' : 'aw78587705',
               'label' : MessageService.createStaticMessage('Location'),
               'codeScannable' : true,
               'lookupAttribute' : 'location',
               'placeHolder' : MessageService.createStaticMessage('Tap to enter'),
            });
            groupitem010.addChild( text020 );

            var eventHandlers024 = [
               {
                     'method' : 'asyncvalidateLocation',
                     'artifactId' : 'ServiceRequest.CreateSR_serviceRequest_groupitem_ServiceRequest.EditLocationView_0_location_Location_eventHandlers_validate_asyncvalidateLocation',
                     'id' : 'aw6c99da8d',
                     'event' : 'validate',
                     'class' : 'application.handlers.SRDetailHandler',
               }
            ];
            text020.eventHandlers = eventHandlers024;

            var text021 = new Text({
               'resourceAttribute' : 'locationdesc',
               'editable' : false,
               'artifactId' : 'ServiceRequest.CreateSR_serviceRequest_groupitem_ServiceRequest.EditLocationView_0_locationdesc',
               'id' : 'aw64317af',
            });
            groupitem010.addChild( text021 );


            var groupitem011 = new GroupItem({
               'transitionTo' : 'ServiceRequest.EditAssetView',
               'artifactId' : 'ServiceRequest.CreateSR_serviceRequest_groupitem_ServiceRequest.EditAssetView_0',
               'id' : 'aw87f6d1c1',
            });
            group004.addChild( groupitem011 );


            var text022 = new Text({
               'resourceAttribute' : 'asset',
               'lookup' : 'ServiceRequest.AssetLookup',
               'editable' : true,
               'artifactId' : 'ServiceRequest.CreateSR_serviceRequest_groupitem_ServiceRequest.EditAssetView_0_asset_Asset',
               'id' : 'aw123edbbd',
               'label' : MessageService.createStaticMessage('Asset'),
               'codeScannable' : true,
               'lookupAttribute' : 'assetnum',
               'placeHolder' : MessageService.createStaticMessage('Tap to enter'),
            });
            groupitem011.addChild( text022 );

            var eventHandlers025 = [
               {
                     'method' : 'asyncvalidateAsset',
                     'artifactId' : 'ServiceRequest.CreateSR_serviceRequest_groupitem_ServiceRequest.EditAssetView_0_asset_Asset_eventHandlers_validate_asyncvalidateAsset',
                     'id' : 'awf3409353',
                     'event' : 'validate',
                     'class' : 'application.handlers.SRDetailHandler',
               }
            ];
            text022.eventHandlers = eventHandlers025;

            var text023 = new Text({
               'resourceAttribute' : 'assetdesc',
               'editable' : false,
               'artifactId' : 'ServiceRequest.CreateSR_serviceRequest_groupitem_ServiceRequest.EditAssetView_0_assetdesc',
               'id' : 'aw81fc2e6b',
            });
            groupitem011.addChild( text023 );


            var groupitem012 = new GroupItem({
               'artifactId' : 'ServiceRequest.CreateSR_serviceRequest_groupitem_ServiceRequest.ReportedPriority_0',
               'id' : 'awd584fcec',
            });
            group004.addChild( groupitem012 );


            var text024 = new Text({
               'resourceAttribute' : 'reportedpriority',
               'lookup' : 'ServiceRequest.PriorityLookup',
               'editable' : true,
               'artifactId' : 'ServiceRequest.CreateSR_serviceRequest_groupitem_ServiceRequest.ReportedPriority_0_ReportedPririty',
               'id' : 'aw8be5373c',
               'label' : MessageService.createStaticMessage('Priority'),
               'lookupAttribute' : 'reportedpriority',
               'placeHolder' : MessageService.createStaticMessage('Tap to enter'),
            });
            groupitem012.addChild( text024 );

            var eventHandlers026 = [
               {
                     'method' : 'validatePriority',
                     'artifactId' : 'ServiceRequest.CreateSR_serviceRequest_groupitem_ServiceRequest.EditPriorityView_0_Priority_Priority_eventHandlers_validate_validatePriority',
                     'id' : 'aw73561438',
                     'event' : 'validate',
                     'class' : 'application.handlers.SRDetailHandler',
               }
            ];
            text024.eventHandlers = eventHandlers026;

            var text025 = new Text({
               'resourceAttribute' : 'prioritydesc',
               'editable' : false,
               'artifactId' : 'ServiceRequest.CreateSR_serviceRequest_groupitem_ServiceRequest.EditLocationView_0_prioritydesc',
               'id' : 'awc86dc508',
            });
            groupitem012.addChild( text025 );


            var groupitem013 = new GroupItem({
               'layout' : 'Item1Count1Button2',
               'enableFeatureByProperty' : 'attachments.enabled',
               'transitionTo' : 'ServiceRequest.AttachmentsView',
               'artifactId' : 'ServiceRequest.CreateSR_groupitem_ServiceRequest.AttachmentsView_0',
               'id' : 'aw6da05cd9',
            });
            group004.addChild( groupitem013 );


            var text026 = new Text({
               'cssClass' : 'relatedRecords',
               'editable' : false,
               'layoutInsertAt' : 'item1',
               'artifactId' : 'ServiceRequest.CreateSR_groupitem_ServiceRequest.AttachmentsView_0_Attachments',
               'id' : 'aw2820eb43',
               'value' : MessageService.createStaticMessage('Attachments'),
            });
            groupitem013.addChild( text026 );


            var text027 = new Text({
               'resourceAttribute' : 'attachmentssize',
               'editable' : false,
               'layoutInsertAt' : 'count1',
               'artifactId' : 'ServiceRequest.CreateSR_groupitem_ServiceRequest.AttachmentsView_0_attachmentssize',
               'id' : 'awf3225e3e',
            });
            groupitem013.addChild( text027 );


            var group005 = new Group({
               'artifactId' : 'ServiceRequest.CreateSR_group_1',
               'id' : 'awe251a04f',
            });
            container012.addChild( group005 );


            var groupitem014 = new GroupItem({
               'layout' : 'Item1Count1Button1',
               'transitionTo' : 'ServiceRequest.WorkLogView',
               'artifactId' : 'ServiceRequest.CreateSR_group_1_grouptitem1',
               'id' : 'awebaa734f',
            });
            group005.addChild( groupitem014 );


            var text028 = new Text({
               'cssClass' : 'relatedRecords',
               'editable' : false,
               'layoutInsertAt' : 'item1',
               'artifactId' : 'ServiceRequest.CreateSR_group_1_groupitem1_text1',
               'id' : 'aw454c2282',
               'value' : MessageService.createStaticMessage('Work Log'),
            });
            groupitem014.addChild( text028 );


            var text029 = new Text({
               'resourceAttribute' : 'workloglistsize',
               'editable' : false,
               'layoutInsertAt' : 'count1',
               'artifactId' : 'ServiceRequest.CreateSR_group_1_groupitem1_text2',
               'id' : 'awdc457338',
            });
            groupitem014.addChild( text029 );


            var button009 = new Button({
               'image' : 'action_addNew_OFF.svg',
               'transitionTo' : 'ServiceRequest.NewWorkLogView',
               'layoutInsertAt' : 'button1',
               'artifactId' : 'ServiceRequest.CreateSR_group_1_button1',
               'id' : 'aw8d1608b5',
               'label' : MessageService.createStaticMessage('Create Work Log Entry'),
            });
            var eventHandlers027 = [
               {
                     'method' : 'enableAddWorkLogButton',
                     'artifactId' : 'ServiceRequest.CreateSR_group_1_enableAddWorkLogButton',
                     'id' : 'aw59fbdd2',
                     'event' : 'datachange',
                     'class' : 'application.handlers.WorkLogHandler',
               }
            ];
            button009.eventHandlers = eventHandlers027;
            groupitem014.addChild( button009 );


            var footer003 = new Footer({
               'artifactId' : 'ServiceRequest.CreateSR_footer',
               'id' : 'awc6347b1e',
            });
            view006.addChild( footer003 );


            var button010 = new Button({
               'artifactId' : 'ServiceRequest.CreateSR_Cancel_button',
               'id' : 'awb81bb303',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers028 = [
               {
                     'method' : 'discardNewServiceRequestView',
                     'artifactId' : 'ServiceRequest.CreateSR_Cancel_button_eventHandlers_click_discardNewServiceRequestView',
                     'id' : 'aw57cdc8ac',
                     'event' : 'click',
                     'class' : 'application.handlers.SRDetailHandler',
               }
            ];
            button010.eventHandlers = eventHandlers028;
            footer003.addChild( button010 );


            var button011 = new Button({
               'resourceAttribute' : 'srnum',
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'ServiceRequest.CreateSR_wonum_Create_button',
               'id' : 'aw1dabb512',
               'label' : MessageService.createStaticMessage('Create'),
               'primary' : 'true',
            });
            var eventHandlers029 = [
               {
                     'method' : 'commitNewServiceRequestView',
                     'artifactId' : 'ServiceRequest.CreateSR_wonum_Create_button_eventHandlers_click_commitNewServiceRequestView',
                     'id' : 'aw8a2436e6',
                     'event' : 'click',
                     'class' : 'application.handlers.SRDetailHandler',
               }
            ];
            button011.eventHandlers = eventHandlers029;
            footer003.addChild( button011 );

            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'ServiceRequest.SRDetail', false);
               trackTimer.startTracking();
            }

            var view007 = new View({
               'showBackButton' : 'true',
               'resource' : 'serviceRequest',
               'id' : 'ServiceRequest.SRDetail',
               'label' : MessageService.createStaticMessage('Service Request Details'),
               'editableView' : 'ServiceRequest.SRDetailEdit',
            });
            ui001.addChild( view007 );

            var requiredResources007 = {
               'serviceRequest' : {
                  'artifactId' : 'ServiceRequest.SRDetail_serviceRequest',
                  'id' : 'aw4763798b',
               },
               'additionalasset' : {
                  'artifactId' : 'ServiceRequest.SRDetail_additionalasset',
                  'id' : 'aw29025db5',
               },
               'domainAssetstatus' : {
                  'artifactId' : 'ServiceRequest.SRDetail_domainAssetstatus',
                  'id' : 'awa97f2744',
               },
               'domainsrstatus' : {
                  'artifactId' : 'ServiceRequest.SRDetail_domainsrstatus',
                  'id' : 'aw14ea99ff',
               },
            };
            view007.addRequiredResources( requiredResources007 );
            var eventHandlers030 = [
               {
                     'method' : 'fetchAllListSizes',
                     'artifactId' : 'ServiceRequest.SRDetail_eventHandlers_initialize_fetchAllListSizes',
                     'id' : 'awe36ec24c',
                     'event' : 'initialize',
                     'class' : 'application.handlers.SRDetailHandler',
               },
               {
                     'method' : 'refreshAllListSizes',
                     'artifactId' : 'ServiceRequest.SRDetailw_eventHandlers_render_refreshAllListSizes',
                     'id' : 'aw68214dc5',
                     'event' : 'render',
                     'class' : 'application.handlers.SRDetailHandler',
               }
            ];
            view007.eventHandlers = eventHandlers030;

            var container013 = new Container({
               'resource' : 'serviceRequest',
               'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_container_0',
               'id' : 'aw100d0578',
            });
            view007.addChild( container013 );


            var errorIndicator001 = new ErrorIndicator({
               'artifactId' : 'ServiceRequest.SRDetail_errorIndicator',
               'id' : 'aw3bfd5fff',
            });
            container013.addChild( errorIndicator001 );


            var group006 = new Group({
               'artifactId' : 'ServiceRequest.SRDetail_group_0',
               'id' : 'aw429d19d2',
            });
            container013.addChild( group006 );


            var groupitem015 = new GroupItem({
               'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_groupitem_ServiceRequest_status_0',
               'id' : 'aw14dff218',
            });
            group006.addChild( groupitem015 );


            var text030 = new Text({
               'resourceAttribute' : 'statusdesc',
               'editable' : false,
               'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_groupitem_ServiceRequest.status_0',
               'id' : 'awf307258e',
               'label' : MessageService.createStaticMessage('Status'),
            });
            groupitem015.addChild( text030 );


            var groupitem016 = new GroupItem({
               'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_groupitem_ServiceRequest_srnum_0',
               'id' : 'awcb78d10c',
            });
            group006.addChild( groupitem016 );


            var text031 = new Text({
               'resourceAttribute' : 'srnum',
               'editable' : false,
               'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_groupitem_ServiceRequest.srnum_0',
               'id' : 'awab824002',
               'label' : MessageService.createStaticMessage('Request Number'),
            });
            groupitem016.addChild( text031 );


            var groupitem017 = new GroupItem({
               'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_groupitem_ServiceRequest_owner_0',
               'id' : 'aw7ca805d7',
            });
            group006.addChild( groupitem017 );


            var text032 = new Text({
               'resourceAttribute' : 'owner',
               'editable' : false,
               'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_groupitem_ServiceRequest.owner_0',
               'id' : 'aw1c5294d9',
               'label' : MessageService.createStaticMessage('Service Request Owner'),
            });
            groupitem017.addChild( text032 );


            var groupitem018 = new GroupItem({
               'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_groupitem_ServiceRequest_summary_0',
               'id' : 'aw3b09ba21',
            });
            group006.addChild( groupitem018 );


            var text033 = new Text({
               'resourceAttribute' : 'summary',
               'editable' : false,
               'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_groupitem_ServiceRequest.summary_0',
               'id' : 'aw22825487',
               'label' : MessageService.createStaticMessage('Summary'),
            });
            groupitem018.addChild( text033 );


            var groupitem019 = new GroupItem({
               'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_groupitem_0',
               'id' : 'aw55d6946b',
            });
            group006.addChild( groupitem019 );


            var text034 = new Text({
               'resourceAttribute' : 'description',
               'cssClass' : 'richText',
               'editable' : false,
               'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_groupitem_0_description_Description',
               'id' : 'aw58479f32',
               'label' : MessageService.createStaticMessage('Description'),
            });
            groupitem019.addChild( text034 );


            var groupitem020 = new GroupItem({
               'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_groupitem_ServiceRequest.EditLocationView_0',
               'id' : 'awc3ef5de9',
            });
            group006.addChild( groupitem020 );


            var text035 = new Text({
               'resourceAttribute' : 'location',
               'editable' : false,
               'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_groupitem_ServiceRequest.LocationView_0_location_Location',
               'id' : 'aw90179345',
               'label' : MessageService.createStaticMessage('Location'),
            });
            groupitem020.addChild( text035 );


            var text036 = new Text({
               'resourceAttribute' : 'maxlocationdesc',
               'editable' : false,
               'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_groupitem_ServiceRequest.EditLocationView_0_maxlocationdesc',
               'id' : 'aw8a831eda',
            });
            groupitem020.addChild( text036 );


            var groupitem021 = new GroupItem({
               'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_groupitem_ServiceRequest.AssetView_0',
               'id' : 'awab603aac',
            });
            group006.addChild( groupitem021 );


            var text037 = new Text({
               'resourceAttribute' : 'asset',
               'editable' : false,
               'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_groupitem_ServiceRequest.AssetView_0_asset_Asset',
               'id' : 'aw8a71ba1',
               'label' : MessageService.createStaticMessage('Asset'),
            });
            groupitem021.addChild( text037 );


            var text038 = new Text({
               'resourceAttribute' : 'maxassetdesc',
               'editable' : false,
               'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_groupitem_ServiceRequest.EditAssetView_0_maxassetdesc',
               'id' : 'aw32c36b85',
            });
            groupitem021.addChild( text038 );


            var groupitem022 = new GroupItem({
               'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_groupitem_ServiceRequest_reportedpriority_0',
               'id' : 'aw4ced75a3',
            });
            group006.addChild( groupitem022 );


            var text039 = new Text({
               'resourceAttribute' : 'reportedpriority',
               'editable' : false,
               'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_groupitem_ServiceRequest.reportedpriority_0',
               'id' : 'awe3c154cd',
               'label' : MessageService.createStaticMessage('Reported Priority'),
            });
            groupitem022.addChild( text039 );


            var groupitem023 = new GroupItem({
               'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_groupitem_ServiceRequest_reportdate_0',
               'id' : 'aw19e002d4',
            });
            group006.addChild( groupitem023 );


            var text040 = new Text({
               'resourceAttribute' : 'reportdate',
               'editable' : false,
               'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_groupitem_ServiceRequest.reportdate_0',
               'id' : 'aw7e82a7d5',
               'label' : MessageService.createStaticMessage('Reported Date'),
            });
            groupitem023.addChild( text040 );


            var groupitem024 = new GroupItem({
               'layout' : 'Item1Count1Button2',
               'enableFeatureByProperty' : 'attachments.enabled',
               'transitionTo' : 'ServiceRequest.AttachmentsView',
               'artifactId' : 'ServiceRequest.SRDetailView_groupitem_ServiceRequest.AttachmentsView_0',
               'id' : 'aw32f87b05',
            });
            group006.addChild( groupitem024 );


            var text041 = new Text({
               'cssClass' : 'relatedRecords',
               'editable' : false,
               'layoutInsertAt' : 'item1',
               'artifactId' : 'ServiceRequest.SRDetailView_groupitem_ServiceRequest.AttachmentsView_0_Attachments',
               'id' : 'awd9194161',
               'value' : MessageService.createStaticMessage('Attachments'),
            });
            groupitem024.addChild( text041 );


            var text042 = new Text({
               'resourceAttribute' : 'attachmentssize',
               'editable' : false,
               'layoutInsertAt' : 'count1',
               'artifactId' : 'ServiceRequest.SRDetailView_groupitem_ServiceRequest.AttachmentsView_0_attachmentssize',
               'id' : 'awe9c8ae0d',
            });
            groupitem024.addChild( text042 );


            var group007 = new Group({
               'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_group_1',
               'id' : 'aw8d428cb8',
            });
            container013.addChild( group007 );


            var groupitem025 = new GroupItem({
               'layout' : 'Item1Count1Button1',
               'transitionTo' : 'ServiceRequest.WorkLogView',
               'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_group_1_grouptitem1',
               'id' : 'aw187a1d5a',
            });
            group007.addChild( groupitem025 );


            var text043 = new Text({
               'cssClass' : 'relatedRecords',
               'editable' : false,
               'layoutInsertAt' : 'item1',
               'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_group_1_groupitem1_text1',
               'id' : 'aw84ad3d0e',
               'value' : MessageService.createStaticMessage('Work Log'),
            });
            groupitem025.addChild( text043 );


            var text044 = new Text({
               'resourceAttribute' : 'workloglistsize',
               'editable' : false,
               'layoutInsertAt' : 'count1',
               'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_group_1_groupitem1_text2',
               'id' : 'aw1da46cb4',
            });
            groupitem025.addChild( text044 );


            var button012 = new Button({
               'image' : 'action_addNew_OFF.svg',
               'transitionTo' : 'ServiceRequest.NewWorkLogView',
               'layoutInsertAt' : 'button1',
               'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_group_1_button1',
               'id' : 'awee85d6a7',
               'label' : MessageService.createStaticMessage('Create Work Log Entry'),
            });
            var eventHandlers031 = [
               {
                     'method' : 'enableAddWorkLogButton',
                     'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_group_1_enableAddWorkLogButton',
                     'id' : 'aw70f3b308',
                     'event' : 'datachange',
                     'class' : 'application.handlers.WorkLogHandler',
               }
            ];
            button012.eventHandlers = eventHandlers031;
            groupitem025.addChild( button012 );


            var container014 = new Container({
               'resource' : 'serviceRequest',
               'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_container_1',
               'id' : 'aw670a35ee',
            });
            view007.addChild( container014 );

            var eventHandlers032 = [
               {
                     'method' : 'validateFollowupWonum',
                     'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_container_1_eventHandlers_render_validateFollowupWonum',
                     'id' : 'aw7cfc02d0',
                     'event' : 'render',
                     'class' : 'application.handlers.SRDetailHandler',
               }
            ];
            container014.eventHandlers = eventHandlers032;

            var group008 = new Group({
               'artifactId' : 'ServiceRequest.SRDetail_group_1',
               'id' : 'aw359a2944',
            });
            container014.addChild( group008 );


            var groupitem026 = new GroupItem({
               'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_groupitem_ServiceRequest_wonum_1',
               'id' : 'awf778d4cc',
            });
            group008.addChild( groupitem026 );


            var text045 = new Text({
               'resourceAttribute' : 'wonum',
               'editable' : false,
               'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_groupitem_ServiceRequest.wonum_0',
               'id' : 'awe0857554',
               'label' : MessageService.createStaticMessage('Work Order No.'),
            });
            groupitem026.addChild( text045 );


            var groupitem027 = new GroupItem({
               'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_groupitem_ServiceRequest_status_1',
               'id' : 'aw63d8c28e',
            });
            group008.addChild( groupitem027 );


            var text046 = new Text({
               'resourceAttribute' : 'wostatus',
               'editable' : false,
               'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_groupitem_ServiceRequest.wostatus_1',
               'id' : 'aw4df46b05',
               'label' : MessageService.createStaticMessage('Work Order Status'),
            });
            groupitem027.addChild( text046 );


            var groupitem028 = new GroupItem({
               'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_groupitem_ServiceRequest_woowner_1',
               'id' : 'aw8a80d19a',
            });
            group008.addChild( groupitem028 );


            var text047 = new Text({
               'resourceAttribute' : 'woowner',
               'editable' : false,
               'artifactId' : 'ServiceRequest.SRDetail_serviceRequest_groupitem_ServiceRequest.woowner_1',
               'id' : 'aw930b3f3c',
               'label' : MessageService.createStaticMessage('Work Order Owner'),
            });
            groupitem028.addChild( text047 );

            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'ServiceRequest.SRDetailEdit', false);
               trackTimer.startTracking();
            }

            var view008 = new View({
               'showBackButton' : 'true',
               'resource' : 'serviceRequest',
               'id' : 'ServiceRequest.SRDetailEdit',
               'label' : MessageService.createStaticMessage('Service Request Details'),
               'editableView' : 'ServiceRequest.SRDetailEdit',
            });
            ui001.addChild( view008 );

            var requiredResources008 = {
               'serviceRequest' : {
                  'artifactId' : 'ServiceRequest.SRDetailEdit_serviceRequest',
                  'id' : 'awf08846e9',
               },
               'additionalasset' : {
                  'artifactId' : 'ServiceRequest.SRDetailEdit_additionalasset',
                  'id' : 'aw8a09b6fe',
               },
               'domainAssetstatus' : {
                  'artifactId' : 'ServiceRequest.SRDetailEdit_domainAssetstatus',
                  'id' : 'aw8d2a2971',
               },
            };
            view008.addRequiredResources( requiredResources008 );
            var eventHandlers033 = [
               {
                     'method' : 'fetchAllListSizes',
                     'artifactId' : 'ServiceRequest.SRDetailEdit_eventHandlers_initialize_fetchAllListSizes',
                     'id' : 'aw7cf8ca1d',
                     'event' : 'initialize',
                     'class' : 'application.handlers.SRDetailHandler',
               },
               {
                     'method' : 'refreshAllListSizes',
                     'artifactId' : 'ServiceRequest.SRDetailEdit_eventHandlers_render_refreshAllListSizes',
                     'id' : 'aw89b201b8',
                     'event' : 'render',
                     'class' : 'application.handlers.SRDetailHandler',
               }
            ];
            view008.eventHandlers = eventHandlers033;

            var container015 = new Container({
               'resource' : 'serviceRequest',
               'artifactId' : 'ServiceRequest.SRDetailEdit_serviceRequest_container_0',
               'id' : 'aw8cf113e7',
            });
            view008.addChild( container015 );


            var errorIndicator002 = new ErrorIndicator({
               'artifactId' : 'ServiceRequest.SRDetailEdit_errorIndicator',
               'id' : 'aw8c16609d',
            });
            container015.addChild( errorIndicator002 );


            var group009 = new Group({
               'artifactId' : 'ServiceRequest.SRDetailEdit_group_0',
               'id' : 'awb491fcd0',
            });
            container015.addChild( group009 );


            var groupitem029 = new GroupItem({
               'artifactId' : 'ServiceRequest.SRDetailEdit_serviceRequest_groupitem_ServiceRequest_status_0',
               'id' : 'aw8d19233e',
            });
            group009.addChild( groupitem029 );


            var text048 = new Text({
               'resourceAttribute' : 'status',
               'editable' : false,
               'artifactId' : 'ServiceRequest.SRDetailEdit_serviceRequest_groupitem_ServiceRequest.status_0',
               'id' : 'aw6ac1f4a8',
               'label' : MessageService.createStaticMessage('Status'),
            });
            groupitem029.addChild( text048 );


            var groupitem030 = new GroupItem({
               'artifactId' : 'ServiceRequest.SRDetailEdit_serviceRequest_groupitem_ServiceRequest_srnum_0',
               'id' : 'aw4f84d0f',
            });
            group009.addChild( groupitem030 );


            var text049 = new Text({
               'resourceAttribute' : 'srnum',
               'editable' : false,
               'artifactId' : 'ServiceRequest.SRDetailEdit_serviceRequest_groupitem_ServiceRequest.srnum_0',
               'id' : 'aw6402dc01',
               'label' : MessageService.createStaticMessage('Request Number'),
            });
            groupitem030.addChild( text049 );


            var groupitem031 = new GroupItem({
               'artifactId' : 'ServiceRequest.SRDetailEdit_serviceRequest_groupitem_ServiceRequest_owner_0',
               'id' : 'awb32899d4',
            });
            group009.addChild( groupitem031 );


            var text050 = new Text({
               'resourceAttribute' : 'owner',
               'editable' : true,
               'artifactId' : 'ServiceRequest.SRDetailEdit_serviceRequest_groupitem_ServiceRequest.owner_0',
               'id' : 'awd3d208da',
               'label' : MessageService.createStaticMessage('Service Request Owner'),
            });
            groupitem031.addChild( text050 );


            var groupitem032 = new GroupItem({
               'artifactId' : 'ServiceRequest.SRDetailEdit_serviceRequest_groupitem_ServiceRequest_summary_0',
               'id' : 'awe99df90d',
            });
            group009.addChild( groupitem032 );


            var text051 = new Text({
               'resourceAttribute' : 'summary',
               'editable' : true,
               'artifactId' : 'ServiceRequest.SRDetailEdit_serviceRequest_groupitem_ServiceRequest.summary_0',
               'id' : 'awf01617ab',
               'label' : MessageService.createStaticMessage('Summary'),
            });
            groupitem032.addChild( text051 );


            var groupitem033 = new GroupItem({
               'artifactId' : 'ServiceRequest.SRDetailEdit_serviceRequest_groupitem_0',
               'id' : 'awc92a82f4',
            });
            group009.addChild( groupitem033 );


            var textarea002 = new TextArea({
               'resourceAttribute' : 'description',
               'editable' : false,
               'artifactId' : 'ServiceRequest.SRDetailEdit_serviceRequest_groupitem_0_description_Description',
               'id' : 'aw6a4d6792',
               'label' : MessageService.createStaticMessage('Description'),
            });
            groupitem033.addChild( textarea002 );


            var groupitem034 = new GroupItem({
               'transitionTo' : 'ServiceRequest.EditLocationView',
               'artifactId' : 'ServiceRequest.SRDetailEdit_serviceRequest_groupitem_ServiceRequest.EditLocationView_0',
               'id' : 'aw4449065b',
            });
            group009.addChild( groupitem034 );


            var text052 = new Text({
               'resourceAttribute' : 'location',
               'lookup' : 'ServiceRequest.LocationLookup',
               'editable' : true,
               'artifactId' : 'ServiceRequest.SRDetailEdit_serviceRequest_groupitem_ServiceRequest.LocationView_0_location_Location',
               'id' : 'aw7e8e4588',
               'label' : MessageService.createStaticMessage('Location'),
               'codeScannable' : true,
               'lookupAttribute' : 'location',
            });
            groupitem034.addChild( text052 );

            var eventHandlers034 = [
               {
                     'method' : 'asyncvalidateLocation',
                     'artifactId' : 'ServiceRequest.SRDetailEdit_serviceRequest_groupitem_ServiceRequest.EditLocationView_0_location_Location_eventHandlers_validate_asyncvalidateLocation',
                     'id' : 'aw83623369',
                     'event' : 'validate',
                     'class' : 'application.handlers.SRDetailHandler',
               }
            ];
            text052.eventHandlers = eventHandlers034;

            var text053 = new Text({
               'resourceAttribute' : 'maxlocationdesc',
               'editable' : false,
               'artifactId' : 'ServiceRequest.SRDetailEdit_serviceRequest_groupitem_ServiceRequest.EditLocationView_0_maxlocationdesc',
               'id' : 'aw9b672ea1',
            });
            groupitem034.addChild( text053 );


            var groupitem035 = new GroupItem({
               'transitionTo' : 'ServiceRequest.EditAssetView',
               'artifactId' : 'ServiceRequest.SRDetailEdit_serviceRequest_groupitem_ServiceRequest.AssetView_0',
               'id' : 'aw7d8493bc',
            });
            group009.addChild( groupitem035 );


            var text054 = new Text({
               'resourceAttribute' : 'asset',
               'lookup' : 'ServiceRequest.AssetLookup',
               'editable' : true,
               'artifactId' : 'ServiceRequest.SRDetailEdit_serviceRequest_groupitem_ServiceRequest.AssetView_0_asset_Asset',
               'id' : 'awd79be728',
               'label' : MessageService.createStaticMessage('Asset'),
               'codeScannable' : true,
               'lookupAttribute' : 'assetnum',
               'placeHolder' : MessageService.createStaticMessage('Tap to enter'),
            });
            groupitem035.addChild( text054 );

            var eventHandlers035 = [
               {
                     'method' : 'asyncvalidateAsset',
                     'artifactId' : 'ServiceRequest.SRDetailEdit_serviceRequest_groupitem_ServiceRequest.EditAssetView_0_asset_Asset_eventHandlers_validate_asyncvalidateAsset',
                     'id' : 'awdb6fa4cf',
                     'event' : 'validate',
                     'class' : 'application.handlers.SRDetailHandler',
               }
            ];
            text054.eventHandlers = eventHandlers035;

            var text055 = new Text({
               'resourceAttribute' : 'maxassetdesc',
               'editable' : false,
               'artifactId' : 'ServiceRequest.SRDetailEdit_serviceRequest_groupitem_ServiceRequest.EditAssetView_0_maxassetdesc',
               'id' : 'aw6954d55d',
            });
            groupitem035.addChild( text055 );


            var groupitem036 = new GroupItem({
               'artifactId' : 'ServiceRequest.SRDetailEdit_serviceRequest_groupitem_ServiceRequest_reportedpriority_0',
               'id' : 'awcb4b2e11',
            });
            group009.addChild( groupitem036 );


            var text056 = new Text({
               'resourceAttribute' : 'reportedpriority',
               'lookup' : 'ServiceRequest.PriorityLookup',
               'editable' : true,
               'artifactId' : 'ServiceRequest.SRDetailEdit_serviceRequest_groupitem_ServiceRequest.reportedpriority_0',
               'id' : 'aw64670f7f',
               'label' : MessageService.createStaticMessage('Reported Priority'),
               'lookupAttribute' : 'reportedpriority',
               'placeHolder' : MessageService.createStaticMessage('Tap to enter'),
            });
            groupitem036.addChild( text056 );

            var eventHandlers036 = [
               {
                     'method' : 'validatePriority',
                     'artifactId' : 'ServiceRequest.SRDetailEdit_serviceRequest_groupitem_ServiceRequest.EditPriorityView_0_Priority_Priority_eventHandlers_validate_validatePriority',
                     'id' : 'aw64560061',
                     'event' : 'validate',
                     'class' : 'application.handlers.SRDetailHandler',
               }
            ];
            text056.eventHandlers = eventHandlers036;

            var text057 = new Text({
               'resourceAttribute' : 'prioritydesc',
               'editable' : false,
               'artifactId' : 'ServiceRequest.SRDetailEdit_serviceRequest_groupitem_ServiceRequest.EditLocationView_0_prioritydesc',
               'id' : 'aw885323b7',
            });
            groupitem036.addChild( text057 );


            var groupitem037 = new GroupItem({
               'artifactId' : 'ServiceRequest.SRDetailEdit_serviceRequest_groupitem_ServiceRequest_reportdate_0',
               'id' : 'aw481f619',
            });
            group009.addChild( groupitem037 );


            var text058 = new Text({
               'resourceAttribute' : 'reportdate',
               'editable' : true,
               'artifactId' : 'ServiceRequest.SRDetailEdit_serviceRequest_groupitem_ServiceRequest.reportdate_0',
               'id' : 'aw63e35318',
               'label' : MessageService.createStaticMessage('Reported Date'),
            });
            groupitem037.addChild( text058 );


            var groupitem038 = new GroupItem({
               'layout' : 'Item1Count1Button2',
               'enableFeatureByProperty' : 'attachments.enabled',
               'transitionTo' : 'ServiceRequest.AttachmentsView',
               'artifactId' : 'ServiceRequest.SRDetailViewEdit_groupitem_ServiceRequest.AttachmentsView_0',
               'id' : 'aw24f297fd',
            });
            group009.addChild( groupitem038 );


            var text059 = new Text({
               'cssClass' : 'relatedRecords',
               'editable' : false,
               'layoutInsertAt' : 'item1',
               'artifactId' : 'ServiceRequest.SRDetailViewEdit_groupitem_ServiceRequest.AttachmentsView_0_Attachments',
               'id' : 'aw7e4f43d9',
               'value' : MessageService.createStaticMessage('Attachments'),
            });
            groupitem038.addChild( text059 );


            var text060 = new Text({
               'resourceAttribute' : 'attachmentssize',
               'editable' : false,
               'layoutInsertAt' : 'count1',
               'artifactId' : 'ServiceRequest.SRDetailViewEdit_groupitem_ServiceRequest.AttachmentsView_0_attachmentssize',
               'id' : 'aw96d9d08f',
            });
            groupitem038.addChild( text060 );


            var group010 = new Group({
               'artifactId' : 'ServiceRequest.SRDetailEdit_serviceRequest_group_1',
               'id' : 'aw9fc3c180',
            });
            container015.addChild( group010 );


            var groupitem039 = new GroupItem({
               'layout' : 'Item1Count1Button1',
               'transitionTo' : 'ServiceRequest.WorkLogView',
               'artifactId' : 'ServiceRequest.SRDetailEdit_serviceRequest_group_1_grouptitem1',
               'id' : 'aw9c720180',
            });
            group010.addChild( groupitem039 );


            var text061 = new Text({
               'cssClass' : 'relatedRecords',
               'editable' : false,
               'layoutInsertAt' : 'item1',
               'artifactId' : 'ServiceRequest.SRDetailEdit_serviceRequest_group_1_groupitem1_text1',
               'id' : 'awcdbbe26',
               'value' : MessageService.createStaticMessage('Work Log'),
            });
            groupitem039.addChild( text061 );


            var text062 = new Text({
               'resourceAttribute' : 'workloglistsize',
               'editable' : true,
               'layoutInsertAt' : 'count1',
               'artifactId' : 'ServiceRequest.SRDetailEdit_serviceRequest_group_1_groupitem1_text2',
               'id' : 'aw95d2ef9c',
            });
            groupitem039.addChild( text062 );


            var button013 = new Button({
               'image' : 'action_addNew_OFF.svg',
               'transitionTo' : 'ServiceRequest.NewWorkLogView',
               'layoutInsertAt' : 'button1',
               'artifactId' : 'ServiceRequest.SRDetailEdit_serviceRequest_group_1_button1',
               'id' : 'aw52bd8949',
               'label' : MessageService.createStaticMessage('Create Work Log Entry'),
            });
            var eventHandlers037 = [
               {
                     'method' : 'enableAddWorkLogButton',
                     'artifactId' : 'ServiceRequest.SRDetailEdit_serviceRequest_group_1_enableAddWorkLogButton',
                     'id' : 'awcc384b69',
                     'event' : 'datachange',
                     'class' : 'application.handlers.WorkLogHandler',
               }
            ];
            button013.eventHandlers = eventHandlers037;
            groupitem039.addChild( button013 );

            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'ServiceRequest.WorkLogView', false);
               trackTimer.startTracking();
            }

            var view009 = new View({
               'id' : 'ServiceRequest.WorkLogView',
               'label' : MessageService.createStaticMessage('Work Log'),
            });
            ui001.addChild( view009 );

            var requiredResources009 = {
               'serviceRequest' : {
                  'artifactId' : 'ServiceRequest.WorkLogView_serviceRequest',
                  'id' : 'awe6330b13',
                  'related' : {
                     'workloglist' : {
                        'reload' : false,
                        'artifactId' : 'ServiceRequest.WorkLogView_serviceRequest_workloglist',
                        'id' : 'awf87e2274',
                     },
                  },
               },
            };
            view009.addRequiredResources( requiredResources009 );

            var actions004 = new Actions({
               'artifactId' : 'ServiceRequest.WorkLogView_actions',
               'id' : 'aw139363de',
            });
            view009.addChild( actions004 );


            var action005 = new Action({
               'image' : 'header_add_OFF.svg',
               'transitionTo' : 'ServiceRequest.NewWorkLogView',
               'artifactId' : 'ServiceRequest.WorkLogView_CreateWorkLogEntry_action',
               'id' : 'aw48abe4a0',
               'label' : MessageService.createStaticMessage('Create Work Log Entry'),
            });
            actions004.addChild( action005 );

            var eventHandlers038 = [
               {
                     'method' : 'enableAddWorkLogButton',
                     'artifactId' : 'ServiceRequest.WorkLogView_CreateWorkLogEntry_action_eventHandlers_render_enableAddWorkLogButton',
                     'id' : 'awfa091085',
                     'event' : 'render',
                     'class' : 'application.handlers.WorkLogHandler',
               }
            ];
            action005.eventHandlers = eventHandlers038;


            var sortOptions002 = new SortOptions({
               'artifactId' : 'ServiceRequest.WorkLogView_serviceRequest_workloglist_list_sortOptions',
               'id' : 'aw4837436a',
            });

            var sortOption002 = new SortOption({
               'artifactId' : 'ServiceRequest.WorkLogView_sortOption_CreatedDate',
               'id' : 'awda1724e5',
               'label' : MessageService.createStaticMessage('Created Date'),
            });
            sortOptions002.addChild( sortOption002 );


            var sortAttribute002 = new SortAttribute({
               'name' : 'createdateISO',
               'artifactId' : 'ServiceRequest.WorkLogView_CreatedDate_sortAttribute_createdate',
               'id' : 'aw8d7388b4',
               'direction' : 'asc',
            });
            sortOption002.addChild( sortAttribute002 );


            var sortOption003 = new SortOption({
               'artifactId' : 'ServiceRequest.WorkLogView_sortOption_CreatedBy',
               'id' : 'awbbd0c5ca',
               'label' : MessageService.createStaticMessage('Created By'),
            });
            sortOptions002.addChild( sortOption003 );


            var sortAttribute003 = new SortAttribute({
               'name' : 'createby',
               'artifactId' : 'ServiceRequest.WorkLogView_CreatedBy_sortAttribute_createby',
               'id' : 'aw91a470a5',
               'direction' : 'asc',
            });
            sortOption003.addChild( sortAttribute003 );



            var listItemTemplate002 = new ListItemTemplate({
               'layout' : 'WorkLogListItem',
               'artifactId' : 'ServiceRequest.WorkLogView_serviceRequest_workloglist_listItemTemplate_WorkLogListItem',
               'id' : 'aw3f0c0e9e',
            });

            var listtext006 = new ListText({
               'resourceAttribute' : 'createdate',
               'layoutInsertAt' : 'item1',
               'artifactId' : 'ServiceRequest.WorkLogView_serviceRequest_WorkLogListItem_createdate',
               'id' : 'aw4e7d23c2',
            });
            listItemTemplate002.addChild( listtext006 );


            var listtext007 = new ListText({
               'resourceAttribute' : 'createby',
               'layoutInsertAt' : 'item2',
               'artifactId' : 'ServiceRequest.WorkLogView_serviceRequest_WorkLogListItem_createby',
               'id' : 'aw5cfb7ec2',
            });
            listItemTemplate002.addChild( listtext007 );


            var listtext008 = new ListText({
               'resourceAttribute' : 'summary',
               'cssClass' : 'bold textappearance-medium',
               'layoutInsertAt' : 'item3',
               'artifactId' : 'ServiceRequest.WorkLogView_serviceRequest_WorkLogListItem_summary',
               'id' : 'awd208c20a',
            });
            listItemTemplate002.addChild( listtext008 );



            var list002 = new List({
               'resource' : 'serviceRequest',
               'transitionTo' : 'ServiceRequest.WorkLogDetailView',
               'sortOptions' : sortOptions002,
               'listItemTemplate' : listItemTemplate002,
               'artifactId' : 'ServiceRequest.WorkLogView_serviceRequest_workloglist_list',
               'attribute' : 'workloglist',
               'id' : 'aw9d8e8756',
            });
            view009.addChild( list002 );

            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'ServiceRequest.WorkLogDetailView', false);
               trackTimer.startTracking();
            }

            var view010 = new View({
               'id' : 'ServiceRequest.WorkLogDetailView',
               'label' : MessageService.createStaticMessage('Work Log Entry'),
               'editableView' : 'ServiceRequest.NewWorkLogView',
            });
            ui001.addChild( view010 );

            var requiredResources010 = {
               'serviceRequest' : {
                  'artifactId' : 'ServiceRequest.WorkLogDetailView_serviceRequest',
                  'id' : 'awf6b0fbc7',
                  'related' : {
                     'workloglist' : {
                        'reload' : false,
                        'artifactId' : 'ServiceRequest.WorkLogDetailView_serviceRequest_workloglist',
                        'id' : 'aw8ff5bbf8',
                     },
                  },
               },
            };
            view010.addRequiredResources( requiredResources010 );

            var container016 = new Container({
               'resource' : 'serviceRequest',
               'artifactId' : 'ServiceRequest.WorkLogDetailView_serviceRequest_container_0',
               'attribute' : 'workloglist',
               'id' : 'awe1d093c3',
            });
            view010.addChild( container016 );


            var group011 = new Group({
               'artifactId' : 'ServiceRequest.WorkLogDetailView_group_0',
               'id' : 'aw2297098',
            });
            container016.addChild( group011 );


            var groupitem040 = new GroupItem({
               'artifactId' : 'ServiceRequest.WorkLogDetailView_serviceRequest_groupitem_0',
               'id' : 'awa40b02d0',
            });
            group011.addChild( groupitem040 );


            var text063 = new Text({
               'resourceAttribute' : 'createdate',
               'editable' : false,
               'artifactId' : 'ServiceRequest.WorkLogDetailView_serviceRequest_groupitem_0_createdate',
               'id' : 'aw3ccd3501',
            });
            groupitem040.addChild( text063 );


            var groupitem041 = new GroupItem({
               'artifactId' : 'ServiceRequest.WorkLogDetailView_serviceRequest_groupitem_1',
               'id' : 'awd30c3246',
            });
            group011.addChild( groupitem041 );


            var text064 = new Text({
               'resourceAttribute' : 'createby',
               'editable' : false,
               'artifactId' : 'ServiceRequest.WorkLogDetailView_serviceRequest_groupitem_1_createby_CreatedBy',
               'id' : 'aw12fc5a44',
               'label' : MessageService.createStaticMessage('Created By'),
            });
            groupitem041.addChild( text064 );


            var groupitem042 = new GroupItem({
               'artifactId' : 'ServiceRequest.WorkLogDetailView_serviceRequest_groupitem_2',
               'id' : 'aw4a0563fc',
            });
            group011.addChild( groupitem042 );


            var checkbox002 = new CheckBox({
               'resourceAttribute' : 'clientviewable',
               'editable' : false,
               'artifactId' : 'ServiceRequest.WorkLogDetailView_clientviewable_checkbox',
               'id' : 'aw3fe1e090',
               'label' : MessageService.createStaticMessage('Display to Client'),
            });
            groupitem042.addChild( checkbox002 );


            var groupitem043 = new GroupItem({
               'artifactId' : 'ServiceRequest.WorkLogDetailView_serviceRequest_groupitem_3',
               'id' : 'aw3d02536a',
            });
            group011.addChild( groupitem043 );


            var text065 = new Text({
               'resourceAttribute' : 'logtype',
               'editable' : false,
               'artifactId' : 'ServiceRequest.WorkLogDetailView_serviceRequest_groupitem_3_logtype_Type',
               'id' : 'aw5b0355c4',
               'label' : MessageService.createStaticMessage('Type'),
            });
            groupitem043.addChild( text065 );


            var groupitem044 = new GroupItem({
               'artifactId' : 'ServiceRequest.WorkLogDetailView_serviceRequest_groupitem_4',
               'id' : 'awa366c6c9',
            });
            group011.addChild( groupitem044 );


            var text066 = new Text({
               'resourceAttribute' : 'summary',
               'editable' : false,
               'artifactId' : 'ServiceRequest.WorkLogDetailView_serviceRequest_groupitem_4_summary_Summary',
               'id' : 'awd061da5f',
               'label' : MessageService.createStaticMessage('Summary'),
            });
            groupitem044.addChild( text066 );


            var groupitem045 = new GroupItem({
               'artifactId' : 'ServiceRequest.WorkLogDetailView_serviceRequest_groupitem_5',
               'id' : 'awd461f65f',
            });
            group011.addChild( groupitem045 );


            var text067 = new Text({
               'resourceAttribute' : 'details',
               'cssClass' : 'richText',
               'editable' : false,
               'artifactId' : 'ServiceRequest.WorkLogDetailView_serviceRequest_groupitem_5_details_Details',
               'id' : 'aw720aebff',
               'label' : MessageService.createStaticMessage('Details'),
            });
            groupitem045.addChild( text067 );


            var group012 = new Group({
               'artifactId' : 'ServiceRequest.WorkLogDetailView_group_1',
               'id' : 'aw752e400e',
            });
            container016.addChild( group012 );


            var groupitem046 = new GroupItem({
               'artifactId' : 'ServiceRequest.WorkLogDetailView_serviceRequest_groupitem_6',
               'id' : 'aw4d68a7e5',
            });
            group012.addChild( groupitem046 );


            var lastupdatetext001 = new LastUpdateText({
               'artifactId' : 'ServiceRequest.WorkLogDetailView_lastupdatetext',
               'id' : 'aw3eba1234',
            });
            groupitem046.addChild( lastupdatetext001 );

            var eventHandlers039 = [
               {
                     'method' : 'initWorkLogDetailView',
                     'artifactId' : 'ServiceRequest.WorkLogDetailView_eventHandlers_show_initWorkLogDetailView',
                     'id' : 'awf0305f52',
                     'event' : 'show',
                     'class' : 'application.handlers.WorkLogHandler',
               }
            ];
            view010.eventHandlers = eventHandlers039;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'ServiceRequest.NewWorkLogView', false);
               trackTimer.startTracking();
            }

            var view011 = new View({
               'showOverflow' : false,
               'id' : 'ServiceRequest.NewWorkLogView',
               'label' : MessageService.createStaticMessage('Work Log Entry'),
            });
            ui001.addChild( view011 );

            var requiredResources011 = {
               'serviceRequest' : {
                  'artifactId' : 'ServiceRequest.NewWorkLogView_serviceRequest',
                  'id' : 'aw36cf32d8',
                  'related' : {
                     'workloglist' : {
                        'reload' : false,
                        'artifactId' : 'ServiceRequest.NewWorkLogView_serviceRequest_workloglist',
                        'id' : 'aw941806dd',
                     },
                  },
               },
               'domainlogtype' : {
                  'artifactId' : 'ServiceRequest.NewWorkLogView_domainlogtype',
                  'id' : 'aw2931f185',
               },
            };
            view011.addRequiredResources( requiredResources011 );

            var container017 = new Container({
               'resource' : 'serviceRequest',
               'artifactId' : 'ServiceRequest.NewWorkLogView_serviceRequest_container_0',
               'attribute' : 'workloglist',
               'id' : 'awfa3d2ee6',
            });
            view011.addChild( container017 );


            var group013 = new Group({
               'artifactId' : 'ServiceRequest.NewWorkLogView_group_0',
               'id' : 'aw6eb6f8c0',
            });
            container017.addChild( group013 );


            var groupitem047 = new GroupItem({
               'artifactId' : 'ServiceRequest.NewWorkLogView_serviceRequest_groupitem_0',
               'id' : 'awbfe6bff5',
            });
            group013.addChild( groupitem047 );


            var text068 = new Text({
               'resourceAttribute' : 'createdate',
               'editable' : false,
               'artifactId' : 'ServiceRequest.NewWorkLogView_serviceRequest_groupitem_0_createdate',
               'id' : 'aw5aa65ddc',
            });
            groupitem047.addChild( text068 );


            var groupitem048 = new GroupItem({
               'artifactId' : 'ServiceRequest.NewWorkLogView_serviceRequest_groupitem_1',
               'id' : 'awc8e18f63',
            });
            group013.addChild( groupitem048 );


            var text069 = new Text({
               'resourceAttribute' : 'createby',
               'editable' : false,
               'artifactId' : 'ServiceRequest.NewWorkLogView_serviceRequest_groupitem_1_createby_CreatedBy',
               'id' : 'aw43fc467f',
               'label' : MessageService.createStaticMessage('Created By'),
            });
            groupitem048.addChild( text069 );


            var groupitem049 = new GroupItem({
               'artifactId' : 'ServiceRequest.NewWorkLogView_serviceRequest_groupitem_2',
               'id' : 'aw51e8ded9',
            });
            group013.addChild( groupitem049 );


            var checkbox003 = new CheckBox({
               'resourceAttribute' : 'clientviewable',
               'editable' : true,
               'artifactId' : 'ServiceRequest.NewWorkLogView_clientviewable_checkbox',
               'id' : 'aw22b98f5a',
               'label' : MessageService.createStaticMessage('Display to Client'),
            });
            groupitem049.addChild( checkbox003 );


            var groupitem050 = new GroupItem({
               'artifactId' : 'ServiceRequest.NewWorkLogView_serviceRequest_groupitem_3',
               'id' : 'aw26efee4f',
            });
            group013.addChild( groupitem050 );


            var text070 = new Text({
               'resourceAttribute' : 'logtype',
               'lookup' : 'ServiceRequest.LogTypeLookup',
               'editable' : true,
               'artifactId' : 'ServiceRequest.NewWorkLogView_serviceRequest_groupitem_3_logtype_Type',
               'id' : 'aw2cfc6197',
               'label' : MessageService.createStaticMessage('Type'),
               'lookupAttribute' : 'value',
               'placeHolder' : MessageService.createStaticMessage('Tap to enter'),
               'required' : true,
            });
            groupitem050.addChild( text070 );

            var eventHandlers040 = [
               {
                     'method' : 'validateLogType',
                     'artifactId' : 'ServiceRequest.NewWorkLogView_serviceRequest_groupitem_3_logtype_Type_eventHandlers_validate_validateLogType',
                     'id' : 'aw7aadbf9e',
                     'event' : 'validate',
                     'class' : 'application.handlers.WorkLogHandler',
               }
            ];
            text070.eventHandlers = eventHandlers040;

            var groupitem051 = new GroupItem({
               'artifactId' : 'ServiceRequest.NewWorkLogView_serviceRequest_groupitem_4',
               'id' : 'awb88b7bec',
            });
            group013.addChild( groupitem051 );


            var text071 = new Text({
               'resourceAttribute' : 'summary',
               'editable' : true,
               'artifactId' : 'ServiceRequest.NewWorkLogView_serviceRequest_groupitem_4_summary_Summary',
               'id' : 'aw28b356bb',
               'label' : MessageService.createStaticMessage('Summary'),
               'placeHolder' : MessageService.createStaticMessage('Tap to enter'),
            });
            groupitem051.addChild( text071 );


            var groupitem052 = new GroupItem({
               'artifactId' : 'ServiceRequest.NewWorkLogView_serviceRequest_groupitem_5',
               'id' : 'awcf8c4b7a',
            });
            group013.addChild( groupitem052 );


            var textarea003 = new TextArea({
               'resourceAttribute' : 'details',
               'editable' : true,
               'artifactId' : 'ServiceRequest.NewWorkLogView_details_0',
               'id' : 'aw6d60bd75',
               'label' : MessageService.createStaticMessage('Work Log Details'),
               'placeHolder' : MessageService.createStaticMessage('Tap to enter'),
            });
            groupitem052.addChild( textarea003 );


            var footer004 = new Footer({
               'artifactId' : 'ServiceRequest.NewWorkLogView_footer',
               'id' : 'awf2100741',
            });
            view011.addChild( footer004 );


            var button014 = new Button({
               'artifactId' : 'ServiceRequest.NewWorkLogView_Cancel_button',
               'id' : 'aw5a6e01d5',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers041 = [
               {
                     'method' : 'discardNewWorkLogEntry',
                     'artifactId' : 'ServiceRequest.NewWorkLogView_Cancel_button_eventHandlers_click_discardNewWorkLogEntry',
                     'id' : 'awfdbf8762',
                     'event' : 'click',
                     'class' : 'application.handlers.WorkLogHandler',
               }
            ];
            button014.eventHandlers = eventHandlers041;
            footer004.addChild( button014 );


            var button015 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'ServiceRequest.NewWorkLogView_Create_button',
               'id' : 'awa2c824b9',
               'label' : MessageService.createStaticMessage('Create'),
               'primary' : 'true',
            });
            var eventHandlers042 = [
               {
                     'method' : 'commitWorkLogEntryView',
                     'artifactId' : 'ServiceRequest.NewWorkLogView_Create_button_eventHandlers_click_commitWorkLogEntryView',
                     'id' : 'aw1c61dc30',
                     'event' : 'click',
                     'class' : 'application.handlers.WorkLogHandler',
               }
            ];
            button015.eventHandlers = eventHandlers042;
            footer004.addChild( button015 );

            var eventHandlers043 = [
               {
                     'method' : 'initNewWorkLogEntry',
                     'artifactId' : 'ServiceRequest.NewWorkLogView_eventHandlers_initialize_initNewWorkLogEntry',
                     'id' : 'aw9c027a0',
                     'event' : 'initialize',
                     'class' : 'application.handlers.WorkLogHandler',
               },
               {
                     'method' : 'handleBackButtonClick',
                     'artifactId' : 'ServiceRequest.NewWorkLogView_eventHandlers_cleanup_handleBackButtonClick',
                     'id' : 'aw82eda429',
                     'event' : 'cleanup',
                     'class' : 'application.handlers.WorkLogHandler',
               },
               {
                     'method' : 'showFooter',
                     'artifactId' : 'ServiceRequest.NewWorkLogView_eventHandlers_show_showFooter',
                     'id' : 'aw58feecfb',
                     'event' : 'show',
                     'class' : 'application.handlers.WorkLogHandler',
               }
            ];
            view011.eventHandlers = eventHandlers043;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'ServiceRequest.AttachmentsView', false);
               trackTimer.startTracking();
            }

            var view012 = new View({
               'showOverflow' : true,
               'id' : 'ServiceRequest.AttachmentsView',
               'label' : MessageService.createStaticMessage('Attachments'),
            });
            ui001.addChild( view012 );

            var requiredResources012 = {
               'serviceRequest' : {
                  'artifactId' : 'ServiceRequest.AttachmentsView_serviceRequest',
                  'id' : 'aw18b9f552',
                  'related' : {
                     'attachments' : {
                        'reload' : true,
                        'artifactId' : 'ServiceRequest.AttachmentsView_serviceRequest_attachments',
                        'id' : 'aw5456070f',
                     },
                  },
               },
            };
            view012.addRequiredResources( requiredResources012 );

            var actions005 = new Actions({
               'artifactId' : 'ServiceRequest.AttachmentsView_actions',
               'id' : 'awe0113b63',
            });
            view012.addChild( actions005 );


            var action006 = new Action({
               'image' : '\/images\/header_camera_off.svg',
               'artifactId' : 'ServiceRequest.AttachmentsView_TakePhoto_action',
               'id' : 'aw317be4e8',
               'label' : MessageService.createStaticMessage('Take Photo'),
            });
            actions005.addChild( action006 );

            var eventHandlers044 = [
               {
                     'method' : 'launchCameraForPhoto',
                     'artifactId' : 'ServiceRequest.AttachmentsView_TakePhoto_action_eventHandlers_click_launchCameraForPhoto',
                     'id' : 'aw9bdad1e4',
                     'event' : 'click',
                     'class' : 'platform.handlers.AttachmentHandler',
               },
               {
                     'method' : 'initCategory',
                     'artifactId' : 'ServiceRequest.AttachmentsView_TakePhoto_action_eventHandlers_render_initCategory',
                     'id' : 'awc08cc675',
                     'event' : 'render',
                     'class' : 'application.handlers.SRAttachmentHandler',
               }
            ];
            action006.eventHandlers = eventHandlers044;

            var action007 = new Action({
               'image' : 'header_add_OFF.svg',
               'artifactId' : 'ServiceRequest.AttachmentsView_PickfromGallery_action',
               'id' : 'awbfd5c2ca',
               'label' : MessageService.createStaticMessage('Pick from Gallery'),
            });
            actions005.addChild( action007 );

            var eventHandlers045 = [
               {
                     'method' : 'launchGallery',
                     'artifactId' : 'ServiceRequest.AttachmentsView_PickfromGallery_action_eventHandlers_click_launchGallery',
                     'id' : 'awc88dce45',
                     'event' : 'click',
                     'class' : 'platform.handlers.AttachmentHandler',
               }
            ];
            action007.eventHandlers = eventHandlers045;


            var sortOptions003 = new SortOptions({
               'artifactId' : 'ServiceRequest.AttachmentsView_serviceRequest_attachments_list_sortOptions',
               'id' : 'awd7c1cb66',
            });

            var sortOption004 = new SortOption({
               'artifactId' : 'ServiceRequest.AttachmentsView_sortOption_CreatedDate',
               'id' : 'aw434e7e90',
               'label' : MessageService.createStaticMessage('Created Date'),
            });
            sortOptions003.addChild( sortOption004 );


            var sortAttribute004 = new SortAttribute({
               'name' : 'displayCreationDate',
               'artifactId' : 'ServiceRequest.AttachmentsView_CreatedDate_sortAttribute_displayCreationDate',
               'id' : 'aw8658db19',
               'direction' : 'asc',
            });
            sortOption004.addChild( sortAttribute004 );


            var sortOption005 = new SortOption({
               'artifactId' : 'ServiceRequest.AttachmentsView_sortOption_FileName',
               'id' : 'awa2be7481',
               'label' : MessageService.createStaticMessage('File Name'),
            });
            sortOptions003.addChild( sortOption005 );


            var sortAttribute005 = new SortAttribute({
               'name' : 'displayFileName',
               'artifactId' : 'ServiceRequest.AttachmentsView_FileName_sortAttribute_displayFileName',
               'id' : 'aw788193b3',
               'direction' : 'asc',
            });
            sortOption005.addChild( sortAttribute005 );


            var sortOption006 = new SortOption({
               'artifactId' : 'ServiceRequest.AttachmentsView_sortOption_Description',
               'id' : 'aw7356b20c',
               'label' : MessageService.createStaticMessage('Description'),
            });
            sortOptions003.addChild( sortOption006 );


            var sortAttribute006 = new SortAttribute({
               'name' : 'displayDescription',
               'artifactId' : 'ServiceRequest.AttachmentsView_Description_sortAttribute_displayDescription',
               'id' : 'awb2923ac',
               'direction' : 'asc',
            });
            sortOption006.addChild( sortAttribute006 );



            var listItemTemplate003 = new ListItemTemplate({
               'layout' : 'AttachmentsListItem',
               'artifactId' : 'ServiceRequest.AttachmentsView_serviceRequest_attachments_listItemTemplate_AttachmentsListItem',
               'id' : 'awe1674255',
            });

            var listtext009 = new ListText({
               'resourceAttribute' : 'displayFileName',
               'cssClass' : 'bold textappearance-medium',
               'layoutInsertAt' : 'item1',
               'artifactId' : 'ServiceRequest.AttachmentsView_serviceRequest_AttachmentsListItem_displayFileName',
               'id' : 'aw757542cb',
            });
            listItemTemplate003.addChild( listtext009 );


            var listtext010 = new ListText({
               'resourceAttribute' : 'displayDescription',
               'layoutInsertAt' : 'item2',
               'artifactId' : 'ServiceRequest.AttachmentsView_serviceRequest_AttachmentsListItem_displayDescription',
               'id' : 'aw8bf13080',
            });
            listItemTemplate003.addChild( listtext010 );


            var listtext011 = new ListText({
               'resourceAttribute' : 'displayFileType',
               'layoutInsertAt' : 'item3',
               'artifactId' : 'ServiceRequest.AttachmentsView_serviceRequest_AttachmentsListItem_displayFileType',
               'id' : 'awa7886be4',
            });
            listItemTemplate003.addChild( listtext011 );


            var button016 = new Button({
               'border' : 'false',
               'resourceAttribute' : 'anywhereAttachDownloaded',
               'image' : '\/images\/msg_downloadComplete_small.svg',
               'cssClass' : 'attachmentIcon',
               'layoutInsertAt' : 'icon',
               'artifactId' : 'ServiceRequest.AttachmentsView_serviceRequest_anywhereAttachDownloaded_imagesmsg_downloadComplete_small.svg_button',
               'id' : 'aw706417a1',
            });
            var eventHandlers046 = [
               {
                     'method' : 'displayLocal',
                     'artifactId' : 'ServiceRequest.AttachmentsView_serviceRequest_anywhereAttachDownloaded_imagesmsg_downloadComplete_small.svg_button_eventHandlers_datachange_displayLocal',
                     'id' : 'aw7bb66bba',
                     'event' : 'datachange',
                     'class' : 'application.handlers.SRAttachmentHandler',
               },
               {
                     'method' : 'handleThumbnailClick',
                     'artifactId' : 'ServiceRequest.AttachmentsView_serviceRequest_anywhereAttachDownloaded_imagesmsg_downloadComplete_small.svg_button_eventHandlers_click_handleThumbnailClick',
                     'id' : 'aw9590a7e7',
                     'event' : 'click',
                     'class' : 'application.handlers.SRAttachmentHandler',
               }
            ];
            button016.eventHandlers = eventHandlers046;
            listItemTemplate003.addChild( button016 );


            var listtext012 = new ListText({
               'resourceAttribute' : 'displaySize',
               'layoutInsertAt' : 'item4',
               'artifactId' : 'ServiceRequest.AttachmentsView_serviceRequest_AttachmentsListItem_displaySize',
               'id' : 'aw2fc65c5d',
            });
            listItemTemplate003.addChild( listtext012 );


            var listtext013 = new ListText({
               'resourceAttribute' : 'createby',
               'layoutInsertAt' : 'item5',
               'artifactId' : 'ServiceRequest.AttachmentsView_serviceRequest_AttachmentsListItem_createby',
               'id' : 'aw26e7adaa',
            });
            listItemTemplate003.addChild( listtext013 );


            var listtext014 = new ListText({
               'resourceAttribute' : 'displayCreationDate',
               'layoutInsertAt' : 'item6',
               'artifactId' : 'ServiceRequest.AttachmentsView_serviceRequest_AttachmentsListItem_displayCreationDate',
               'id' : 'aw3ae7f7c',
            });
            listItemTemplate003.addChild( listtext014 );

            var eventHandlers047 = [
               {
                     'method' : 'handleThumbnailClick',
                     'artifactId' : 'ServiceRequest.AttachmentsView_serviceRequest_attachments_listItemTemplate_AttachmentsListItem_eventHandlers_click_handleThumbnailClick',
                     'id' : 'awceadc62c',
                     'event' : 'click',
                     'class' : 'application.handlers.SRAttachmentHandler',
               }
            ];
            listItemTemplate003.eventHandlers = eventHandlers047;


            var list003 = new List({
               'resource' : 'serviceRequest',
               'sortOptions' : sortOptions003,
               'listItemTemplate' : listItemTemplate003,
               'artifactId' : 'ServiceRequest.AttachmentsView_serviceRequest_attachments_list',
               'attribute' : 'attachments',
               'id' : 'awb08ced39',
            });
            view012.addChild( list003 );

            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            var dialog004 = new Dialog({
               'id' : 'ServiceRequest.SRAssetToLocationDialog',
            });
            ui001.addChild( dialog004 );


            var container018 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'ServiceRequest.SRAssetToLocationDialog_container_0',
               'id' : 'aw6997952e',
            });
            dialog004.addChild( container018 );


            var text072 = new Text({
               'artifactId' : 'ServiceRequest.SRAssetToLocationDialog_container_0_Theassetisinloca',
               'id' : 'awe08374e1',
               'value' : MessageService.createDynamicMessage('The asset is in location {0}. Replace the current location with location {1}? If you do not want to update the current asset, click Close.', 'application.handlers.SRDetailHandler', 'resolveAssetLocation'),
               'resolverFunction' : 'resolveAssetLocation',
               'resolverClass' : 'application.handlers.SRDetailHandler',
            });
            container018.addChild( text072 );


            var container019 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'ServiceRequest.SRAssetToLocationDialog_container_1',
               'id' : 'aw1e90a5b8',
            });
            dialog004.addChild( container019 );


            var button017 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'ServiceRequest.SRAssetToLocationDialog_Yes_button',
               'id' : 'awf1b06bc1',
               'label' : MessageService.createStaticMessage('Yes'),
            });
            var eventHandlers048 = [
               {
                     'method' : 'asyncyesOnSRAssetToLocation',
                     'artifactId' : 'ServiceRequest.SRAssetToLocationDialog_Yes_button_eventHandlers_click_asyncyesOnSRAssetToLocation',
                     'id' : 'awba073978',
                     'event' : 'click',
                     'class' : 'application.handlers.SRDetailHandler',
               }
            ];
            button017.eventHandlers = eventHandlers048;
            container019.addChild( button017 );


            var button018 = new Button({
               'artifactId' : 'ServiceRequest.SRAssetToLocationDialog_Close_button',
               'id' : 'awda4cfcab',
               'label' : MessageService.createStaticMessage('Close'),
            });
            var eventHandlers049 = [
               {
                     'method' : 'closeOnSRAssetToLocation',
                     'artifactId' : 'ServiceRequest.SRAssetToLocationDialog_Close_button_eventHandlers_click_closeOnSRAssetToLocation',
                     'id' : 'awc098f1f3',
                     'event' : 'click',
                     'class' : 'application.handlers.SRDetailHandler',
               }
            ];
            button018.eventHandlers = eventHandlers049;
            container019.addChild( button018 );


            var button019 = new Button({
               'artifactId' : 'ServiceRequest.SRAssetToLocationDialog_No_button',
               'id' : 'aw36365089',
               'label' : MessageService.createStaticMessage('No'),
            });
            var eventHandlers050 = [
               {
                     'method' : 'noOnSRAssetToLocation',
                     'artifactId' : 'ServiceRequest.SRAssetToLocationDialog_No_button_eventHandlers_click_noOnSRAssetToLocation',
                     'id' : 'awc8137477',
                     'event' : 'click',
                     'class' : 'application.handlers.SRDetailHandler',
               }
            ];
            button019.eventHandlers = eventHandlers050;
            container019.addChild( button019 );


            var dialog005 = new Dialog({
               'id' : 'ServiceRequest.SRLocationToAssetDialog',
            });
            ui001.addChild( dialog005 );


            var container020 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'ServiceRequest.WOLocationToAssetDialog_container_0',
               'id' : 'awbf7e7896',
            });
            dialog005.addChild( container020 );


            var text073 = new Text({
               'artifactId' : 'ServiceRequest.WOLocationToAssetDialog_container_0_Thespecifiedlocati',
               'id' : 'aw687c5a09',
               'value' : MessageService.createDynamicMessage('The specified location does not match the location of asset {0}. Clear the current asset? If you do not want to update the current location, click Close.', 'application.handlers.SRDetailHandler', 'resolveExistingAsset'),
               'resolverFunction' : 'resolveExistingAsset',
               'resolverClass' : 'application.handlers.SRDetailHandler',
            });
            container020.addChild( text073 );


            var container021 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'ServiceRequest.SRLocationToAssetDialog_container_1',
               'id' : 'aw2cbd981e',
            });
            dialog005.addChild( container021 );


            var button020 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'ServiceRequest.SRLocationToAssetDialog_Yes_button',
               'id' : 'aw4e12eed',
               'label' : MessageService.createStaticMessage('Yes'),
            });
            var eventHandlers051 = [
               {
                     'method' : 'asyncYesOnSRLocationToAsset',
                     'artifactId' : 'ServiceRequest.SRLocationToAssetDialog_Yes_button_eventHandlers_click_asyncYesOnSRLocationToAsset',
                     'id' : 'aw32e707a9',
                     'event' : 'click',
                     'class' : 'application.handlers.SRDetailHandler',
               }
            ];
            button020.eventHandlers = eventHandlers051;
            container021.addChild( button020 );


            var button021 = new Button({
               'artifactId' : 'ServiceRequest.SRLocationToAssetDialog_Close_button',
               'id' : 'awe5cbd74b',
               'label' : MessageService.createStaticMessage('Close'),
            });
            var eventHandlers052 = [
               {
                     'method' : 'closeOnSRLocationToAsset',
                     'artifactId' : 'ServiceRequest.SRLocationToAssetDialog_Close_button_eventHandlers_click_closeOnSRLocationToAsset',
                     'id' : 'awf5bc92bf',
                     'event' : 'click',
                     'class' : 'application.handlers.SRDetailHandler',
               }
            ];
            button021.eventHandlers = eventHandlers052;
            container021.addChild( button021 );


            var button022 = new Button({
               'artifactId' : 'ServiceRequest.SRLocationToAssetDialog_No_button',
               'id' : 'aw68b72bde',
               'label' : MessageService.createStaticMessage('No'),
            });
            var eventHandlers053 = [
               {
                     'method' : 'noOnSRLocationToAsset',
                     'artifactId' : 'ServiceRequest.SRLocationToAssetDialog_No_button_eventHandlers_click_noOnSRLocationToAsset',
                     'id' : 'aw9cf77fbc',
                     'event' : 'click',
                     'class' : 'application.handlers.SRDetailHandler',
               }
            ];
            button022.eventHandlers = eventHandlers053;
            container021.addChild( button022 );


            var dialog006 = new Dialog({
               'id' : 'ServiceRequest.SRCommitConfirm',
            });
            ui001.addChild( dialog006 );


            var container022 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'ServiceRequest_SRCommitConfirm',
               'id' : 'awdd901a18',
            });
            dialog006.addChild( container022 );


            var text074 = new Text({
               'artifactId' : 'ServiceRequest.SRCommitConfirm_container_0',
               'id' : 'aw279092ba',
               'value' : MessageService.createStaticMessage('The Service Request was created successfully.'),
            });
            container022.addChild( text074 );


            var container023 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'ServiceRequest.SRCommitConfirm_container_1',
               'id' : 'aw5097a22c',
            });
            dialog006.addChild( container023 );


            var button023 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'ServiceRequest.SRCommitConfirm_button',
               'id' : 'awad5f878e',
               'label' : MessageService.createStaticMessage('Ok'),
            });
            var eventHandlers054 = [
               {
                     'method' : 'okOnSRCommitConfirm',
                     'artifactId' : 'ServiceRequest.SRCommitConfirm_button_eventHandlers_click_okOnSRCommitConfirm',
                     'id' : 'aw24eceaa',
                     'event' : 'click',
                     'class' : 'application.handlers.SRDetailHandler',
               }
            ];
            button023.eventHandlers = eventHandlers054;
            container023.addChild( button023 );


            var dialog007 = new Dialog({
               'id' : 'ServiceRequest.ConfirmCancel',
            });
            ui001.addChild( dialog007 );


            var container024 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'ServiceRequest.ConfirmCancel_container_0',
               'id' : 'awc9112045',
            });
            dialog007.addChild( container024 );


            var text075 = new Text({
               'artifactId' : 'ServiceRequest.ConfirmCancel_container_0_Areyousure',
               'id' : 'aw3bf661ed',
               'value' : MessageService.createStaticMessage('Are you sure you wish to Cancel?  All changes to this request will be lost.'),
            });
            container024.addChild( text075 );


            var container025 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'ServiceRequest.ConfirmCancel_container_1',
               'id' : 'awbe1610d3',
            });
            dialog007.addChild( container025 );


            var button024 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'ServiceRequest.ConfirmCancel_Yes_button',
               'id' : 'aw7de77821',
               'label' : MessageService.createStaticMessage('Yes'),
            });
            var eventHandlers055 = [
               {
                     'method' : 'yesOnCancel',
                     'artifactId' : 'ServiceRequest.ConfirmCancel_Yes_button_eventHandlers_click_yesOnCancel',
                     'id' : 'aw7065d268',
                     'event' : 'click',
                     'class' : 'application.handlers.SRDetailHandler',
               }
            ];
            button024.eventHandlers = eventHandlers055;
            container025.addChild( button024 );


            var button025 = new Button({
               'artifactId' : 'ServiceRequest.ConfirmCancel_No_button',
               'id' : 'awb25943d7',
               'label' : MessageService.createStaticMessage('No'),
            });
            var eventHandlers056 = [
               {
                     'method' : 'noOnCancel',
                     'artifactId' : 'ServiceRequest.ConfirmCancel_No_button_eventHandlers_click_noOnCancel',
                     'id' : 'aw9b0ffb9f',
                     'event' : 'click',
                     'class' : 'application.handlers.SRDetailHandler',
               }
            ];
            button025.eventHandlers = eventHandlers056;
            container025.addChild( button025 );


            var dialog008 = new Dialog({
               'resource' : 'PlatformProgressResource',
               'id' : 'ServiceRequest.DownloadAttachmentLocal',
            });
            ui001.addChild( dialog008 );


            var container026 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'ServiceRequest.DownloadAttachmentLocal_container_0',
               'id' : 'aw2a815ceb',
            });
            dialog008.addChild( container026 );


            var text076 = new Text({
               'resourceAttribute' : 'progressMsg',
               'editable' : false,
               'artifactId' : 'ServiceRequest.DownloadAttachmentLocal_container_0_progressMsg',
               'id' : 'aw7e5b6b4f',
            });
            container026.addChild( text076 );


            var container027 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'ServiceRequest.DownloadAttachmentLocal_container_1',
               'id' : 'aw5d866c7d',
            });
            dialog008.addChild( container027 );


            var button026 = new Button({
               'artifactId' : 'ServiceRequest.DownloadAttachmentLocal_Cancel_button',
               'id' : 'awfd4126ce',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers057 = [
               {
                     'method' : 'cancelDownload',
                     'artifactId' : 'ServiceRequest.DownloadAttachmentLocal_Cancel_button_eventHandlers_click_cancelDownload',
                     'id' : 'awefda4d0',
                     'event' : 'click',
                     'class' : 'application.handlers.SRAttachmentHandler',
               }
            ];
            button026.eventHandlers = eventHandlers057;
            container027.addChild( button026 );


            var lookup001 = new Lookup({
               'filterMethod' : 'filterLocationForLookup',
               'resource' : 'additionallocations',
               'filterClass' : 'application.handlers.SRDetailHandler',
               'id' : 'ServiceRequest.LocationLookup',
               'label' : MessageService.createStaticMessage('Select Location'),
            });
            ui001.addChild( lookup001 );

            var requiredResources013 = {
               'additionallocations' : {
                  'artifactId' : 'ServiceRequest.LocationLookup_additionallocations',
                  'id' : 'aw78c5c3a6',
               },
            };
            lookup001.addRequiredResources( requiredResources013 );


            var searchAttributes001 = new SearchAttributes({
               'artifactId' : 'ServiceRequest.LocationLookup_additionallocations_searchAttributes',
               'id' : 'aw271d2079',
            });

            var searchAttribute001 = new SearchAttribute({
               'name' : 'location',
               'artifactId' : 'ServiceRequest.LocationLookup_additionallocations_searchAttribute_location',
               'id' : 'aw8a50a90a',
            });
            searchAttributes001.addChild( searchAttribute001 );


            var searchAttribute002 = new SearchAttribute({
               'name' : 'description',
               'artifactId' : 'ServiceRequest.LocationLookup_additionallocations_searchAttribute_description',
               'id' : 'aw14d17790',
            });
            searchAttributes001.addChild( searchAttribute002 );



            var listItemTemplate004 = new ListItemTemplate({
               'layout' : 'Item1Desc1',
               'artifactId' : 'ServiceRequest.LocationLookup_additionallocations_listItemTemplate_Item1Desc1',
               'id' : 'awa824e1ab',
            });

            var listtext015 = new ListText({
               'resourceAttribute' : 'location',
               'cssClass' : 'bold textappearance-medium',
               'layoutInsertAt' : 'item1',
               'artifactId' : 'ServiceRequest.LocationLookup_additionallocations_Item1Desc1_location',
               'id' : 'aw6771610',
            });
            listItemTemplate004.addChild( listtext015 );


            var listtext016 = new ListText({
               'resourceAttribute' : 'description',
               'cssClass' : 'bold textappearance-medium',
               'layoutInsertAt' : 'desc1',
               'artifactId' : 'ServiceRequest.LocationLookup_additionallocations_Item1Desc1_description',
               'id' : 'awc33756a6',
            });
            listItemTemplate004.addChild( listtext016 );



            var list004 = new List({
               'resource' : 'additionallocations',
               'listItemTemplate' : listItemTemplate004,
               'artifactId' : 'ServiceRequest.LocationLookup_additionallocations_list',
               'id' : 'awf2f00488',
               'searchAttributes' : searchAttributes001,
            });
            lookup001.addChild( list004 );


            var returnAttributes001 = new ReturnAttributes({
               'artifactId' : 'ServiceRequest.LocationLookup_returnAttributes',
               'id' : 'aw5095c534',
            });
            lookup001.addChild( returnAttributes001 );


            var returnAttribute001 = new ReturnAttribute({
               'targetAttribute' : 'location',
               'artifactId' : 'ServiceRequest.LocationLookup_location_location',
               'id' : 'awd058f566',
               'sourceAttribute' : 'location',
            });
            returnAttributes001.addChild( returnAttribute001 );


            var returnAttribute002 = new ReturnAttribute({
               'targetAttribute' : 'locationdesc',
               'artifactId' : 'ServiceRequest.LocationLookup_description_locationdesc',
               'id' : 'aw6c550e8c',
               'sourceAttribute' : 'description',
            });
            returnAttributes001.addChild( returnAttribute002 );


            var lookup002 = new Lookup({
               'filterMethod' : 'filterAssetForLookup',
               'resource' : 'additionalasset',
               'filterClass' : 'application.handlers.SRDetailHandler',
               'id' : 'ServiceRequest.AssetLookup',
               'label' : MessageService.createStaticMessage('Select Asset'),
            });
            ui001.addChild( lookup002 );

            var requiredResources014 = {
               'additionalasset' : {
                  'artifactId' : 'ServiceRequest.AssetLookup_additionalasset',
                  'id' : 'awc83631a6',
               },
               'serviceRequest' : {
                  'artifactId' : 'ServiceRequest.AssetLookup_serviceRequest',
                  'id' : 'aw7d9772c0',
               },
            };
            lookup002.addRequiredResources( requiredResources014 );


            var searchAttributes002 = new SearchAttributes({
               'artifactId' : 'ServiceRequest.AssetLookup_additionalasset_searchAttributes',
               'id' : 'aw5225b0cf',
            });

            var searchAttribute003 = new SearchAttribute({
               'name' : 'assetnum',
               'artifactId' : 'ServiceRequest.AssetLookup_additionalasset_searchAttribute_assetnum',
               'id' : 'aw4d5c10bd',
            });
            searchAttributes002.addChild( searchAttribute003 );


            var searchAttribute004 = new SearchAttribute({
               'name' : 'description',
               'artifactId' : 'ServiceRequest.AssetLookup_additionalasset_searchAttribute_description',
               'id' : 'aw131db687',
            });
            searchAttributes002.addChild( searchAttribute004 );


            var searchAttribute005 = new SearchAttribute({
               'name' : 'location',
               'artifactId' : 'ServiceRequest.AssetLookup_additionalasset_searchAttribute_location',
               'id' : 'awac1aea69',
            });
            searchAttributes002.addChild( searchAttribute005 );


            var searchAttribute006 = new SearchAttribute({
               'name' : 'locationdesc',
               'artifactId' : 'ServiceRequest.AssetLookup_additionalasset_searchAttribute_locationdesc',
               'id' : 'aw86a354b3',
            });
            searchAttributes002.addChild( searchAttribute006 );



            var listItemTemplate005 = new ListItemTemplate({
               'layout' : 'Item2Desc2',
               'artifactId' : 'ServiceRequest.AssetLookup_additionalasset_listItemTemplate_Item2Desc2',
               'id' : 'awb07503a8',
            });

            var listtext017 = new ListText({
               'resourceAttribute' : 'assetnum',
               'cssClass' : 'bold textappearance-medium',
               'layoutInsertAt' : 'item1',
               'artifactId' : 'ServiceRequest.AssetLookup_additionalasset_Item2Desc2_assetnum',
               'id' : 'aw85eb8ded',
            });
            listItemTemplate005.addChild( listtext017 );


            var listtext018 = new ListText({
               'resourceAttribute' : 'description',
               'cssClass' : 'bold textappearance-medium',
               'layoutInsertAt' : 'desc1',
               'artifactId' : 'ServiceRequest.AssetLookup_additionalasset_Item2Desc2_description',
               'id' : 'awee4b4a87',
            });
            listItemTemplate005.addChild( listtext018 );


            var listtext019 = new ListText({
               'resourceAttribute' : 'location',
               'layoutInsertAt' : 'item2',
               'artifactId' : 'ServiceRequest.AssetLookup_additionalasset_Item2Desc2_location',
               'id' : 'aw64ad7739',
            });
            listItemTemplate005.addChild( listtext019 );


            var listtext020 = new ListText({
               'resourceAttribute' : 'locationdesc',
               'layoutInsertAt' : 'desc2',
               'artifactId' : 'ServiceRequest.AssetLookup_additionalasset_Item2Desc2_locationdesc',
               'id' : 'aw865e024f',
            });
            listItemTemplate005.addChild( listtext020 );



            var list005 = new List({
               'resource' : 'additionalasset',
               'listItemTemplate' : listItemTemplate005,
               'artifactId' : 'ServiceRequest.AssetLookup_additionalasset_list',
               'id' : 'aw8dd8b995',
               'searchAttributes' : searchAttributes002,
            });
            lookup002.addChild( list005 );


            var returnAttributes002 = new ReturnAttributes({
               'artifactId' : 'ServiceRequest.AssetLookup_returnAttributes',
               'id' : 'aw6d2b97c9',
            });
            lookup002.addChild( returnAttributes002 );


            var returnAttribute003 = new ReturnAttribute({
               'targetAttribute' : 'asset',
               'artifactId' : 'ServiceRequest.AssetLookup_assetnum_asset',
               'id' : 'awa7ce92bc',
               'sourceAttribute' : 'assetnum',
            });
            returnAttributes002.addChild( returnAttribute003 );


            var returnAttribute004 = new ReturnAttribute({
               'targetAttribute' : 'assetdesc',
               'artifactId' : 'ServiceRequest.AssetLookup_description_assetdesc',
               'id' : 'aw6007b71d',
               'sourceAttribute' : 'description',
            });
            returnAttributes002.addChild( returnAttribute004 );


            var lookup003 = new Lookup({
               'resource' : 'priorityDomain',
               'id' : 'ServiceRequest.PriorityLookup',
               'label' : MessageService.createStaticMessage('Select Priority'),
            });
            ui001.addChild( lookup003 );

            var requiredResources015 = {
               'priorityDomain' : {
                  'artifactId' : 'ServiceRequest.PriorityLookup_priorityDomain',
                  'id' : 'aw91fc8202',
               },
            };
            lookup003.addRequiredResources( requiredResources015 );


            var listItemTemplate006 = new ListItemTemplate({
               'layout' : 'Item1Desc1',
               'artifactId' : 'ServiceRequest.PriorityLookup_priorityDomain_listItemTemplate_Item1Desc1',
               'id' : 'aw36870f66',
            });

            var listtext021 = new ListText({
               'resourceAttribute' : 'value',
               'cssClass' : 'bold textappearance-medium',
               'layoutInsertAt' : 'item1',
               'artifactId' : 'ServiceRequest.PriorityLookup_priorityDomain_Item1Desc1_value',
               'id' : 'aw607ff7a2',
            });
            listItemTemplate006.addChild( listtext021 );


            var listtext022 = new ListText({
               'resourceAttribute' : 'description',
               'cssClass' : 'bold textappearance-medium',
               'layoutInsertAt' : 'desc1',
               'artifactId' : 'ServiceRequest.PriorityLookup_priorityDomain_Item1Desc1_description',
               'id' : 'awcd316ed3',
            });
            listItemTemplate006.addChild( listtext022 );



            var list006 = new List({
               'resource' : 'priorityDomain',
               'listItemTemplate' : listItemTemplate006,
               'artifactId' : 'ServiceRequest.PriorityLookup_priorityDomain_list',
               'id' : 'awf0f9943c',
            });
            lookup003.addChild( list006 );


            var returnAttributes003 = new ReturnAttributes({
               'artifactId' : 'ServiceRequest.PriorityLookup_returnAttributes',
               'id' : 'awa4296688',
            });
            lookup003.addChild( returnAttributes003 );


            var returnAttribute005 = new ReturnAttribute({
               'targetAttribute' : 'reportedpriority',
               'artifactId' : 'ServiceRequest.PriorityLookup_value_reportedpriority',
               'id' : 'aw29e263aa',
               'sourceAttribute' : 'value',
            });
            returnAttributes003.addChild( returnAttribute005 );


            var returnAttribute006 = new ReturnAttribute({
               'targetAttribute' : 'prioritydesc',
               'artifactId' : 'ServiceRequest.priorityLookup_description_prioritydesc',
               'id' : 'awe2b0ad8f',
               'sourceAttribute' : 'description',
            });
            returnAttributes003.addChild( returnAttribute006 );


            var lookup004 = new Lookup({
               'resource' : 'appDocType',
               'id' : 'ServiceRequest.appDocTypeLookup',
               'label' : MessageService.createStaticMessage('Select Value'),
            });
            ui001.addChild( lookup004 );

            var requiredResources016 = {
               'appDocType' : {
                  'artifactId' : 'ServiceRequest.appDocTypeLookup_appDocType',
                  'id' : 'aw203f2059',
               },
            };
            lookup004.addRequiredResources( requiredResources016 );


            var listItemTemplate007 = new ListItemTemplate({
               'artifactId' : 'ServiceRequest.appDocTypeLookup_appDocType_listItemTemplate',
               'id' : 'aw18240c78',
            });

            var listtext023 = new ListText({
               'resourceAttribute' : 'doctype',
               'cssClass' : 'bold textappearance-medium',
               'artifactId' : 'ServiceRequest.appDocTypeLookup_appDocType_doctype',
               'id' : 'awad4e25df',
            });
            listItemTemplate007.addChild( listtext023 );



            var list007 = new List({
               'resource' : 'appDocType',
               'listItemTemplate' : listItemTemplate007,
               'artifactId' : 'ServiceRequest.appDocTypeLookup_appDocType_list',
               'id' : 'aw366f0c88',
            });
            lookup004.addChild( list007 );


            var returnAttributes004 = new ReturnAttributes({
               'artifactId' : 'ServiceRequest.appDocTypeLookup_returnAttributes',
               'id' : 'awed809c3b',
            });
            lookup004.addChild( returnAttributes004 );


            var returnAttribute007 = new ReturnAttribute({
               'targetAttribute' : 'category',
               'artifactId' : 'ServiceRequest.appDocTypeLookup_doctype_category',
               'id' : 'aw8c5c050',
               'sourceAttribute' : 'doctype',
            });
            returnAttributes004.addChild( returnAttribute007 );


            var lookup005 = new Lookup({
               'resource' : 'domainlogtype',
               'id' : 'ServiceRequest.LogTypeLookup',
               'label' : MessageService.createStaticMessage('Select Log Type'),
            });
            ui001.addChild( lookup005 );

            var requiredResources017 = {
               'domainlogtype' : {
                  'reload' : true,
                  'artifactId' : 'ServiceRequest.LogTypeLookup_domainlogtype',
                  'id' : 'aw2ab896c4',
               },
            };
            lookup005.addRequiredResources( requiredResources017 );


            var searchAttributes003 = new SearchAttributes({
               'artifactId' : 'ServiceRequest.LogTypeLookup_domainlogtype_searchAttributes',
               'id' : 'awef35552',
            });

            var searchAttribute007 = new SearchAttribute({
               'name' : 'value',
               'artifactId' : 'ServiceRequest.LogTypeLookup_domainlogtype_searchAttribute_value',
               'id' : 'awfa181e45',
            });
            searchAttributes003.addChild( searchAttribute007 );


            var searchAttribute008 = new SearchAttribute({
               'name' : 'description',
               'artifactId' : 'ServiceRequest.LogTypeLookup_domainlogtype_searchAttribute_description',
               'id' : 'awb5c112db',
            });
            searchAttributes003.addChild( searchAttribute008 );



            var listItemTemplate008 = new ListItemTemplate({
               'layout' : 'Item1Desc1',
               'artifactId' : 'ServiceRequest.LogTypeLookup_domainlogtype_listItemTemplate_Item1Desc1',
               'id' : 'aw93484e0',
            });

            var listtext024 = new ListText({
               'resourceAttribute' : 'value',
               'cssClass' : 'bold textappearance-medium',
               'layoutInsertAt' : 'item1',
               'artifactId' : 'ServiceRequest.LogTypeLookup_domainlogtype_Item1Desc1_value',
               'id' : 'aw358d120a',
            });
            listItemTemplate008.addChild( listtext024 );


            var listtext025 = new ListText({
               'resourceAttribute' : 'description',
               'cssClass' : 'bold textappearance-medium',
               'layoutInsertAt' : 'desc1',
               'artifactId' : 'ServiceRequest.LogTypeLookup_domainlogtype_Item1Desc1_description',
               'id' : 'aw9e528788',
            });
            listItemTemplate008.addChild( listtext025 );



            var list008 = new List({
               'resource' : 'domainlogtype',
               'listItemTemplate' : listItemTemplate008,
               'artifactId' : 'ServiceRequest.LogTypeLookup_domainlogtype_list',
               'id' : 'aw39751be0',
               'searchAttributes' : searchAttributes003,
            });
            lookup005.addChild( list008 );


            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'Platform.AttachmentInfoView', false);
               trackTimer.startTracking();
            }

            var view013 = new View({
               'resource' : 'PlatformAttachmentInfoResource',
               'id' : 'Platform.AttachmentInfoView',
               'label' : MessageService.createStaticMessage('Attachment Details'),
            });
            ui001.addChild( view013 );

            var requiredResources018 = {
               'PlatformAttachmentInfoResource' : {
                  'reload' : true,
                  'artifactId' : 'Platform.AttachmentInfoView_PlatformAttachmentInfoResource',
                  'id' : 'awedbd920b',
               },
            };
            view013.addRequiredResources( requiredResources018 );

            var container028 = new Container({
               'resource' : 'PlatformAttachmentInfoResource',
               'artifactId' : 'Platform.AttachmentInfoView_container_0',
               'id' : 'aw22b80d5f',
            });
            view013.addChild( container028 );


            var group014 = new Group({
               'artifactId' : 'Platform.AttachmentInfoView_group_0',
               'id' : 'aw80e7b381',
            });
            container028.addChild( group014 );


            var groupitem053 = new GroupItem({
               'artifactId' : 'Platform.AttachmentInfoView_PlatformAttachmentInfoResource_groupitem_0',
               'id' : 'aw15768e0',
            });
            group014.addChild( groupitem053 );


            var text077 = new Text({
               'resourceAttribute' : 'name',
               'editable' : true,
               'artifactId' : 'Platform.AttachmentInfoView_PlatformAttachmentInfoResource_groupitem_0_name_Name',
               'id' : 'awddf675f4',
               'label' : MessageService.createStaticMessage('Name'),
               'required' : true,
            });
            groupitem053.addChild( text077 );


            var groupitem054 = new GroupItem({
               'artifactId' : 'Platform.AttachmentInfoView_PlatformAttachmentInfoResource_groupitem_1',
               'id' : 'aw76505876',
            });
            group014.addChild( groupitem054 );


            var text078 = new Text({
               'resourceAttribute' : 'description',
               'editable' : true,
               'artifactId' : 'Platform.AttachmentInfoView_PlatformAttachmentInfoResource_groupitem_1_description_Description',
               'id' : 'awc2735258',
               'label' : MessageService.createStaticMessage('Description'),
               'placeHolder' : MessageService.createStaticMessage('Tap to enter'),
            });
            groupitem054.addChild( text078 );


            var groupitem055 = new GroupItem({
               'artifactId' : 'Platform.AttachmentInfoView_PlatformAttachmentInfoResource_groupitem_2',
               'id' : 'awef5909cc',
            });
            group014.addChild( groupitem055 );


            var text079 = new Text({
               'resourceAttribute' : 'category',
               'lookup' : 'PlatformAttachmentIn.CategoryLookup',
               'editable' : false,
               'artifactId' : 'Platform.AttachmentInfoView_PlatformAttachmentInfoResource_groupitem_2_category_Folder',
               'id' : 'aw3a5ae064',
               'label' : MessageService.createStaticMessage('Folder'),
               'lookupAttribute' : 'folderName',
               'placeHolder' : MessageService.createStaticMessage('Tap to enter'),
            });
            groupitem055.addChild( text079 );

            var eventHandlers058 = [
               {
                     'method' : 'renderCategory',
                     'artifactId' : 'Platform.AttachmentInfoView_PlatformAttachmentInfoResource_groupitem_2_category_Folder_eventHandlers_render_renderCategory',
                     'id' : 'awa205ff23',
                     'event' : 'render',
                     'class' : 'platform.handlers.AttachmentHandler',
               }
            ];
            text079.eventHandlers = eventHandlers058;

            var groupitem056 = new GroupItem({
               'artifactId' : 'Platform.AttachmentInfoView_PlatformAttachmentInfoResource_groupitem_3',
               'id' : 'aw985e395a',
            });
            group014.addChild( groupitem056 );


            var text080 = new Text({
               'resourceAttribute' : 'fileType',
               'editable' : false,
               'artifactId' : 'Platform.AttachmentInfoView_PlatformAttachmentInfoResource_groupitem_3_fileType_FileType',
               'id' : 'awf0b55f9',
               'label' : MessageService.createStaticMessage('File Type'),
            });
            groupitem056.addChild( text080 );


            var groupitem057 = new GroupItem({
               'artifactId' : 'Platform.AttachmentInfoView_PlatformAttachmentInfoResource_groupitem_4',
               'id' : 'aw63aacf9',
            });
            group014.addChild( groupitem057 );


            var text081 = new Text({
               'resourceAttribute' : 'fileSize',
               'editable' : false,
               'artifactId' : 'Platform.AttachmentInfoView_PlatformAttachmentInfoResource_groupitem_4_fileSize_FileSizeKB',
               'id' : 'awa8aac05f',
               'label' : MessageService.createStaticMessage('File Size (KB)'),
            });
            groupitem057.addChild( text081 );


            var footer005 = new Footer({
               'artifactId' : 'Platform.AttachmentInfoView_footer',
               'id' : 'awad3a6a43',
            });
            view013.addChild( footer005 );


            var button027 = new Button({
               'artifactId' : 'Platform.AttachmentInfoView_Cancel_button',
               'id' : 'aw61842429',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers059 = [
               {
                     'method' : 'handleBackButtonAttachmentDetailsView',
                     'artifactId' : 'Platform.AttachmentInfoView_Cancel_button_eventHandlers_click_handleBackButtonAttachmentDetailsView',
                     'id' : 'aw2e660b65',
                     'event' : 'click',
                     'class' : 'platform.handlers.AttachmentHandler',
               }
            ];
            button027.eventHandlers = eventHandlers059;
            footer005.addChild( button027 );


            var button028 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'Platform.AttachmentInfoView_Save_button',
               'id' : 'aw8904293b',
               'label' : MessageService.createStaticMessage('Save'),
            });
            var eventHandlers060 = [
               {
                     'method' : 'commitAttachmentEntry',
                     'artifactId' : 'Platform.AttachmentInfoView_Save_button_eventHandlers_click_commitAttachmentEntry',
                     'id' : 'awbff90b7f',
                     'event' : 'click',
                     'class' : 'platform.handlers.AttachmentHandler',
               }
            ];
            button028.eventHandlers = eventHandlers060;
            footer005.addChild( button028 );

            var eventHandlers061 = [
               {
                     'method' : 'init',
                     'artifactId' : 'Platform.AttachmentInfoView_eventHandlers_initialize_init',
                     'id' : 'awbe3d1849',
                     'event' : 'initialize',
                     'class' : 'platform.handlers.AttachmentHandler',
               },
               {
                     'method' : 'cancelAttachmentDetailsView',
                     'artifactId' : 'Platform.AttachmentInfoView_eventHandlers_cleanup_handleBackButtonAttachmentDetailsView',
                     'id' : 'awb6598e9',
                     'event' : 'cleanup',
                     'class' : 'platform.handlers.AttachmentHandler',
               }
            ];
            view013.eventHandlers = eventHandlers061;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'Platform.AttachmentFileDialog', false);
               trackTimer.startTracking();
            }

            var view014 = new View({
               'id' : 'Platform.AttachmentFileDialog',
            });
            ui001.addChild( view014 );


            var footer006 = new Footer({
               'artifactId' : 'Platform.AttachmentFileDialog_footer',
               'id' : 'awb513dc05',
            });
            view014.addChild( footer006 );


            var button029 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'Platform.UnsavedSketch_doNotAllow_button',
               'id' : 'aw150d1bc',
               'label' : MessageService.createStaticMessage('Close'),
            });
            var eventHandlers062 = [
               {
                     'method' : 'closeFileDialog',
                     'artifactId' : 'Platform.AttachmentFileDialog_closeDialog',
                     'id' : 'awc0d2f7fd',
                     'event' : 'click',
                     'class' : 'platform.handlers.AttachmentHandler',
               }
            ];
            button029.eventHandlers = eventHandlers062;
            footer006.addChild( button029 );

            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            var lookup006 = new Lookup({
               'resource' : 'PlatformAttachmentCategoryResource',
               'id' : 'PlatformAttachmentIn.CategoryLookup',
               'label' : MessageService.createStaticMessage('Select Folder'),
            });
            ui001.addChild( lookup006 );

            var requiredResources019 = {
               'PlatformAttachmentCategoryResource' : {
                  'artifactId' : 'PlatformAttachmentIn.CategoryLookup_PlatformAttachmentCategoryResource',
                  'id' : 'aw18cc3542',
               },
            };
            lookup006.addRequiredResources( requiredResources019 );


            var searchAttributes004 = new SearchAttributes({
               'artifactId' : 'PlatformAttachmentIn.CategoryLookup_PlatformAttachmentCategoryResource_searchAttributes',
               'id' : 'awb7d9341f',
            });

            var searchAttribute009 = new SearchAttribute({
               'name' : 'folderName',
               'artifactId' : 'PlatformAttachmentIn.CategoryLookup_PlatformAttachmentCategoryResource_searchAttribute_folderName',
               'id' : 'aw9514e6e6',
            });
            searchAttributes004.addChild( searchAttribute009 );



            var listItemTemplate009 = new ListItemTemplate({
               'layout' : 'Item2Desc2',
               'artifactId' : 'PlatformAttachmentIn.CategoryLookup_PlatformAttachmentCategoryResource_listItemTemplate_Item2Desc2',
               'id' : 'aweb3659e3',
            });

            var listtext026 = new ListText({
               'resourceAttribute' : 'folderName',
               'cssClass' : 'bold textappearance-medium',
               'layoutInsertAt' : 'item1',
               'artifactId' : 'PlatformAttachmentIn.CategoryLookup_PlatformAttachmentCategoryResource_Item2Desc2_folderName',
               'id' : 'aw48fc196b',
            });
            listItemTemplate009.addChild( listtext026 );



            var list009 = new List({
               'resource' : 'PlatformAttachmentCategoryResource',
               'listItemTemplate' : listItemTemplate009,
               'artifactId' : 'PlatformAttachmentIn.CategoryLookup_PlatformAttachmentCategoryResource_list',
               'id' : 'awe6857cc4',
               'searchAttributes' : searchAttributes004,
            });
            lookup006.addChild( list009 );


            var returnAttributes005 = new ReturnAttributes({
               'artifactId' : 'PlatformAttachmentIn.CategoryLookup_returnAttributes',
               'id' : 'aw4860e6b5',
            });
            lookup006.addChild( returnAttributes005 );


            var returnAttribute008 = new ReturnAttribute({
               'targetAttribute' : 'category',
               'artifactId' : 'PlatformAttachmentIn.CategoryLookup_folderName_category',
               'id' : 'awb2f5d728',
               'sourceAttribute' : 'folderName',
            });
            returnAttributes005.addChild( returnAttribute008 );


            var actions006 = new Actions({
               'artifactId' : 'actions',
               'id' : 'aw548f1ef',
            });
            ui001.addChild( actions006 );


            var action008 = new Action({
               'overflow' : true,
               'artifactId' : 'ResetWorkList_action',
               'id' : 'aw956f5d3b',
               'label' : MessageService.createStaticMessage('Reset Work List'),
            });
            actions006.addChild( action008 );

            var eventHandlers063 = [
               {
                     'method' : 'resetWorkList',
                     'artifactId' : 'ResetWorkList_action_eventHandlers_click_findByScan',
                     'id' : 'aw11a2bd29',
                     'event' : 'click',
                     'class' : 'platform.handlers.WorkOfflineHandler',
               },
               {
                     'method' : 'enableResetWorkList',
                     'artifactId' : 'ResetWorkList_action_eventHandlers_render_enableResetWorkList',
                     'id' : 'awfb6356a8',
                     'event' : 'render',
                     'class' : 'platform.handlers.WorkOfflineHandler',
               }
            ];
            action008.eventHandlers = eventHandlers063;

            var action009 = new Action({
               'overflow' : true,
               'artifactId' : 'PseudoOffline_goOffline',
               'id' : 'aw90309912',
               'label' : MessageService.createStaticMessage('Enable Offline Mode'),
            });
            actions006.addChild( action009 );

            var eventHandlers064 = [
               {
                     'method' : 'toggleOfflineMode',
                     'artifactId' : 'PseudoOffline_enableoffline_action_eventHandlers_click',
                     'id' : 'aw33d3b70c',
                     'event' : 'click',
                     'class' : 'platform.handlers.PseudoOfflineModeHandler',
               }
            ];
            action009.eventHandlers = eventHandlers064;

            var action010 = new Action({
               'overflow' : true,
               'transitionTo' : 'Platform.Settings',
               'artifactId' : 'Settings_action',
               'id' : 'awc0b1927e',
               'label' : MessageService.createStaticMessage('Settings'),
            });
            actions006.addChild( action010 );


            var action011 = new Action({
               'overflow' : true,
               'transitionTo' : 'Platform.HelpAbout',
               'artifactId' : 'About_action',
               'id' : 'aw49fae06b',
               'label' : MessageService.createStaticMessage('About'),
            });
            actions006.addChild( action011 );


            var action012 = new Action({
               'overflow' : true,
               'transitionTo' : 'Platform.LogOutPrompt',
               'artifactId' : 'LogOut_action',
               'id' : 'awd566efa2',
               'label' : MessageService.createStaticMessage('Log Out'),
            });
            actions006.addChild( action012 );


            var action013 = new Action({
               'artifactId' : 'action',
               'id' : 'aw47cc8c92',
            });
            actions006.addChild( action013 );

            var eventHandlers065 = [
               {
                     'artifactId' : 'action_eventHandlers_click',
                     'id' : 'aw871940b2',
                     'event' : 'click',
                     'class' : 'platform.handlers.CreateQueryBaseHandler',
               }
            ];
            action013.eventHandlers = eventHandlers065;

            var erroractions001 = new ErrorActions({
               'artifactId' : 'erroractions',
               'id' : 'aw6a5d95e9',
            });
            ui001.addChild( erroractions001 );


            var action014 = new Action({
               'artifactId' : 'UndoChanges_action',
               'id' : 'aw2236d58a',
               'label' : MessageService.createStaticMessage('Undo Changes'),
            });
            erroractions001.addChild( action014 );

            var eventHandlers066 = [
               {
                     'method' : 'confirmClearChanges',
                     'artifactId' : 'UndoChanges_action_eventHandlers_click_confirmClearChanges',
                     'id' : 'awcf857f5c',
                     'event' : 'click',
                     'class' : 'platform.handlers.WorkOfflineHandler',
               }
            ];
            action014.eventHandlers = eventHandlers066;

            var action015 = new Action({
               'artifactId' : 'ResendChanges_action',
               'id' : 'awccf9e70e',
               'label' : MessageService.createStaticMessage('Resend Changes'),
            });
            erroractions001.addChild( action015 );

            var eventHandlers067 = [
               {
                     'method' : 'retryRecordChanges',
                     'artifactId' : 'ResendChanges_action_eventHandlers_click_retryRecordChanges',
                     'id' : 'aw543ac47e',
                     'event' : 'click',
                     'class' : 'platform.handlers.WorkOfflineHandler',
               }
            ];
            action015.eventHandlers = eventHandlers067;
            var eventHandlers068 = [
               {
                     'method' : 'none',
                     'artifactId' : 'eventHandlers_none_none',
                     'id' : 'aw1e2e7ded',
                     'event' : 'none',
                     'class' : 'platform.handlers.LookupHandler',
               }
            ];
            ui001.eventHandlers = eventHandlers068;

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'Platform.emptyview', false);
               trackTimer.startTracking();
            }

            var view015 = new View({
               'showHeader' : false,
               'id' : 'Platform.emptyview',
               'showFooter' : false,
            });
            ui001.addChild( view015 );

            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'Platform.Notifications', false);
               trackTimer.startTracking();
            }

            var view016 = new View({
               'id' : 'Platform.Notifications',
               'label' : MessageService.createStaticMessage('My Notifications'),
               'fullScreen' : 'true',
            });
            ui001.addChild( view016 );

            var requiredResources020 = {
               'osusernotification' : {
                  'reload' : true,
                  'artifactId' : 'Platform.Notifications_osusernotification',
                  'id' : 'awed6a5e70',
               },
               'PlatformTempPushNotification' : {
                  'reload' : true,
                  'artifactId' : 'Platform.Notifications_PlatformTempPushNotification',
                  'id' : 'aw9993c5cb',
               },
            };
            view016.addRequiredResources( requiredResources020 );


            var listItemTemplate010 = new ListItemTemplate({
               'layout' : 'NotificationList',
               'artifactId' : 'Platform.Notifications_listItemTemplate',
               'id' : 'aw718eb447',
            });

            var listtext027 = new ListText({
               'resourceAttribute' : 'uiDate',
               'layoutInsertAt' : 'date1',
               'artifactId' : 'Platform.Notifications_uiDate',
               'id' : 'aw56b07378',
            });
            listItemTemplate010.addChild( listtext027 );


            var listtext028 = new ListText({
               'resourceAttribute' : 'itemnum',
               'layoutInsertAt' : 'item1',
               'artifactId' : 'Platform.Notifications_itemnum',
               'id' : 'aw4dbbd111',
            });
            listItemTemplate010.addChild( listtext028 );


            var listtext029 = new ListText({
               'resourceAttribute' : 'itemDesc',
               'layoutInsertAt' : 'item2',
               'artifactId' : 'Platform.Notifications_itemDesc',
               'id' : 'aw6bac97b9',
            });
            listItemTemplate010.addChild( listtext029 );

            var eventHandlers069 = [
               {
                     'method' : 'openFromMsgHistory',
                     'artifactId' : 'Platform.Notifications_Open_button_eventHandlers_click_FromList',
                     'id' : 'awf03f57bd',
                     'event' : 'click',
                     'class' : 'platform.handlers.PushNotificationDialogHandler',
               },
               {
                     'method' : 'renderMsgHistoryItem',
                     'artifactId' : 'Platform.Notifications_Open_button_eventHandlers_render_FromList',
                     'id' : 'awfd2341e9',
                     'event' : 'render',
                     'class' : 'platform.handlers.PushNotificationDialogHandler',
               }
            ];
            listItemTemplate010.eventHandlers = eventHandlers069;


            var list010 = new List({
               'resource' : 'osusernotification',
               'listItemTemplate' : listItemTemplate010,
               'artifactId' : 'Platform.Notifications_list',
               'id' : 'awb4916253',
               'label' : MessageService.createStaticMessage('List of notifications'),
            });
            view016.addChild( list010 );

            var eventHandlers070 = [
               {
                     'method' : 'renderMsgHistory',
                     'artifactId' : 'Platform.Notifications_eventHandlers_render_FromList',
                     'id' : 'awa8aedc90',
                     'event' : 'render',
                     'class' : 'platform.handlers.PushNotificationDialogHandler',
               }
            ];
            view016.eventHandlers = eventHandlers070;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            var dialog009 = new Dialog({
               'cssClass' : 'dialogDateTimeLookup',
               'resource' : 'PlatformDateLookupResource',
               'id' : 'Platform.DateTimeLookup',
               'label' : MessageService.createStaticMessage('Change Time or Date'),
            });
            ui001.addChild( dialog009 );

            var eventHandlers071 = [
               {
                     'method' : 'initLookup',
                     'artifactId' : 'Platform.DateTimeLookup_eventHandlers_show_initLookup',
                     'id' : 'aw576c44ec',
                     'event' : 'show',
                     'class' : 'platform.handlers.LookupHandler',
               }
            ];
            dialog009.eventHandlers = eventHandlers071;

            var container029 = new Container({
               'artifactId' : 'Platform.DateTimeLookup_container_0',
               'id' : 'aw3cdb37d7',
            });
            dialog009.addChild( container029 );


            var datetimepicker001 = new DateTimePicker({
               'artifactId' : 'Platform.DateTimeLookup_datetimepicker_0',
               'id' : 'aw7d2f0e0d',
            });
            container029.addChild( datetimepicker001 );


            var container030 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.DateTimeLookup_container_1',
               'id' : 'aw4bdc0741',
            });
            dialog009.addChild( container030 );


            var button030 = new Button({
               'artifactId' : 'Platform.DateTimeLookup_Cancel_button',
               'id' : 'aw54d2f1bb',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers072 = [
               {
                     'method' : 'Cancel',
                     'artifactId' : 'Platform.DateTimeLookup_Cancel_button_eventHandlers_click_Cancel',
                     'id' : 'aw5ced0c47',
                     'event' : 'click',
                     'class' : 'platform.handlers.LookupHandler',
               }
            ];
            button030.eventHandlers = eventHandlers072;
            container030.addChild( button030 );


            var button031 = new Button({
               'artifactId' : 'Platform.DateTimeLookup_Clear_button',
               'id' : 'awfd1238bd',
               'label' : MessageService.createStaticMessage('Clear'),
            });
            var eventHandlers073 = [
               {
                     'method' : 'Clear',
                     'artifactId' : 'Platform.DateTimeLookup_Clear_button_eventHandlers_click_Clear',
                     'id' : 'aw47510f1f',
                     'event' : 'click',
                     'class' : 'platform.handlers.LookupHandler',
               }
            ];
            button031.eventHandlers = eventHandlers073;
            container030.addChild( button031 );


            var button032 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'Platform.DateTimeLookup_OK_button',
               'id' : 'awb1e0d280',
               'label' : MessageService.createStaticMessage('OK'),
               'primary' : 'true',
            });
            var eventHandlers074 = [
               {
                     'method' : 'SetSelection',
                     'artifactId' : 'Platform.DateTimeLookup_OK_button_eventHandlers_click_SetSelection',
                     'id' : 'aw6c08b2ff',
                     'event' : 'click',
                     'class' : 'platform.handlers.LookupHandler',
               }
            ];
            button032.eventHandlers = eventHandlers074;
            container030.addChild( button032 );


            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'Platform.HelpAbout', false);
               trackTimer.startTracking();
            }

            var view017 = new View({
               'resource' : 'PlatformLoginResource',
               'id' : 'Platform.HelpAbout',
               'label' : MessageService.createStaticMessage('About'),
               'fullScreen' : 'true',
            });
            ui001.addChild( view017 );


            var container031 = new Container({
               'cssClass' : 'platformHelpAboutContainer',
               'artifactId' : 'Platform.HelpAbout_container_0',
               'id' : 'awf8c0259e',
            });
            view017.addChild( container031 );


            var image005 = new Image({
               'image' : 'ibmLogoDark.svg',
               'artifactId' : 'Platform.HelpAbout_image_0',
               'id' : 'awfebf608a',
            });
            container031.addChild( image005 );


            var text082 = new Text({
               'resourceAttribute' : 'appName',
               'cssClass' : 'productName bold textappearance-large',
               'editable' : false,
               'artifactId' : 'Platform.HelpAbout_container_0_appName',
               'id' : 'aw27632fa8',
            });
            container031.addChild( text082 );


            var text083 = new Text({
               'cssClass' : 'version',
               'editable' : false,
               'artifactId' : 'Platform.HelpAbout_container_0_Version7.5.2.1',
               'id' : 'awf060501a',
               'value' : MessageService.createStaticMessage('Version 7.6.4.0'),
            });
            container031.addChild( text083 );


            var text084 = new Text({
               'cssClass' : 'build',
               'editable' : false,
               'artifactId' : 'Platform.HelpAbout_container_0_Buildnumberbuild',
               'id' : 'awd289f042',
               'value' : MessageService.createStaticMessage('Build number @build@'),
            });
            container031.addChild( text084 );


            var text085 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.HelpAbout_container_0_LicensedMaterials-',
               'id' : 'aw31046f88',
               'value' : MessageService.createStaticMessage('Licensed Materials - Property of IBM. \u00A9IBM Corp. 2020. IBM, the IBM logo, and ibm.com are trademarks of IBM Corp., registered in many jurisdictions worldwide. Other product and service names might be trademarks of IBM or other companies. A current list of IBM trademarks is available on the Web at www.ibm.com\/legal\/copytrade.shtml. This Program is licensed under the terms of the license agreement for the Program. Please read this agreement carefully before using the Program. By using the Program, you agree to these terms.'),
            });
            container031.addChild( text085 );


            var group015 = new Group({
               'debugOnly' : 'true',
               'artifactId' : 'Platform.Settings_group_2',
               'id' : 'awc5ac5572',
            });
            container031.addChild( group015 );


            var groupitem058 = new GroupItem({
               'layout' : 'ScreenInfo',
               'cssClass' : 'screenInfo',
               'artifactId' : 'Platform.Settings_screenInfo_item',
               'id' : 'aw5de3d82',
            });
            group015.addChild( groupitem058 );


            var text086 = new Text({
               'cssClass' : 'textappearance-large',
               'layoutInsertAt' : 'title',
               'artifactId' : 'Platform.Settings_screenInfo_title',
               'id' : 'awd295621c',
               'value' : MessageService.createStaticMessage('Screen Information'),
            });
            groupitem058.addChild( text086 );


            var text087 = new Text({
               'resourceAttribute' : 'ppi',
               'resource' : 'DeviceSizeResource',
               'editable' : false,
               'layoutInsertAt' : 'pixels',
               'artifactId' : 'Platform.Settings_screenInfo_ppi_text',
               'id' : 'aw4219624',
               'label' : MessageService.createStaticMessage('PPI'),
            });
            groupitem058.addChild( text087 );


            var text088 = new Text({
               'resourceAttribute' : 'width',
               'resource' : 'DeviceSizeResource',
               'editable' : false,
               'layoutInsertAt' : 'width',
               'artifactId' : 'Platform.Settings_screenInfo_width_text',
               'id' : 'aw6564040e',
               'label' : MessageService.createStaticMessage('Width'),
            });
            groupitem058.addChild( text088 );


            var text089 = new Text({
               'resourceAttribute' : 'height',
               'resource' : 'DeviceSizeResource',
               'editable' : false,
               'layoutInsertAt' : 'height',
               'artifactId' : 'Platform.Settings_screenInfo_height_text',
               'id' : 'awcd6ab682',
               'label' : MessageService.createStaticMessage('Height'),
            });
            groupitem058.addChild( text089 );


            var text090 = new Text({
               'resourceAttribute' : 'layoutSize',
               'resource' : 'DeviceSizeResource',
               'editable' : false,
               'layoutInsertAt' : 'size',
               'artifactId' : 'Platform.Settings_screenInfo_layout_text',
               'id' : 'awd74c1b0',
               'label' : MessageService.createStaticMessage('Layout Size'),
            });
            groupitem058.addChild( text090 );


            var text091 = new Text({
               'resourceAttribute' : 'orientation',
               'resource' : 'DeviceSizeResource',
               'editable' : false,
               'layoutInsertAt' : 'orientation',
               'artifactId' : 'Platform.Settings_screenInfo_orientation_text',
               'id' : 'aw22df9e6f',
               'label' : MessageService.createStaticMessage('Orientation'),
            });
            groupitem058.addChild( text091 );


            var text092 = new Text({
               'resourceAttribute' : 'density',
               'resource' : 'DeviceSizeResource',
               'editable' : false,
               'layoutInsertAt' : 'density',
               'artifactId' : 'Platform.Settings_screenInfo_density_text',
               'id' : 'aw6b4b20e2',
               'label' : MessageService.createStaticMessage('Density'),
            });
            groupitem058.addChild( text092 );


            var text093 = new Text({
               'resourceAttribute' : 'pane0_layoutSize',
               'resource' : 'DeviceSizeResource',
               'editable' : false,
               'layoutInsertAt' : 'pane0',
               'artifactId' : 'Platform.Settings_screenInfo_pane0',
               'id' : 'aw39d3d4a7',
               'label' : MessageService.createStaticMessage('Pane 1 Size'),
            });
            groupitem058.addChild( text093 );


            var text094 = new Text({
               'resourceAttribute' : 'pane1_layoutSize',
               'resource' : 'DeviceSizeResource',
               'editable' : false,
               'layoutInsertAt' : 'pane1',
               'artifactId' : 'Platform.Settings_screenInfo_pane1',
               'id' : 'aw4ed4e431',
               'label' : MessageService.createStaticMessage('Pane 2 Size'),
            });
            groupitem058.addChild( text094 );

            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'Platform.Settings', false);
               trackTimer.startTracking();
            }

            var view018 = new View({
               'id' : 'Platform.Settings',
               'label' : MessageService.createStaticMessage('Settings'),
               'fullScreen' : 'true',
            });
            ui001.addChild( view018 );

            var requiredResources021 = {
               'LastADDownload' : {
                  'artifactId' : 'Platform.Settings_LastADDownload',
                  'id' : 'aw879343e2',
               },
            };
            view018.addRequiredResources( requiredResources021 );

            var actions007 = new Actions({
               'artifactId' : 'Platform.Settings_actions',
               'id' : 'awb3f56d3b',
            });
            view018.addChild( actions007 );


            var action016 = new Action({
               'overflow' : true,
               'artifactId' : 'Platform.Settings_RefreshSystemData_action',
               'id' : 'awccb0ee65',
               'label' : MessageService.createStaticMessage('Refresh System Data'),
            });
            actions007.addChild( action016 );

            var eventHandlers075 = [
               {
                     'method' : 'openDownloadSystemDataDialog',
                     'artifactId' : 'Platform.Settings_RefreshSystemData_action_eventHandlers_click_downloadSystemData',
                     'id' : 'aw490b2801',
                     'event' : 'click',
                     'class' : 'platform.handlers.SettingsHandler',
               },
               {
                     'method' : 'renderDownloadSytemDataActionButton',
                     'artifactId' : 'Platform.Settings_RefreshSystemData_action_eventHandlers_render_renderDownloadSytemDataActionButton',
                     'id' : 'awa42bdfcc',
                     'event' : 'render',
                     'class' : 'platform.handlers.SettingsHandler',
               }
            ];
            action016.eventHandlers = eventHandlers075;

            var container032 = new Container({
               'resource' : 'LastADDownload',
               'artifactId' : 'Platform.Settings_container_0',
               'id' : 'aw74ff68b5',
            });
            view018.addChild( container032 );


            var group016 = new Group({
               'artifactId' : 'Platform.Settings_group_0',
               'id' : 'aw2ba2345e',
            });
            container032.addChild( group016 );


            var groupitem059 = new GroupItem({
               'transitionTo' : 'Platform.ChangePassword',
               'artifactId' : 'Platform.Settings_LastADDownload_groupitem_Platform.ChangePassword_0',
               'id' : 'awd48342a3',
            });
            group016.addChild( groupitem059 );


            var text095 = new Text({
               'cssClass' : 'relatedRecords',
               'artifactId' : 'Platform.Settings_LastADDownload_groupitem_Platform.ChangePassword_0_ChangePassword',
               'id' : 'aw6c14924a',
               'value' : MessageService.createStaticMessage('Change Password'),
            });
            groupitem059.addChild( text095 );

            var eventHandlers076 = [
               {
                     'method' : 'enableChangePasswordFunction',
                     'artifactId' : 'Platform.Settings_LastADDownload_groupitem_Platform.ChangePassword_0_eventHandlers_render_enableChangePasswordFunction',
                     'id' : 'awa81f4a5',
                     'event' : 'render',
                     'class' : 'platform.handlers.ChangePasswordHandler',
               }
            ];
            groupitem059.eventHandlers = eventHandlers076;

            var groupitem060 = new GroupItem({
               'artifactId' : 'Platform.Settings_LastADDownload_groupitem_0',
               'id' : 'aw82635ebb',
            });
            group016.addChild( groupitem060 );


            var text096 = new Text({
               'cssClass' : 'relatedRecords',
               'artifactId' : 'Platform.Settings_LastADDownload_groupitem_0_RefreshLookupData',
               'id' : 'awcddf2167',
               'value' : MessageService.createStaticMessage('Refresh Lookup Data'),
            });
            groupitem060.addChild( text096 );


            var text097 = new Text({
               'resourceAttribute' : 'downloadStatus',
               'editable' : false,
               'artifactId' : 'Platform.Settings_LastADDownload_groupitem_0_downloadStatus',
               'id' : 'aw8a1673e3',
            });
            groupitem060.addChild( text097 );

            var eventHandlers077 = [
               {
                     'method' : 'renderLastDownload',
                     'artifactId' : 'Platform.Settings_LastADDownload_groupitem_0_downloadStatus_eventHandlers_render_renderLastDownload',
                     'id' : 'aw72547fb7',
                     'event' : 'render',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               }
            ];
            text097.eventHandlers = eventHandlers077;

            var text098 = new Text({
               'cssClass' : 'textappearance-small',
               'editable' : false,
               'artifactId' : 'Platform.Settings_LastADDownload_groupitem_0_Updatesthelookupd',
               'id' : 'aw38a24bec',
               'value' : MessageService.createStaticMessage('Updates the lookup data on your device. Lookup data includes objects, such as assets and locations, that can be added to records.'),
            });
            groupitem060.addChild( text098 );

            var eventHandlers078 = [
               {
                     'method' : 'refreshAdditionalData',
                     'artifactId' : 'Platform.Settings_LastADDownload_groupitem_0_eventHandlers_click_refreshAdditionalData',
                     'id' : 'aw93ad06fe',
                     'event' : 'click',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               }
            ];
            groupitem060.eventHandlers = eventHandlers078;

            var groupitem061 = new GroupItem({
               'artifactId' : 'Platform.Settings_LastADDownload_groupitem_3_Number_of_day_to_sync',
               'id' : 'aw97e66cd6',
            });
            group016.addChild( groupitem061 );


            var text099 = new Text({
               'resourceAttribute' : 'numberOfDaysToSync',
               'editable' : true,
               'artifactId' : 'Platform.Settings_LastADDownload_text_Number_of_day_to_sync',
               'id' : 'aw69a517e3',
               'label' : MessageService.createStaticMessage('How often changes need to be refresh in days:'),
            });
            groupitem061.addChild( text099 );

            var eventHandlers079 = [
               {
                     'method' : 'renderDayToSYnc',
                     'artifactId' : 'Platform.Settings_LastADDownload_text_Number_of_day_to_sync_eventHandlers_renderDayToSYnc',
                     'id' : 'awdc11c959',
                     'event' : 'render',
                     'class' : 'platform.handlers.SettingsHandler',
               },
               {
                     'method' : 'saveDayToSync',
                     'artifactId' : 'Platform.Settings_LastADDownload_text_Number_of_day_to_sync_eventHandlers_saveDayToSYnc',
                     'id' : 'aw57729721',
                     'event' : 'validate',
                     'class' : 'platform.handlers.SettingsHandler',
               }
            ];
            text099.eventHandlers = eventHandlers079;

            var groupitem062 = new GroupItem({
               'transitionTo' : 'Platform.AdvancedSettings',
               'artifactId' : 'Platform.Settings_LastADDownload_groupitem_Platform.AdvancedSettings_0',
               'id' : 'aw741c4d60',
            });
            group016.addChild( groupitem062 );


            var text100 = new Text({
               'cssClass' : 'relatedRecords',
               'artifactId' : 'Platform.Settings_LastADDownload_groupitem_Platform.AdvancedSettings_0_AdvancedSettings',
               'id' : 'aw2d662633',
               'value' : MessageService.createStaticMessage('Advanced Settings'),
            });
            groupitem062.addChild( text100 );


            var group017 = new Group({
               'enableFeatureByProperty' : 'attachments.enabled',
               'artifactId' : 'Platform.Settings_group_1',
               'id' : 'aw5ca504c8',
            });
            container032.addChild( group017 );


            var groupitem063 = new GroupItem({
               'layout' : 'Item1Button1',
               'artifactId' : 'Platform.Settings_LastADDownload_groupitem_1',
               'id' : 'awf5646e2d',
            });
            group017.addChild( groupitem063 );


            var text101 = new Text({
               'cssClass' : 'wrap-content',
               'layoutInsertAt' : 'item1',
               'artifactId' : 'Platform.Settings_LastADDownload_groupitem_1_Downloadattachments',
               'id' : 'awd21c407a',
               'value' : MessageService.createStaticMessage('Download attachments with work list.'),
            });
            groupitem063.addChild( text101 );


            var checkbox004 = new CheckBox({
               'resourceAttribute' : 'downloadAttachments',
               'cssClass' : 'rightCheckBox',
               'editable' : true,
               'layoutInsertAt' : 'button1',
               'artifactId' : 'Platform.Settings_downloadAttachments_checkbox',
               'id' : 'aw1a5b9aa2',
            });
            groupitem063.addChild( checkbox004 );

            var eventHandlers080 = [
               {
                     'method' : 'updateFieldValue',
                     'artifactId' : 'Platform.Settings_downloadAttachments_checkbox_eventHandlers_render_updateFieldValue',
                     'id' : 'aw9635db7f',
                     'event' : 'render',
                     'class' : 'platform.handlers.SettingsHandler',
               },
               {
                     'method' : 'updateSettingsValue',
                     'artifactId' : 'Platform.Settings_downloadAttachments_checkbox_eventHandlers_validate_updateSettingsValue',
                     'id' : 'awb178b23',
                     'event' : 'validate',
                     'class' : 'platform.handlers.SettingsHandler',
               }
            ];
            checkbox004.eventHandlers = eventHandlers080;

            var container033 = new Container({
               'artifactId' : 'ConnectionContainer',
               'id' : 'awef0b2658',
            });
            view018.addChild( container033 );


            var group018 = new Group({
               'artifactId' : 'Platform.Settings.ConnectionManagement.group',
               'id' : 'aw9ad5002d',
            });
            container033.addChild( group018 );


            var groupitem064 = new GroupItem({
               'layout' : 'ConnectionManagementLayout',
               'artifactId' : 'Platform.Settings.ConnectionManagement.groupItem1',
               'id' : 'aw81b0980b',
            });
            group018.addChild( groupitem064 );


            var text102 = new Text({
               'cssClass' : 'relatedRecords',
               'layoutInsertAt' : 'Title',
               'artifactId' : 'Platform.Settings.ConnectionManagement.Title',
               'id' : 'aw1de21387',
               'value' : MessageService.createStaticMessage('Connection Behavior'),
            });
            groupitem064.addChild( text102 );


            var text103 = new Text({
               'cssClass' : 'wrap-content',
               'layoutInsertAt' : 'description',
               'artifactId' : 'Platform.Settings.ConnectionManagement.Description',
               'id' : 'aw6b506a6f',
               'value' : MessageService.createStaticMessage('Specifies which network connections should enable the application to work online'),
            });
            groupitem064.addChild( text103 );


            var radiobutton001 = new RadioButton({
               'cssClass' : 'firstradiobutton',
               'name' : 'Connectiongrp',
               'layoutInsertAt' : 'button1',
               'artifactId' : 'Platform.Settings.ConnectionManagement.Button.AllConnections',
               'id' : 'awcb83aecb',
               'label' : MessageService.createStaticMessage('All Types'),
            });
            groupitem064.addChild( radiobutton001 );

            var eventHandlers081 = [
               {
                     'method' : 'renderConnetionManagementSetting',
                     'artifactId' : 'Platform.Settings.ConnectionManagement.AllConnection.EventHandler1',
                     'id' : 'awe9d7776d',
                     'event' : 'render',
                     'class' : 'platform.handlers.SettingsHandler',
               },
               {
                     'method' : 'connetionManagementSetting',
                     'artifactId' : 'Platform.Settings.allCOnnection.click.EventHandler',
                     'id' : 'aw76203443',
                     'event' : 'click',
                     'class' : 'platform.handlers.SettingsHandler',
               }
            ];
            radiobutton001.eventHandlers = eventHandlers081;

            var radiobutton002 = new RadioButton({
               'name' : 'Connectiongrp',
               'layoutInsertAt' : 'button2',
               'artifactId' : 'Platform.Settings.ConnectionManagement.Button.WiFi',
               'id' : 'aw42dec2bb',
               'label' : MessageService.createStaticMessage('Only WiFi'),
            });
            groupitem064.addChild( radiobutton002 );

            var eventHandlers082 = [
               {
                     'method' : 'renderConnetionManagementSetting',
                     'artifactId' : 'Platform.Settings.ConnectionManagement.AllConnection.EventHandler2',
                     'id' : 'aw70de26d7',
                     'event' : 'render',
                     'class' : 'platform.handlers.SettingsHandler',
               },
               {
                     'method' : 'connetionManagementSetting',
                     'artifactId' : 'Platform.Settings.WiFi.click.EventHandler',
                     'id' : 'aw183e4c0c',
                     'event' : 'click',
                     'class' : 'platform.handlers.SettingsHandler',
               }
            ];
            radiobutton002.eventHandlers = eventHandlers082;

            var radiobutton003 = new RadioButton({
               'name' : 'Connectiongrp',
               'layoutInsertAt' : 'button3',
               'artifactId' : 'Platform.Settings.ConnectionManagement.Button.Cellular',
               'id' : 'aw7032481d',
               'label' : MessageService.createStaticMessage('Only Cellular'),
            });
            groupitem064.addChild( radiobutton003 );

            var eventHandlers083 = [
               {
                     'method' : 'renderConnetionManagementSetting',
                     'artifactId' : 'Platform.Settings.ConnectionManagement.AllConnection.EventHandler3',
                     'id' : 'aw7d91641',
                     'event' : 'render',
                     'class' : 'platform.handlers.SettingsHandler',
               },
               {
                     'method' : 'connetionManagementSetting',
                     'artifactId' : 'Platform.Settings.ConnectionManagement.Cellular.EventHandler',
                     'id' : 'aw2a978e73',
                     'event' : 'click',
                     'class' : 'platform.handlers.SettingsHandler',
               }
            ];
            radiobutton003.eventHandlers = eventHandlers083;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'Platform.AdvancedSettings', false);
               trackTimer.startTracking();
            }

            var view019 = new View({
               'id' : 'Platform.AdvancedSettings',
               'label' : MessageService.createStaticMessage('Settings'),
            });
            ui001.addChild( view019 );


            var container034 = new Container({
               'artifactId' : 'Platform.AdvancedSettings_container_0',
               'id' : 'aw5c13274d',
            });
            view019.addChild( container034 );


            var group019 = new Group({
               'artifactId' : 'Platform.AdvancedSettings_group_0',
               'id' : 'awebdfb82c',
            });
            container034.addChild( group019 );


            var groupitem065 = new GroupItem({
               'transitionTo' : 'Platform.TimeTrackReport',
               'artifactId' : 'Platform.AdvancedSettings_groupitem_Platform.TimeTrackReport_0',
               'id' : 'awba4384a8',
            });
            group019.addChild( groupitem065 );


            var text104 = new Text({
               'cssClass' : 'relatedRecords',
               'artifactId' : 'Platform.AdvancedSettings_groupitem_Platform.TimeTrackReport_0_TrackPerformanceDa',
               'id' : 'awc0a6dde7',
               'value' : MessageService.createStaticMessage('Track Performance Data'),
            });
            groupitem065.addChild( text104 );


            var text105 = new Text({
               'cssClass' : 'red-text',
               'editable' : false,
               'artifactId' : 'Platform.AdvancedSettings_groupitem_Platform.TimeTrackReport_0_Thisoptionusesmem',
               'id' : 'aw4367e95f',
               'value' : MessageService.createStaticMessage('This option uses memory and might slow the performance of your device. Disable performance tracking when you are done.'),
            });
            groupitem065.addChild( text105 );


            var groupitem066 = new GroupItem({
               'transitionTo' : 'Platform.LoggerReport',
               'artifactId' : 'Platform.AdvancedSettings_groupitem_Platform.LoggerReport_0',
               'id' : 'aw10ca73e0',
            });
            group019.addChild( groupitem066 );


            var text106 = new Text({
               'cssClass' : 'relatedRecords',
               'artifactId' : 'Platform.AdvancedSettings_groupitem_Platform.LoggerReport_0_Logging',
               'id' : 'awffa3ff9c',
               'value' : MessageService.createStaticMessage('Logging'),
            });
            groupitem066.addChild( text106 );


            var text107 = new Text({
               'cssClass' : 'red-text',
               'editable' : false,
               'artifactId' : 'Platform.AdvancedSettings_groupitem_Platform.LoggerReport_0_Thisoptionusesmem',
               'id' : 'aw30da1efa',
               'value' : MessageService.createStaticMessage('This option uses memory and might slow the performance of your device. Disable logging when you are done.'),
            });
            groupitem066.addChild( text107 );

            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'Platform.LoggerReport', false);
               trackTimer.startTracking();
            }

            var view020 = new View({
               'cssClass' : 'loggerReport',
               'scrollDir' : 'vh',
               'id' : 'Platform.LoggerReport',
               'label' : MessageService.createStaticMessage('Logging Data'),
            });
            ui001.addChild( view020 );


            var actions008 = new Actions({
               'artifactId' : 'Platform.LoggerReport_actions',
               'id' : 'aw5b090344',
            });
            view020.addChild( actions008 );


            var action017 = new Action({
               'overflow' : true,
               'artifactId' : 'Platform.LoggerReport_EnableErrorLogging_action',
               'id' : 'awc05e82b4',
               'label' : MessageService.createStaticMessage('Enable Error Logging'),
            });
            actions008.addChild( action017 );

            var eventHandlers084 = [
               {
                     'method' : 'enableDisableLoggerErro',
                     'artifactId' : 'Platform.LoggerReport_EnableErrorLogging_action_eventHandlers_click_enableDisableLoggerErro',
                     'id' : 'awf5ad7151',
                     'event' : 'click',
                     'class' : 'platform.logging.handler.LoggerReportHandler',
               },
               {
                     'method' : 'setLabelError',
                     'artifactId' : 'Platform.LoggerReport_EnableErrorLogging_action_eventHandlers_render_setLabelError',
                     'id' : 'aw4faa4e07',
                     'event' : 'render',
                     'class' : 'platform.logging.handler.LoggerReportHandler',
               }
            ];
            action017.eventHandlers = eventHandlers084;

            var action018 = new Action({
               'overflow' : true,
               'artifactId' : 'Platform.LoggerReport_EnableInfoLogging_action',
               'id' : 'aw6d618335',
               'label' : MessageService.createStaticMessage('Enable Info Logging'),
            });
            actions008.addChild( action018 );

            var eventHandlers085 = [
               {
                     'method' : 'enableDisableLoggerInfo',
                     'artifactId' : 'Platform.LoggerReport_EnableInfoLogging_action_eventHandlers_click_enableDisableLoggerInfo',
                     'id' : 'aw164710f9',
                     'event' : 'click',
                     'class' : 'platform.logging.handler.LoggerReportHandler',
               },
               {
                     'method' : 'setLabelInfo',
                     'artifactId' : 'Platform.LoggerReport_EnableInfoLogging_action_eventHandlers_render_setLabelInfo',
                     'id' : 'awc8b2e890',
                     'event' : 'render',
                     'class' : 'platform.logging.handler.LoggerReportHandler',
               }
            ];
            action018.eventHandlers = eventHandlers085;

            var action019 = new Action({
               'overflow' : true,
               'artifactId' : 'Platform.LoggerReport_EnableDebugLogging_action',
               'id' : 'awaa11689b',
               'label' : MessageService.createStaticMessage('Enable Debug Logging'),
            });
            actions008.addChild( action019 );

            var eventHandlers086 = [
               {
                     'method' : 'enableDisableLoggerDebug',
                     'artifactId' : 'Platform.LoggerReport_EnableDebugLogging_action_eventHandlers_click_enableDisableLoggerDebug',
                     'id' : 'aw49ea32aa',
                     'event' : 'click',
                     'class' : 'platform.logging.handler.LoggerReportHandler',
               },
               {
                     'method' : 'setLabelDebug',
                     'artifactId' : 'Platform.LoggerReport_EnableDebugLogging_action_eventHandlers_render_setLabelDebug',
                     'id' : 'aw1cc86c8a',
                     'event' : 'render',
                     'class' : 'platform.logging.handler.LoggerReportHandler',
               }
            ];
            action019.eventHandlers = eventHandlers086;

            var action020 = new Action({
               'overflow' : true,
               'transitionTo' : 'Platform.TransLoggerReport',
               'artifactId' : 'Platform.LoggerReport_ViewTransactionLog_action',
               'id' : 'awdaed3d40',
               'label' : MessageService.createStaticMessage('View Transaction Log'),
            });
            actions008.addChild( action020 );


            var action021 = new Action({
               'overflow' : true,
               'artifactId' : 'Platform.LoggerReport_ClearLogData_action',
               'id' : 'awb6d3895c',
               'label' : MessageService.createStaticMessage('Clear Log Data'),
            });
            actions008.addChild( action021 );

            var eventHandlers087 = [
               {
                     'method' : 'clear',
                     'artifactId' : 'Platform.LoggerReport_ClearLogData_action_eventHandlers_click_clear',
                     'id' : 'aw10958c5',
                     'event' : 'click',
                     'class' : 'platform.logging.handler.LoggerReportHandler',
               }
            ];
            action021.eventHandlers = eventHandlers087;

            var action022 = new Action({
               'overflow' : true,
               'artifactId' : 'Platform.LoggerReport_UploadLog_action',
               'id' : 'aw7510fce3',
               'label' : MessageService.createStaticMessage('Save Log'),
            });
            actions008.addChild( action022 );

            var eventHandlers088 = [
               {
                     'method' : 'showIfConnected',
                     'artifactId' : 'Platform.LoggerReport_UploadLog_action_eventHandlers_render_uploadCurrent',
                     'id' : 'aw4d53a4f5',
                     'event' : 'render',
                     'class' : 'platform.logging.handler.LoggerReportHandler',
               },
               {
                     'method' : 'uploadCurrent',
                     'artifactId' : 'Platform.LoggerReport_UploadLog_action_eventHandlers_click_uploadCurrent',
                     'id' : 'aw2b172289',
                     'event' : 'click',
                     'class' : 'platform.logging.handler.LoggerReportHandler',
               }
            ];
            action022.eventHandlers = eventHandlers088;

            var action023 = new Action({
               'overflow' : true,
               'artifactId' : 'Platform.LoggerReport_EmailLog_action',
               'id' : 'aw90d8a401',
               'label' : MessageService.createStaticMessage('Email Log'),
            });
            actions008.addChild( action023 );

            var eventHandlers089 = [
               {
                     'method' : 'emailCurrent',
                     'artifactId' : 'Platform.LoggerReport_EmailLog_action_eventHandlers_click_emailCurrent',
                     'id' : 'awf10881b9',
                     'event' : 'click',
                     'class' : 'platform.logging.handler.LoggerReportHandler',
               }
            ];
            action023.eventHandlers = eventHandlers089;
            var eventHandlers090 = [
               {
                     'method' : 'renderLoggerReport',
                     'artifactId' : 'Platform.LoggerReport_eventHandlers_show_renderLoggerReport',
                     'id' : 'aw9b7c5c73',
                     'event' : 'show',
                     'class' : 'platform.logging.handler.LoggerReportHandler',
               }
            ];
            view020.eventHandlers = eventHandlers090;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'Platform.TransLoggerReport', false);
               trackTimer.startTracking();
            }

            var view021 = new View({
               'scrollDir' : 'vh',
               'id' : 'Platform.TransLoggerReport',
               'label' : MessageService.createStaticMessage('Logging Data'),
            });
            ui001.addChild( view021 );


            var actions009 = new Actions({
               'artifactId' : 'Platform.TransLoggerReport_actions',
               'id' : 'aw49b00040',
            });
            view021.addChild( actions009 );


            var action024 = new Action({
               'overflow' : true,
               'artifactId' : 'Platform.TransLoggerReport_ClearLogData_action',
               'id' : 'awdce21e26',
               'label' : MessageService.createStaticMessage('Clear Log Data'),
            });
            actions009.addChild( action024 );

            var eventHandlers091 = [
               {
                     'method' : 'clearTransLog',
                     'artifactId' : 'Platform.TransLoggerReport_ClearLogData_action_eventHandlers_click_clear',
                     'id' : 'aw71c2398e',
                     'event' : 'click',
                     'class' : 'platform.logging.handler.LoggerReportHandler',
               }
            ];
            action024.eventHandlers = eventHandlers091;

            var action025 = new Action({
               'overflow' : true,
               'artifactId' : 'Platform.TransLoggerReport_EmailLog_action',
               'id' : 'aw29f3639',
               'label' : MessageService.createStaticMessage('Email Log'),
            });
            actions009.addChild( action025 );

            var eventHandlers092 = [
               {
                     'method' : 'emailCurrentTranslog',
                     'artifactId' : 'Platform.TransLoggerReport_EmailLog_action_eventHandlers_click_emailCurrent',
                     'id' : 'awfd97a236',
                     'event' : 'click',
                     'class' : 'platform.logging.handler.LoggerReportHandler',
               }
            ];
            action025.eventHandlers = eventHandlers092;
            var eventHandlers093 = [
               {
                     'method' : 'renderTransLoggerReport',
                     'artifactId' : 'Platform.TransLoggerReport_eventHandlers_show_renderTransLoggerReport',
                     'id' : 'aw4261a98a',
                     'event' : 'show',
                     'class' : 'platform.logging.handler.LoggerReportHandler',
               }
            ];
            view021.eventHandlers = eventHandlers093;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'Platform.ChangePassword', false);
               trackTimer.startTracking();
            }

            var view022 = new View({
               'resource' : 'PlatformChangePasswordForm',
               'id' : 'Platform.ChangePassword',
               'label' : MessageService.createStaticMessage('Change Password'),
            });
            ui001.addChild( view022 );


            var container035 = new Container({
               'cssClass' : 'changePasswordForm',
               'artifactId' : 'Platform.ChangePassword_container_0',
               'id' : 'awf7c2a2a',
            });
            view022.addChild( container035 );


            var text108 = new Text({
               'resourceAttribute' : 'errorMsg',
               'cssClass' : 'errorMsg',
               'editable' : false,
               'artifactId' : 'Platform.ChangePassword_container_0_errorMsg',
               'id' : 'aw3ed16fe1',
            });
            container035.addChild( text108 );


            var text109 = new Text({
               'resourceAttribute' : 'infoMsg',
               'cssClass' : 'infoMsg',
               'editable' : false,
               'artifactId' : 'Platform.ChangePassword_container_0_infoMsg',
               'id' : 'awe28ebedd',
            });
            container035.addChild( text109 );


            var text110 = new Text({
               'border' : 'true',
               'resourceAttribute' : 'currentpassword',
               'editable' : true,
               'artifactId' : 'Platform.ChangePassword_container_0_currentpassword',
               'id' : 'aw7df0b045',
               'type' : 'password',
               'placeHolder' : MessageService.createStaticMessage('Current password'),
            });
            container035.addChild( text110 );

            var eventHandlers094 = [
               {
                     'method' : 'hidePasswordField',
                     'artifactId' : 'Platform.ChangePassword_container_0_currentpassword_eventHandlers_render_hidePasswordField',
                     'id' : 'aw27f3eacb',
                     'event' : 'render',
                     'class' : 'platform.handlers.ChangePasswordHandler',
               }
            ];
            text110.eventHandlers = eventHandlers094;

            var text111 = new Text({
               'border' : 'true',
               'resourceAttribute' : 'newpassword',
               'editable' : true,
               'artifactId' : 'Platform.ChangePassword_container_0_newpassword',
               'id' : 'aw618d08b5',
               'type' : 'password',
               'placeHolder' : MessageService.createStaticMessage('New password'),
            });
            container035.addChild( text111 );


            var text112 = new Text({
               'border' : 'true',
               'resourceAttribute' : 'confirmnewpassword',
               'editable' : true,
               'artifactId' : 'Platform.ChangePassword_container_0_confirmnewpassword',
               'id' : 'awd274537a',
               'type' : 'password',
               'placeHolder' : MessageService.createStaticMessage('Confirm password'),
            });
            container035.addChild( text112 );


            var button033 = new Button({
               'artifactId' : 'Platform.ChangePassword_Cancel_button',
               'id' : 'aw96c63135',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers095 = [
               {
                     'method' : 'cancelPasswordClickHandler',
                     'artifactId' : 'Platform.ChangePassword_Cancel_button_eventHandlers_click_cancelPasswordClickHandler',
                     'id' : 'aw7492b621',
                     'event' : 'click',
                     'class' : 'platform.handlers.ChangePasswordHandler',
               }
            ];
            button033.eventHandlers = eventHandlers095;
            container035.addChild( button033 );


            var button034 = new Button({
               'artifactId' : 'Platform.ChangePassword_Change_button',
               'id' : 'aw5cd0477f',
               'label' : MessageService.createStaticMessage('Change'),
               'primary' : 'true',
            });
            var eventHandlers096 = [
               {
                     'method' : 'changePasswordClickHandler',
                     'artifactId' : 'Platform.ChangePassword_Change_button_eventHandlers_click_changePasswordClickHandler',
                     'id' : 'awfdba8feb',
                     'event' : 'click',
                     'class' : 'platform.handlers.ChangePasswordHandler',
               }
            ];
            button034.eventHandlers = eventHandlers096;
            container035.addChild( button034 );

            var eventHandlers097 = [
               {
                     'method' : 'initializeChangePasswordView',
                     'artifactId' : 'Platform.ChangePassword_eventHandlers_show_initializeChangePasswordView',
                     'id' : 'awbbd173b',
                     'event' : 'show',
                     'class' : 'platform.handlers.ChangePasswordHandler',
               },
               {
                     'method' : 'changePasswordBack',
                     'artifactId' : 'Platform.ChangePassword_eventHandlers_back_changePasswordBack',
                     'id' : 'awc25c9010',
                     'event' : 'back',
                     'class' : 'platform.handlers.ChangePasswordHandler',
               }
            ];
            view022.eventHandlers = eventHandlers097;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'Platform.RetrieveOldPassword', false);
               trackTimer.startTracking();
            }

            var view023 = new View({
               'resource' : 'PlatformChangePasswordForm',
               'showHeader' : false,
               'showOverflow' : false,
               'id' : 'Platform.RetrieveOldPassword',
               'label' : MessageService.createStaticMessage('Recover App Data'),
            });
            ui001.addChild( view023 );


            var container036 = new Container({
               'cssClass' : 'changePasswordForm',
               'artifactId' : 'Platform.RetrieveOldPassword_container_0',
               'id' : 'awecdef66d',
            });
            view023.addChild( container036 );


            var text113 = new Text({
               'artifactId' : 'Platform.RetrieveOldPassword_container_0_Enterthepasswordt',
               'id' : 'aw14ebf03b',
               'value' : MessageService.createStaticMessage('Enter the password that you last used to log in to the app. If you do not have this password, you must reset the app before you can log in.'),
            });
            container036.addChild( text113 );


            var text114 = new Text({
               'resourceAttribute' : 'errorMsg',
               'cssClass' : 'errorMsg',
               'editable' : false,
               'artifactId' : 'Platform.RetrieveOldPassword_container_0_errorMsg',
               'id' : 'aw9574c917',
            });
            container036.addChild( text114 );


            var text115 = new Text({
               'border' : 'true',
               'resourceAttribute' : 'currentpassword',
               'editable' : true,
               'artifactId' : 'Platform.RetrieveOldPassword_container_0_currentpassword',
               'id' : 'aw97b6c3b7',
               'type' : 'password',
               'placeHolder' : MessageService.createStaticMessage('Previous password'),
            });
            container036.addChild( text115 );


            var button035 = new Button({
               'artifactId' : 'Platform.RetrieveOldPassword_Recover_button',
               'id' : 'aw3a0ff2',
               'label' : MessageService.createStaticMessage('Recover'),
               'primary' : 'true',
            });
            var eventHandlers098 = [
               {
                     'method' : 'recoverOldPasswordClickHandler',
                     'artifactId' : 'Platform.RetrieveOldPassword_Recover_button_eventHandlers_click_recoverOldPasswordClickHandler',
                     'id' : 'awecb18d1c',
                     'event' : 'click',
                     'class' : 'platform.handlers.ChangePasswordHandler',
               }
            ];
            button035.eventHandlers = eventHandlers098;
            container036.addChild( button035 );


            var button036 = new Button({
               'artifactId' : 'Platform.RetrieveOldPassword_Reset_button',
               'id' : 'aw8bb551dc',
               'label' : MessageService.createStaticMessage('Reset'),
            });
            var eventHandlers099 = [
               {
                     'method' : 'resetStorageClickHandler',
                     'artifactId' : 'Platform.RetrieveOldPassword_Reset_button_eventHandlers_click_resetStorageClickHandler',
                     'id' : 'awfe7a73d2',
                     'event' : 'click',
                     'class' : 'platform.handlers.ChangePasswordHandler',
               }
            ];
            button036.eventHandlers = eventHandlers099;
            container036.addChild( button036 );

            var eventHandlers100 = [
               {
                     'method' : 'initializeRetrieveOldPasswordView',
                     'artifactId' : 'Platform.RetrieveOldPassword_eventHandlers_show_initializeRetrieveOldPasswordView',
                     'id' : 'aw26f17c5a',
                     'event' : 'show',
                     'class' : 'platform.handlers.ChangePasswordHandler',
               }
            ];
            view023.eventHandlers = eventHandlers100;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            var dialog010 = new Dialog({
               'closeOnBackgroundClick' : 'true',
               'id' : 'Platform.ConfirmResetDataStore',
            });
            ui001.addChild( dialog010 );


            var container037 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.ConfirmResetDataStore_container_0',
               'id' : 'awacb7e535',
            });
            dialog010.addChild( container037 );


            var text116 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.ConfirmResetDataStore_container_0_WarningAllappdat',
               'id' : 'aw68bdf3e8',
               'value' : MessageService.createStaticMessage('Warning! All app data on the device will be cleared. Any data that has not been sent to the server will be lost.'),
            });
            container037.addChild( text116 );


            var container038 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.ConfirmResetDataStore_container_1',
               'id' : 'awdbb0d5a3',
            });
            dialog010.addChild( container038 );


            var button037 = new Button({
               'cssClass' : 'dialogButton',
               'artifactId' : 'Platform.ConfirmResetDataStore_Continue_button',
               'id' : 'awba645d10',
               'label' : MessageService.createStaticMessage('Continue'),
            });
            var eventHandlers101 = [
               {
                     'method' : 'resetDataStoreClickHandler',
                     'artifactId' : 'Platform.ConfirmResetDataStore_Continue_button_eventHandlers_click_resetDataStoreClickHandler',
                     'id' : 'aw5074e6c8',
                     'event' : 'click',
                     'class' : 'platform.handlers.ChangePasswordHandler',
               }
            ];
            button037.eventHandlers = eventHandlers101;
            container038.addChild( button037 );


            var button038 = new Button({
               'cssClass' : 'dialogButton',
               'artifactId' : 'Platform.ConfirmResetDataStore_Cancel_button',
               'id' : 'aw50474341',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers102 = [
               {
                     'method' : 'cancelResetDataStoreClickHandler',
                     'artifactId' : 'Platform.ConfirmResetDataStore_Cancel_button_eventHandlers_click_cancelResetDataStoreClickHandler',
                     'id' : 'awda7121b8',
                     'event' : 'click',
                     'class' : 'platform.handlers.ChangePasswordHandler',
               }
            ];
            button038.eventHandlers = eventHandlers102;
            container038.addChild( button038 );


            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'Platform.TimeTrackReport', false);
               trackTimer.startTracking();
            }

            var view024 = new View({
               'cssClass' : 'loggerReport',
               'scrollDir' : 'vh',
               'id' : 'Platform.TimeTrackReport',
               'label' : MessageService.createStaticMessage('Performance Data'),
            });
            ui001.addChild( view024 );

            var requiredResources022 = {
               'timeTrack' : {
                  'artifactId' : 'Platform.TimeTrackReport_timeTrack',
                  'id' : 'aw8d707cee',
               },
            };
            view024.addRequiredResources( requiredResources022 );

            var actions010 = new Actions({
               'artifactId' : 'Platform.TimeTrackReport_actions',
               'id' : 'aw9d9a4864',
            });
            view024.addChild( actions010 );


            var action026 = new Action({
               'overflow' : true,
               'artifactId' : 'Platform.TimeTrackReport_EnablePerformanceTracking_action',
               'id' : 'aw34736a63',
               'label' : MessageService.createStaticMessage('Enable Performance Tracking'),
            });
            actions010.addChild( action026 );

            var eventHandlers103 = [
               {
                     'method' : 'enableDisableTT',
                     'artifactId' : 'Platform.TimeTrackReport_EnablePerformanceTracking_action_eventHandlers_click_enableDisableTT',
                     'id' : 'aw10972127',
                     'event' : 'click',
                     'class' : 'platform.performance.handler.TimeTrackHandler',
               },
               {
                     'method' : 'setLabel',
                     'artifactId' : 'Platform.TimeTrackReport_EnablePerformanceTracking_action_eventHandlers_render_setLabel',
                     'id' : 'awf9abf636',
                     'event' : 'render',
                     'class' : 'platform.performance.handler.TimeTrackHandler',
               }
            ];
            action026.eventHandlers = eventHandlers103;

            var action027 = new Action({
               'overflow' : true,
               'artifactId' : 'Platform.TimeTrackReport_ClearPerformanceData_action',
               'id' : 'aw1edf54cf',
               'label' : MessageService.createStaticMessage('Clear Performance Data'),
            });
            actions010.addChild( action027 );

            var eventHandlers104 = [
               {
                     'method' : 'clear',
                     'artifactId' : 'Platform.TimeTrackReport_ClearPerformanceData_action_eventHandlers_click_clear',
                     'id' : 'aw85273d1b',
                     'event' : 'click',
                     'class' : 'platform.performance.handler.TimeTrackHandler',
               }
            ];
            action027.eventHandlers = eventHandlers104;

            var action028 = new Action({
               'overflow' : true,
               'artifactId' : 'Platform.TimeTrackReport_EmailReport_action',
               'id' : 'aw6ff8fae1',
               'label' : MessageService.createStaticMessage('Email Report'),
            });
            actions010.addChild( action028 );

            var eventHandlers105 = [
               {
                     'method' : 'emailCurrent',
                     'artifactId' : 'Platform.TimeTrackReport_EmailReport_action_eventHandlers_click_emailCurrent',
                     'id' : 'awc00583a0',
                     'event' : 'click',
                     'class' : 'platform.performance.handler.TimeTrackHandler',
               }
            ];
            action028.eventHandlers = eventHandlers105;
            var eventHandlers106 = [
               {
                     'method' : 'renderTT',
                     'artifactId' : 'Platform.TimeTrackReport_eventHandlers_show_renderTT',
                     'id' : 'awca05a315',
                     'event' : 'show',
                     'class' : 'platform.performance.handler.TimeTrackHandler',
               }
            ];
            view024.eventHandlers = eventHandlers106;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            var dialog011 = new Dialog({
               'closeOnBackgroundClick' : 'true',
               'id' : 'Platform.ListLongPressDialog',
            });
            ui001.addChild( dialog011 );



            var listItemTemplate011 = new ListItemTemplate({
               'cssClass' : 'dialogListItem textappearance-medium',
               'artifactId' : 'Platform.ListLongPressDialog_PlatformLongPressResource_listItemTemplate',
               'id' : 'awefd72fd8',
            });

            var listtext030 = new ListText({
               'resourceAttribute' : 'label',
               'artifactId' : 'Platform.ListLongPressDialog_PlatformLongPressResource_label',
               'id' : 'awe2e495b2',
            });
            listItemTemplate011.addChild( listtext030 );



            var list011 = new List({
               'resource' : 'PlatformLongPressResource',
               'showHeader' : false,
               'listItemTemplate' : listItemTemplate011,
               'artifactId' : 'Platform.ListLongPressDialog_PlatformLongPressResource_list',
               'id' : 'aw64ff84d9',
               'queryBase' : '',
            });
            dialog011.addChild( list011 );


            var dialog012 = new Dialog({
               'id' : 'Platform.LoadingAdditionalData',
            });
            ui001.addChild( dialog012 );


            var container039 = new Container({
               'artifactId' : 'Platform.LoadingAdditionalData_container_0',
               'id' : 'aw48b509d9',
            });
            dialog012.addChild( container039 );


            var text117 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.LoadingAdditionalData_container_0_Downloadinglookupd',
               'id' : 'aw4cec47c0',
               'value' : MessageService.createStaticMessage('Downloading lookup data.'),
            });
            container039.addChild( text117 );


            var button039 = new Button({
               'artifactId' : 'Platform.LoadingAdditionalData_Cancel_button',
               'id' : 'awb30b5f0',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers107 = [
               {
                     'method' : 'cancelADDownload',
                     'artifactId' : 'Platform.LoadingAdditionalData_Cancel_button_eventHandlers_click_cancelADDownload',
                     'id' : 'awc41dac4c',
                     'event' : 'click',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               }
            ];
            button039.eventHandlers = eventHandlers107;
            container039.addChild( button039 );


            var dialog013 = new Dialog({
               'id' : 'Platform.AdditionalDataNoConn',
            });
            ui001.addChild( dialog013 );


            var container040 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.AdditionalDataNoConn_container_0',
               'id' : 'aw666da461',
            });
            dialog013.addChild( container040 );


            var text118 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.AdditionalDataNoConn_container_0_Lookupdatacouldno',
               'id' : 'aw96b90fd8',
               'value' : MessageService.createStaticMessage('Lookup data could not be downloaded. Go to Settings > Refresh Lookup Data when you are online.'),
            });
            container040.addChild( text118 );


            var container041 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.AdditionalDataNoConn_container_1',
               'id' : 'aw116a94f7',
            });
            dialog013.addChild( container041 );


            var button040 = new Button({
               'artifactId' : 'Platform.AdditionalDataNoConn_OK_button',
               'id' : 'aw9b370278',
               'label' : MessageService.createStaticMessage('OK'),
            });
            var eventHandlers108 = [
               {
                     'method' : 'closeDialogAndShowDefaultViewIfNeeded',
                     'artifactId' : 'Platform.AdditionalDataNoConn_OK_button_eventHandlers_click_closeDialogAndShowDefaultViewIfNeeded',
                     'id' : 'aw108159b3',
                     'event' : 'click',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               }
            ];
            button040.eventHandlers = eventHandlers108;
            container041.addChild( button040 );


            var dialog014 = new Dialog({
               'id' : 'Platform.ConfirmReloadWorkList',
            });
            ui001.addChild( dialog014 );


            var container042 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.ConfirmReloadWorkList_container_0',
               'id' : 'aw2054aa9e',
            });
            dialog014.addChild( container042 );


            var text119 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.ConfirmReloadWorkList_container_0_Doyouwanttoclose',
               'id' : 'aw83f81a4b',
               'value' : MessageService.createStaticMessage('Reloading the work list takes time if you are downloading large amounts of data.  Are you sure that you want to continue?'),
            });
            container042.addChild( text119 );


            var container043 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.ConfirmReloadWorkList_container_1',
               'id' : 'aw57539a08',
            });
            dialog014.addChild( container043 );


            var button041 = new Button({
               'cssClass' : 'dialogButton',
               'artifactId' : 'Platform.ConfirmReloadWorkList_Yes_button',
               'id' : 'aw5bc89627',
               'label' : MessageService.createStaticMessage('Yes'),
            });
            var eventHandlers109 = [
               {
                     'method' : 'reloadConfirmed',
                     'artifactId' : 'Platform.ConfirmReloadWorkList_Yes_button_eventHandlers_click_processDialog',
                     'id' : 'awafdb701f',
                     'event' : 'click',
                     'class' : 'platform.handlers.WorkOfflineHandler',
               }
            ];
            button041.eventHandlers = eventHandlers109;
            container043.addChild( button041 );


            var button042 = new Button({
               'cssClass' : 'mblPrimaryButton dialogButton',
               'artifactId' : 'Platform.ConfirmReloadWorkList_No_button',
               'id' : 'aw4487e9e7',
               'label' : MessageService.createStaticMessage('No'),
            });
            var eventHandlers110 = [
               {
                     'method' : 'closeDialog',
                     'artifactId' : 'Platform.ConfirmReloadWorkList_No_button_eventHandlers_click_closeDialog',
                     'id' : 'aw56d1743',
                     'event' : 'click',
                     'class' : 'platform.handlers.DialogHandler',
               }
            ];
            button042.eventHandlers = eventHandlers110;
            container043.addChild( button042 );


            var dialog015 = new Dialog({
               'resource' : 'PlatformProgressResource',
               'id' : 'Platform.ReloadingCurrentWorklist',
            });
            ui001.addChild( dialog015 );


            var container044 = new Container({
               'cssClass' : 'mblSimpleMessageText',
               'artifactId' : 'Platform.ReloadCurrentWorklist_container_0',
               'id' : 'awce0c0b72',
            });
            dialog015.addChild( container044 );


            var text120 = new Text({
               'resourceAttribute' : 'progressMsg',
               'editable' : false,
               'artifactId' : 'Platform.ReloadCurrentWorklist_container_0_progressMsg',
               'id' : 'awaa894933',
            });
            container044.addChild( text120 );


            var dialog016 = new Dialog({
               'id' : 'Platform.AdditionalDataFailed',
            });
            ui001.addChild( dialog016 );


            var container045 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.AdditionalDataFailed.container',
               'id' : 'aw275627fb',
            });
            dialog016.addChild( container045 );


            var text121 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.AdditionalDataFailed.text',
               'id' : 'awb25e5b66',
               'value' : MessageService.createStaticMessage('Lookup data could not be downloaded. If you are connected, go to Settings > Refresh Lookup Data.'),
            });
            container045.addChild( text121 );


            var container046 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.AdditionalDataFailed.container2',
               'id' : 'aw309dc3be',
            });
            dialog016.addChild( container046 );


            var button043 = new Button({
               'artifactId' : 'Platform.AdditionalDataFailed.button',
               'id' : 'aw39111677',
               'label' : MessageService.createStaticMessage('OK'),
            });
            var eventHandlers111 = [
               {
                     'method' : 'closeDialogAndShowDefaultViewIfNeeded',
                     'artifactId' : 'Platform.AdditionalDataFailed.eventHandler',
                     'id' : 'awacbc5440',
                     'event' : 'click',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               }
            ];
            button043.eventHandlers = eventHandlers111;
            container046.addChild( button043 );


            var dialog017 = new Dialog({
               'resource' : 'PlatformProgressResource',
               'id' : 'Platform.LoadingSystemData',
            });
            ui001.addChild( dialog017 );


            var container047 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.LoadingSystemData_container_0',
               'id' : 'aw13d3cc6a',
            });
            dialog017.addChild( container047 );


            var text122 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.LoadingSystemData_container_0_Downloadingsystemd',
               'id' : 'awfc1b5f79',
               'value' : MessageService.createStaticMessage('Downloading system data.'),
            });
            container047.addChild( text122 );


            var text123 = new Text({
               'resourceAttribute' : 'progressMsg',
               'editable' : false,
               'artifactId' : 'Platform.LoadingSystemData_container_0_progressMsg',
               'id' : 'aw635d9968',
            });
            container047.addChild( text123 );


            var dialog018 = new Dialog({
               'id' : 'Platform.LoadAdditionalDataYesNo',
            });
            ui001.addChild( dialog018 );


            var container048 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.LoadAdditionalDataYesNo_container_0',
               'id' : 'aw22834650',
            });
            dialog018.addChild( container048 );


            var text124 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.LoadAdditionalDataYesNo_container_0_Thelookupdatafor',
               'id' : 'aw89be3f27',
               'value' : MessageService.createStaticMessage('The lookup data for this app must be downloaded. Download it now or later?'),
            });
            container048.addChild( text124 );

            var eventHandlers112 = [
               {
                     'method' : 'theLookupdataText',
                     'artifactId' : 'Platform.LoadAdditionalDataYesNo_container_0_Thelookupdatafor_eventHandlers_render_setAdditionalDownloadText',
                     'id' : 'aw9051ca24',
                     'event' : 'render',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               }
            ];
            text124.eventHandlers = eventHandlers112;

            var text125 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.LoadAdditionalDataYesNo_container_0_Retrylookupdatafor',
               'id' : 'awb287d1cc',
               'value' : MessageService.createStaticMessage('Lookup data was partially downloaded. Click Retry to download the remaining lookup data. Click Reset to refresh all of the lookup data. Click Close if you are through downloading lookup data.'),
            });
            container048.addChild( text125 );

            var eventHandlers113 = [
               {
                     'method' : 'retrylookupdataText',
                     'artifactId' : 'Platform.LoadAdditionalDataYesNo_container_0_Retrylookupdatafor_eventHandlers_render_setAdditionalDownloadText',
                     'id' : 'aw5ad2ed31',
                     'event' : 'render',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               }
            ];
            text125.eventHandlers = eventHandlers113;

            var text126 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.LoadAdditionalDataYesNo_container_0_Whenrunninginabr',
               'id' : 'awb757e4d5',
               'value' : MessageService.createStaticMessage('When running in a browser, a maximum of 200 records are downloaded per lookup.'),
            });
            container048.addChild( text126 );

            var eventHandlers114 = [
               {
                     'method' : 'showInPreview',
                     'artifactId' : 'Platform.LoadAdditionalDataYesNo_container_0_Whenrunninginabr_eventHandlers_render_showInPreview',
                     'id' : 'awb7d271e9',
                     'event' : 'render',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               }
            ];
            text126.eventHandlers = eventHandlers114;

            var container049 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.LoadAdditionalDataYesNo_container_1',
               'id' : 'aw558476c6',
            });
            dialog018.addChild( container049 );


            var button044 = new Button({
               'cssClass' : 'dialogButton',
               'artifactId' : 'Platform.LoadAdditionalDataYesNo_Later_button',
               'id' : 'awa2501fe3',
               'label' : MessageService.createStaticMessage('Later'),
            });
            var eventHandlers115 = [
               {
                     'method' : 'closeDialogAndShowDefaultViewIfNeeded',
                     'artifactId' : 'Platform.LoadAdditionalDataYesNo_Later_button_eventHandlers_click_closeDialogAndShowDefaultViewIfNeeded',
                     'id' : 'aw257121b',
                     'event' : 'click',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               },
               {
                     'method' : 'setBtLabelLaterOrCancel',
                     'artifactId' : 'Platform.LoadAdditionalDataYesNo_Retry_button_eventHandlers_render_setBtLabelLaterOrCancel',
                     'id' : 'aw6ece4695',
                     'event' : 'render',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               }
            ];
            button044.eventHandlers = eventHandlers115;
            container049.addChild( button044 );


            var button045 = new Button({
               'cssClass' : 'mblPrimaryButton dialogButton',
               'artifactId' : 'Platform.LoadAdditionalDataYesNo_Now_button',
               'id' : 'aw35a14c11',
               'label' : MessageService.createStaticMessage('Now'),
            });
            var eventHandlers116 = [
               {
                     'method' : 'confirmADDownload',
                     'artifactId' : 'Platform.LoadAdditionalDataYesNo_Now_button_eventHandlers_click_confirmADDownload',
                     'id' : 'aw7df27335',
                     'event' : 'click',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               },
               {
                     'method' : 'setBtLabelNowOrRefresh',
                     'artifactId' : 'Platform.LoadAdditionalDataYesNo_Retry_button_eventHandlers_render_setBtLabelNowOrRefresh',
                     'id' : 'aw83fe125f',
                     'event' : 'render',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               }
            ];
            button045.eventHandlers = eventHandlers116;
            container049.addChild( button045 );


            var button046 = new Button({
               'cssClass' : 'mblPrimaryButton dialogButton',
               'artifactId' : 'Platform.LoadAdditionalDataYesNo_Retry_button',
               'id' : 'aw626b616d',
               'label' : MessageService.createStaticMessage('Retry'),
            });
            var eventHandlers117 = [
               {
                     'method' : 'retryADDownload',
                     'artifactId' : 'Platform.LoadAdditionalDataYesNo_Retry_button_eventHandlers_click_retryADDownload',
                     'id' : 'aw7bef6fb1',
                     'event' : 'click',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               },
               {
                     'method' : 'renderRetryButton',
                     'artifactId' : 'Platform.LoadAdditionalDataYesNo_Retry_button_eventHandlers_render_retryADDownload',
                     'id' : 'awfa4998f7',
                     'event' : 'render',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               }
            ];
            button046.eventHandlers = eventHandlers117;
            container049.addChild( button046 );


            var dialog019 = new Dialog({
               'id' : 'Platform.LoadAdditionalDataDeltaDownload',
            });
            ui001.addChild( dialog019 );


            var container050 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.LoadAdditionalDataDeltaDownload_container_0',
               'id' : 'aw79883531',
            });
            dialog019.addChild( container050 );


            var text127 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.LoadAdditionalDataDeltaDownload_container_0_Thelookupdatafor',
               'id' : 'aw3d94f20f',
               'value' : MessageService.createStaticMessage('Click Changes to download only lookup data changes.'),
            });
            container050.addChild( text127 );


            var text128 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.LoadAdditionalDataDeltaDownload_container_0_Retrylookupdatafor',
               'id' : 'awa0f7541',
               'value' : MessageService.createStaticMessage('Click All to download all the lookup data.'),
            });
            container050.addChild( text128 );


            var text129 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.LoadAdditionalDataDeltaDownload_container_0_cancel',
               'id' : 'aw62270e4c',
               'value' : MessageService.createStaticMessage('Click Cancel to cancel the lookup download.'),
            });
            container050.addChild( text129 );


            var text130 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.LoadAdditionalDataDeltaDownload_container_0_action',
               'id' : 'aw73fd47ac',
               'value' : MessageService.createStaticMessage('Which refresh do you want to perform?'),
            });
            container050.addChild( text130 );


            var text131 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.LoadAdditionalDataDeltaDownload_container_0_Whenrunninginabr',
               'id' : 'aw37d29fd',
               'value' : MessageService.createStaticMessage('When running in a browser, a maximum of 200 records are downloaded per lookup.'),
            });
            container050.addChild( text131 );

            var eventHandlers118 = [
               {
                     'method' : 'showInPreview',
                     'artifactId' : 'Platform.LoadAdditionalDataDeltaDownload_container_0_Whenrunninginabr_eventHandlers_render_showInPreview',
                     'id' : 'aw1edf10f3',
                     'event' : 'render',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               }
            ];
            text131.eventHandlers = eventHandlers118;

            var container051 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.LoadAdditionalDataDeltaDownload_container_1',
               'id' : 'awe8f05a7',
            });
            dialog019.addChild( container051 );


            var button047 = new Button({
               'artifactId' : 'Platform.LoadAdditionalDataDeltaDownload_Cancel_button',
               'id' : 'awb2f881ae',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers119 = [
               {
                     'method' : 'closeDialogAndShowDefaultViewIfNeeded',
                     'artifactId' : 'Platform.LoadAdditionalDataDeltaDownload_Later_button_eventHandlers_click_closeDialogAndShowDefaultViewIfNeeded',
                     'id' : 'awcaa29f5a',
                     'event' : 'click',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               }
            ];
            button047.eventHandlers = eventHandlers119;
            container051.addChild( button047 );


            var button048 = new Button({
               'artifactId' : 'Platform.LoadAdditionalDataDeltaDownload_RefreshAll_button',
               'id' : 'aw8ab2882',
               'label' : MessageService.createStaticMessage('All'),
            });
            var eventHandlers120 = [
               {
                     'method' : 'confirmADDownload',
                     'artifactId' : 'Platform.LoadAdditionalDataDeltaDownload_Now_button_eventHandlers_click_confirmADDownload',
                     'id' : 'awa5526bd4',
                     'event' : 'click',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               }
            ];
            button048.eventHandlers = eventHandlers120;
            container051.addChild( button048 );


            var button049 = new Button({
               'cssClass' : 'mblPrimaryButton dialogButton',
               'artifactId' : 'Platform.LoadAdditionalDataDeltaDownload_RefreshChanges_button',
               'id' : 'aw9c0cf49a',
               'label' : MessageService.createStaticMessage('Changes'),
            });
            var eventHandlers121 = [
               {
                     'method' : 'confirmADDeltaDownload',
                     'artifactId' : 'Platform.LoadAdditionalDataDeltaDownload_Later_button_eventHandlers_click_confirmADDeltaDownload',
                     'id' : 'aw46619626',
                     'event' : 'click',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               }
            ];
            button049.eventHandlers = eventHandlers121;
            container051.addChild( button049 );


            var dialog020 = new Dialog({
               'id' : 'Platform.LoadSystemDataDeltaDownload',
            });
            ui001.addChild( dialog020 );


            var container052 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.LoadSystemDataDeltaDownload_container_0',
               'id' : 'aw47beed1c',
            });
            dialog020.addChild( container052 );


            var text132 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.LoadSystemDataDeltaDownload_container_0_Thelookupdatafor',
               'id' : 'aw682ebd2f',
               'value' : MessageService.createStaticMessage('Click Changes to download only the system data changes.'),
            });
            container052.addChild( text132 );


            var text133 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.LoadSystemDataDeltaDownload_container_0_Retrylookupdatafor',
               'id' : 'aw79e85858',
               'value' : MessageService.createStaticMessage('Click All to download all the system data.'),
            });
            container052.addChild( text133 );


            var text134 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.LoadSystemDataDeltaDownload_container_0_cancel',
               'id' : 'awcb50ae6',
               'value' : MessageService.createStaticMessage('Click Cancel to cancel the system download.'),
            });
            container052.addChild( text134 );


            var text135 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.LoadSystemDataDeltaDownload_container_0_action',
               'id' : 'aw1d6f4306',
               'value' : MessageService.createStaticMessage('Which refresh do you want to perform?'),
            });
            container052.addChild( text135 );


            var text136 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.LoadSystemDataDeltaDownload_container_0_Whenrunninginabr',
               'id' : 'aw56c766dd',
               'value' : MessageService.createStaticMessage('When running in a browser, a maximum of 200 records are downloaded per System.'),
            });
            container052.addChild( text136 );

            var eventHandlers122 = [
               {
                     'method' : 'showInPreview',
                     'artifactId' : 'Platform.LoadSystemDataDeltaDownload_container_0_Whenrunninginabr_eventHandlers_render_showInPreview',
                     'id' : 'aw37b2ac2a',
                     'event' : 'render',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               }
            ];
            text136.eventHandlers = eventHandlers122;

            var container053 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.LoadSystemDataDeltaDownload_container_1',
               'id' : 'aw30b9dd8a',
            });
            dialog020.addChild( container053 );


            var button050 = new Button({
               'artifactId' : 'Platform.LoadSystemDataDeltaDownload_Cancel_button',
               'id' : 'aw1adabf91',
               'label' : MessageService.createStaticMessage('cancel'),
            });
            var eventHandlers123 = [
               {
                     'method' : 'closeDialogAndShowDefaultViewIfNeeded',
                     'artifactId' : 'Platform.LoadSystemDataDeltaDownload_Later_button_eventHandlers_click_closeDialogAndShowDefaultViewIfNeeded',
                     'id' : 'aw2569598a',
                     'event' : 'click',
                     'class' : 'platform.handlers.SettingsHandler',
               }
            ];
            button050.eventHandlers = eventHandlers123;
            container053.addChild( button050 );


            var button051 = new Button({
               'artifactId' : 'Platform.LoadSystemDataDeltaDownload_RefreshAll_button',
               'id' : 'awf1a96515',
               'label' : MessageService.createStaticMessage('All'),
            });
            var eventHandlers124 = [
               {
                     'method' : 'downloadSystemData',
                     'artifactId' : 'Platform.LoadSystemDataDeltaDownload_Now_button_eventHandlers_click_confirmdownloadSystemData',
                     'id' : 'aw8d600b10',
                     'event' : 'click',
                     'class' : 'platform.handlers.SettingsHandler',
               }
            ];
            button051.eventHandlers = eventHandlers124;
            container053.addChild( button051 );


            var button052 = new Button({
               'cssClass' : 'mblPrimaryButton dialogButton',
               'artifactId' : 'Platform.LoadSystemDataDeltaDownload_RefreshChanges_button',
               'id' : 'aw328e1b2e',
               'label' : MessageService.createStaticMessage('Changes'),
            });
            var eventHandlers125 = [
               {
                     'method' : 'confirmSystemDataDeltaDownload',
                     'artifactId' : 'Platform.LoadSystemDataDeltaDownload_Later_button_eventHandlers_click_confirmSystemDataDeltaDownload',
                     'id' : 'awbd23e928',
                     'event' : 'click',
                     'class' : 'platform.handlers.SettingsHandler',
               }
            ];
            button052.eventHandlers = eventHandlers125;
            container053.addChild( button052 );


            var dialog021 = new Dialog({
               'id' : 'Platform.ExitApplicationPrompt',
            });
            ui001.addChild( dialog021 );


            var container054 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.ExitApplicationPrompt_container_0',
               'id' : 'aw71d2ddca',
            });
            dialog021.addChild( container054 );


            var text137 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.ExitApplicationPrompt_container_0_Doyouwanttoclose',
               'id' : 'aw4e0184c3',
               'value' : MessageService.createStaticMessage('Do you want to close the app?'),
            });
            container054.addChild( text137 );


            var container055 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.ExitApplicationPrompt_container_1',
               'id' : 'aw6d5ed5c',
            });
            dialog021.addChild( container055 );


            var button053 = new Button({
               'cssClass' : 'dialogButton',
               'artifactId' : 'Platform.ExitApplicationPrompt_Yes_button',
               'id' : 'aw3bff816',
               'label' : MessageService.createStaticMessage('Yes'),
            });
            var eventHandlers126 = [
               {
                     'method' : 'processDialog',
                     'artifactId' : 'Platform.ExitApplicationPrompt_Yes_button_eventHandlers_click_processDialog',
                     'id' : 'awfa220200',
                     'event' : 'click',
                     'class' : 'platform.handlers.DialogHandler',
               }
            ];
            button053.eventHandlers = eventHandlers126;
            container055.addChild( button053 );


            var button054 = new Button({
               'cssClass' : 'mblPrimaryButton dialogButton',
               'artifactId' : 'Platform.ExitApplicationPrompt_No_button',
               'id' : 'aw5ba5c9da',
               'label' : MessageService.createStaticMessage('No'),
            });
            var eventHandlers127 = [
               {
                     'method' : 'closeDialog',
                     'artifactId' : 'Platform.ExitApplicationPrompt_No_button_eventHandlers_click_closeDialog',
                     'id' : 'aw5256cc3',
                     'event' : 'click',
                     'class' : 'platform.handlers.DialogHandler',
               }
            ];
            button054.eventHandlers = eventHandlers127;
            container055.addChild( button054 );


            var dialog022 = new Dialog({
               'id' : 'Platform.LogOutPrompt',
            });
            ui001.addChild( dialog022 );


            var container056 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.LogOutPrompt_container_0',
               'id' : 'awcf20d41b',
            });
            dialog022.addChild( container056 );


            var text138 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.LogOutPrompt_container_0_Doyouwanttologo',
               'id' : 'aw15a96005',
               'value' : MessageService.createStaticMessage('Do you want to log out of the app?'),
            });
            container056.addChild( text138 );


            var container057 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.LogOutPrompt_container_1',
               'id' : 'awb827e48d',
            });
            dialog022.addChild( container057 );


            var button055 = new Button({
               'cssClass' : 'dialogButton',
               'artifactId' : 'Platform.LogOutPrompt_No_button',
               'id' : 'awfbbbd446',
               'label' : MessageService.createStaticMessage('No'),
            });
            var eventHandlers128 = [
               {
                     'method' : 'closeDialog',
                     'artifactId' : 'Platform.LogOutPrompt_No_button_eventHandlers_click_closeDialog',
                     'id' : 'aw364ad2c7',
                     'event' : 'click',
                     'class' : 'platform.handlers.DialogHandler',
               }
            ];
            button055.eventHandlers = eventHandlers128;
            container057.addChild( button055 );


            var button056 = new Button({
               'cssClass' : 'mblPrimaryButton dialogButton',
               'artifactId' : 'Platform.LogOutPrompt_Yes_button',
               'id' : 'awfaa63964',
               'label' : MessageService.createStaticMessage('Yes'),
            });
            var eventHandlers129 = [
               {
                     'method' : 'logoutDialog',
                     'artifactId' : 'Platform.LogOutPrompt_Yes_button_eventHandlers_click_logoutDialog',
                     'id' : 'aw82db52a6',
                     'event' : 'click',
                     'class' : 'platform.handlers.DialogHandler',
               }
            ];
            button056.eventHandlers = eventHandlers129;
            container057.addChild( button056 );


            var dialog023 = new Dialog({
               'cssClass' : 'dialogDurationLookup',
               'resource' : 'PlatformDateLookupResource',
               'id' : 'Platform.DurationLookup',
               'label' : MessageService.createStaticMessage('Change Duration'),
            });
            ui001.addChild( dialog023 );

            var eventHandlers130 = [
               {
                     'method' : 'initLookup',
                     'artifactId' : 'Platform.DurationLookup_eventHandlers_show_initLookup',
                     'id' : 'aw2898d5b1',
                     'event' : 'show',
                     'class' : 'platform.handlers.LookupHandler',
               }
            ];
            dialog023.eventHandlers = eventHandlers130;

            var container058 = new Container({
               'artifactId' : 'Platform.DurationLookup_container_0',
               'id' : 'awc7b6d6e2',
            });
            dialog023.addChild( container058 );


            var durationpicker001 = new DurationPicker({
               'artifactId' : 'Platform.DurationLookup_durationpicker_0',
               'id' : 'awbdafea4f',
            });
            container058.addChild( durationpicker001 );


            var container059 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.DurationLookup_container_1',
               'id' : 'awb0b1e674',
            });
            dialog023.addChild( container059 );


            var button057 = new Button({
               'artifactId' : 'Platform.DurationLookup_Cancel_button',
               'id' : 'aw21ee1a8e',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers131 = [
               {
                     'method' : 'Cancel',
                     'artifactId' : 'Platform.DurationLookup_Cancel_button_eventHandlers_click_Cancel',
                     'id' : 'aw7fc46e19',
                     'event' : 'click',
                     'class' : 'platform.handlers.LookupHandler',
               }
            ];
            button057.eventHandlers = eventHandlers131;
            container059.addChild( button057 );


            var button058 = new Button({
               'artifactId' : 'Platform.DurationLookup_Clear_button',
               'id' : 'awab5a917f',
               'label' : MessageService.createStaticMessage('Clear'),
            });
            var eventHandlers132 = [
               {
                     'method' : 'Clear',
                     'artifactId' : 'Platform.DurationLookup_Clear_button_eventHandlers_click_Clear',
                     'id' : 'aw4d23bc8f',
                     'event' : 'click',
                     'class' : 'platform.handlers.LookupHandler',
               }
            ];
            button058.eventHandlers = eventHandlers132;
            container059.addChild( button058 );


            var button059 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'Platform.DurationLookup_OK_button',
               'id' : 'aw7a6484f6',
               'label' : MessageService.createStaticMessage('OK'),
               'primary' : 'true',
            });
            var eventHandlers133 = [
               {
                     'method' : 'SetSelection',
                     'artifactId' : 'Platform.DurationLookup_OK_button_eventHandlers_click_SetSelection',
                     'id' : 'aweb8ce178',
                     'event' : 'click',
                     'class' : 'platform.handlers.LookupHandler',
               }
            ];
            button059.eventHandlers = eventHandlers133;
            container059.addChild( button059 );


            var dialog024 = new Dialog({
               'id' : 'Platform.CancelDownload',
            });
            ui001.addChild( dialog024 );


            var container060 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.CancelDownload_container_0',
               'id' : 'awf839de44',
            });
            dialog024.addChild( container060 );


            var text139 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.CancelDownload_container_0_Doyouwanttostop',
               'id' : 'awdb2316b3',
               'value' : MessageService.createStaticMessage('Do you want to stop downloading work list records?'),
            });
            container060.addChild( text139 );


            var container061 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.CancelDownload_container_1',
               'id' : 'aw8f3eeed2',
            });
            dialog024.addChild( container061 );


            var button060 = new Button({
               'cssClass' : 'mblPrimaryButton dialogButton',
               'artifactId' : 'Platform.CancelDownload_Yes_button',
               'id' : 'aw3b97968f',
               'label' : MessageService.createStaticMessage('Yes'),
            });
            var eventHandlers134 = [
               {
                     'method' : 'cancelDownload',
                     'artifactId' : 'Platform.CancelDownload_Yes_button_eventHandlers_click_cancelDownload',
                     'id' : 'awadc6ff1d',
                     'event' : 'click',
                     'class' : 'platform.handlers.WorkOfflineHandler',
               }
            ];
            button060.eventHandlers = eventHandlers134;
            container061.addChild( button060 );


            var button061 = new Button({
               'cssClass' : 'dialogButton',
               'artifactId' : 'Platform.CancelDownload_No_button',
               'id' : 'awab099478',
               'label' : MessageService.createStaticMessage('No'),
            });
            var eventHandlers135 = [
               {
                     'method' : 'closeDialog',
                     'artifactId' : 'Platform.CancelDownload_No_button_eventHandlers_click_closeDialog',
                     'id' : 'aw9ceda703',
                     'event' : 'click',
                     'class' : 'platform.handlers.DialogHandler',
               }
            ];
            button061.eventHandlers = eventHandlers135;
            container061.addChild( button061 );


            var dialog025 = new Dialog({
               'id' : 'Platform.ConfirmClearChanges',
            });
            ui001.addChild( dialog025 );


            var container062 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.ConfirmClearChanges_container_0',
               'id' : 'aw3965500f',
            });
            dialog025.addChild( container062 );


            var text140 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.ConfirmClearChanges_container_0_Changesthathaveno',
               'id' : 'aw66e22f87',
               'value' : MessageService.createStaticMessage('Changes that have not been sent to the server will be discarded.'),
            });
            container062.addChild( text140 );


            var container063 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.ConfirmClearChanges_container_1',
               'id' : 'aw4e626099',
            });
            dialog025.addChild( container063 );


            var button062 = new Button({
               'artifactId' : 'Platform.ConfirmClearChanges_Cancel_button',
               'id' : 'awcee54fe9',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers136 = [
               {
                     'method' : 'cancelClearChanges',
                     'artifactId' : 'Platform.ConfirmClearChanges_Cancel_button_eventHandlers_click_cancelClearChanges',
                     'id' : 'awb208eba2',
                     'event' : 'click',
                     'class' : 'platform.handlers.WorkOfflineHandler',
               }
            ];
            button062.eventHandlers = eventHandlers136;
            container063.addChild( button062 );


            var button063 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'Platform.ConfirmClearChanges_OK_button',
               'id' : 'aw8a3b05f2',
               'label' : MessageService.createStaticMessage('OK'),
            });
            var eventHandlers137 = [
               {
                     'method' : 'doClearChanges',
                     'artifactId' : 'Platform.ConfirmClearChanges_OK_button_eventHandlers_click_doClearChanges',
                     'id' : 'aw32f778d4',
                     'event' : 'click',
                     'class' : 'platform.handlers.WorkOfflineHandler',
               }
            ];
            button063.eventHandlers = eventHandlers137;
            container063.addChild( button063 );


            var dialog026 = new Dialog({
               'resource' : 'PlatformProgressResource',
               'id' : 'Platform.DownloadCurrentWorklist',
            });
            ui001.addChild( dialog026 );


            var container064 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.DownloadCurrentWorklist_container_0',
               'id' : 'awfd35c5df',
            });
            dialog026.addChild( container064 );


            var text141 = new Text({
               'resourceAttribute' : 'progressMsg',
               'editable' : false,
               'artifactId' : 'Platform.DownloadCurrentWorklist_container_0_progressMsg',
               'id' : 'aw3c55ae56',
            });
            container064.addChild( text141 );


            var container065 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.DownloadCurrentWorklist_container_1',
               'id' : 'aw8a32f549',
            });
            dialog026.addChild( container065 );


            var button064 = new Button({
               'artifactId' : 'Platform.DownloadCurrentWorklist_Cancel_button',
               'id' : 'awcfb8296d',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers138 = [
               {
                     'method' : 'cancelDownload',
                     'artifactId' : 'Platform.DownloadCurrentWorklist_Cancel_button_eventHandlers_click_cancelDownload',
                     'id' : 'aw5541afbb',
                     'event' : 'click',
                     'class' : 'platform.handlers.WorkOfflineHandler',
               }
            ];
            button064.eventHandlers = eventHandlers138;
            container065.addChild( button064 );


            var dialog027 = new Dialog({
               'id' : 'Platform.NoRecordFoundDialog',
            });
            ui001.addChild( dialog027 );


            var container066 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.NoRecordFoundDialog_container_0',
               'id' : 'awa73a1c57',
            });
            dialog027.addChild( container066 );


            var text142 = new Text({
               'artifactId' : 'Platform.NoRecordFoundDialog_container_0_Stopthetimeronwo',
               'id' : 'awd6cf8f25',
               'value' : MessageService.createStaticMessage('No record was found. If you are working offline, try downloading worklist when online to access your workorder'),
            });
            container066.addChild( text142 );


            var container067 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.NoRecordFoundDialog_container_1',
               'id' : 'awd03d2cc1',
            });
            dialog027.addChild( container067 );


            var button065 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'Platform.NoRecordFoundDialog_OK_button',
               'id' : 'aw3de0cad2',
               'label' : MessageService.createStaticMessage('Close'),
            });
            var eventHandlers139 = [
               {
                     'method' : 'closeNoRecord',
                     'artifactId' : 'Platform.NoRecordFoundDialog_OK_button_multiple',
                     'id' : 'aw41a4b840',
                     'event' : 'click',
                     'class' : 'platform.handlers.PushNotificationDialogHandler',
               }
            ];
            button065.eventHandlers = eventHandlers139;
            container067.addChild( button065 );


            var dialog028 = new Dialog({
               'id' : 'Platform.MultiplePushNotificationDialog',
            });
            ui001.addChild( dialog028 );


            var container068 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.MultiplePushNotificationDialog_container_0',
               'id' : 'aw7b338e5e',
            });
            dialog028.addChild( container068 );


            var text143 = new Text({
               'artifactId' : 'Platform.MultiplePushNotificationDialog_container_0_Stopthetimeronwo',
               'id' : 'aw72fc5fcc',
               'value' : MessageService.createStaticMessage('Multiple notification were recieved. Go to notification view to access them.'),
            });
            container068.addChild( text143 );


            var container069 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.MultiplePushNotificationDialog_container_1',
               'id' : 'awc34bec8',
            });
            dialog028.addChild( container069 );


            var button066 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'Platform.MultiplePushNotificationDialog_OK_button',
               'id' : 'awc2c9277e',
               'label' : MessageService.createStaticMessage('Close'),
            });
            var eventHandlers140 = [
               {
                     'method' : 'close',
                     'artifactId' : 'Platform.MultiplePushNotificationDialog_OK_button_multiple',
                     'id' : 'awe5002e8b',
                     'event' : 'click',
                     'class' : 'platform.handlers.PushNotificationDialogHandler',
               }
            ];
            button066.eventHandlers = eventHandlers140;
            container069.addChild( button066 );


            var dialog029 = new Dialog({
               'resource' : 'PlatformTempPushNotification',
               'id' : 'Platform.PushNotificationDialog',
            });
            ui001.addChild( dialog029 );


            var container070 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.PushNotificationDialog_container_0',
               'id' : 'awb0eedc9',
            });
            dialog029.addChild( container070 );


            var text144 = new Text({
               'artifactId' : 'Platform.PushNotificationDialog_container_0_Stopthetimeronwo',
               'id' : 'aw35fc28ff',
               'value' : MessageService.createDynamicMessage('{0} {1} {2}', 'platform.handlers.PushNotificationDialogHandler', 'resolveMessageProps'),
               'resolverFunction' : 'resolveMessageProps',
               'resolverClass' : 'platform.handlers.PushNotificationDialogHandler',
            });
            container070.addChild( text144 );


            var container071 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.PushNotificationDialog_container_1',
               'id' : 'aw7c09dd5f',
            });
            dialog029.addChild( container071 );


            var button067 = new Button({
               'artifactId' : 'Platform.PushNotificationDialog_Open_button',
               'id' : 'aw4151795',
               'label' : MessageService.createStaticMessage('Open'),
            });
            var eventHandlers141 = [
               {
                     'method' : 'openRecord',
                     'artifactId' : 'Platform.PushNotificationDialog_Open_button_eventHandlers_click_WOStartedDialogNoClickHandler',
                     'id' : 'aw32cc643',
                     'event' : 'click',
                     'class' : 'platform.handlers.PushNotificationDialogHandler',
               },
               {
                     'method' : 'renderOpen',
                     'artifactId' : 'Platform.PushNotificationDialog_Open_button_eventHandlers_render_RenderOpenButton',
                     'id' : 'awff1adc93',
                     'event' : 'render',
                     'class' : 'platform.handlers.PushNotificationDialogHandler',
               }
            ];
            button067.eventHandlers = eventHandlers141;
            container071.addChild( button067 );


            var button068 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'Platform.PushNotificationDialog_OK_button',
               'id' : 'aw3d64070a',
               'label' : MessageService.createStaticMessage('OK'),
            });
            var eventHandlers142 = [
               {
                     'method' : 'close',
                     'artifactId' : 'Platform.PushNotificationDialog_OK_button_eventHandlers_click_WOStartedDialogYesClickHandler',
                     'id' : 'aw40f88c32',
                     'event' : 'click',
                     'class' : 'platform.handlers.PushNotificationDialogHandler',
               }
            ];
            button068.eventHandlers = eventHandlers142;
            container071.addChild( button068 );


            var dialog030 = new Dialog({
               'resource' : 'PlatformDemoModeResource',
               'id' : 'Platform.DemoDownloadWarning',
            });
            ui001.addChild( dialog030 );


            var container072 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.DemoDownloadWarning_container_0',
               'id' : 'awf840ab79',
            });
            dialog030.addChild( container072 );


            var text145 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.DemoDownloadWarning_container_0_progressMsg',
               'id' : 'awf3cb0903',
               'value' : MessageService.createStaticMessage('MessageText'),
            });
            container072.addChild( text145 );


            var container073 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.DemoDownloadWarning_container_1',
               'id' : 'aw8f479bef',
            });
            dialog030.addChild( container073 );


            var button069 = new Button({
               'artifactId' : 'Platform.DemoDownloadWarning_Continue_button',
               'id' : 'aw2659f8c8',
               'label' : MessageService.createStaticMessage('Continue'),
            });
            var eventHandlers143 = [
               {
                     'method' : 'doClearChanges',
                     'artifactId' : 'Platform.DemoDownloadWarning_Continue_button_eventHandlers_click_doClearChanges',
                     'id' : 'awbdf1879f',
                     'event' : 'click',
                     'class' : 'platform.handlers.WorkOfflineHandler',
               }
            ];
            button069.eventHandlers = eventHandlers143;
            container073.addChild( button069 );


            var button070 = new Button({
               'artifactId' : 'Platform.DemoDownloadWarning_Cancel_button',
               'id' : 'aw9def7b28',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers144 = [
               {
                     'method' : 'cancelDownload',
                     'artifactId' : 'Platform.DemoDownloadWarning_Cancel_button_eventHandlers_click_cancelDownload',
                     'id' : 'awd4960a86',
                     'event' : 'click',
                     'class' : 'platform.handlers.WorkOfflineHandler',
               }
            ];
            button070.eventHandlers = eventHandlers144;
            container073.addChild( button070 );


            var dialog031 = new Dialog({
               'resource' : 'PlatformEsigResource',
               'id' : 'Platform.EsigLoginView',
               'label' : MessageService.createStaticMessage('Electronic Signature Authentication'),
            });
            ui001.addChild( dialog031 );

            var requiredResources023 = {
               'attemptResultDomain' : {
                  'enableFeatureByProperty' : 'esig.enabled',
                  'artifactId' : 'Platform.EsigLoginView_attemptResultDomain',
                  'id' : 'aw3c53638b',
               },
            };
            dialog031.addRequiredResources( requiredResources023 );

            var container074 = new Container({
               'artifactId' : 'Platform.EsigLoginView_container_0',
               'id' : 'aw44fd9611',
            });
            dialog031.addChild( container074 );


            var group020 = new Group({
               'artifactId' : 'Platform.EsigLoginView_group_0',
               'id' : 'aw7bf6135f',
            });
            container074.addChild( group020 );


            var groupitem067 = new GroupItem({
               'artifactId' : 'Platform.EsigLoginView_group_0_groupitem_1',
               'id' : 'aw209714b9',
            });
            group020.addChild( groupitem067 );


            var text146 = new Text({
               'border' : 'true',
               'resourceAttribute' : 'userName',
               'cssClass' : 'loginUsername',
               'editable' : false,
               'artifactId' : 'Platform.EsigLoginView_container_0_username',
               'id' : 'aw15aabb30',
               'label' : MessageService.createStaticMessage('User Name'),
               'placeHolder' : MessageService.createStaticMessage('User name'),
            });
            groupitem067.addChild( text146 );


            var text147 = new Text({
               'border' : 'true',
               'resourceAttribute' : 'password',
               'cssClass' : 'loginPassword',
               'editable' : true,
               'artifactId' : 'Platform.EsigLoginView_container_0_password',
               'id' : 'awd836fb92',
               'label' : MessageService.createStaticMessage('Password'),
               'type' : 'password',
               'placeHolder' : MessageService.createStaticMessage('Password'),
               'required' : true,
            });
            groupitem067.addChild( text147 );


            var text148 = new Text({
               'resourceAttribute' : 'reason',
               'cssClass' : 'loginUsername',
               'editable' : true,
               'artifactId' : 'Platform.EsigLoginView_container_0_reason',
               'id' : 'aw6ccf562d',
               'label' : MessageService.createStaticMessage('Reason for Change'),
               'placeHolder' : MessageService.createStaticMessage('Reason for Change'),
               'required' : true,
            });
            groupitem067.addChild( text148 );


            var container075 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.EsigLoginView_footer',
               'id' : 'aw68d6d11c',
            });
            dialog031.addChild( container075 );


            var button071 = new Button({
               'artifactId' : 'Platform.EsigLoginView_Cancel_button',
               'id' : 'aw68a36a2b',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers145 = [
               {
                     'method' : 'cancelEsig',
                     'artifactId' : 'Platform.EsigLoginView_Cancel_button_eventHandlers_click_cancelEsig',
                     'id' : 'awdba9800d',
                     'event' : 'click',
                     'class' : 'platform.handlers.EsigHandler',
               }
            ];
            button071.eventHandlers = eventHandlers145;
            container075.addChild( button071 );


            var button072 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'Platform.EsigLoginView_Save_button',
               'id' : 'awef41b275',
               'label' : MessageService.createStaticMessage('OK'),
               'primary' : 'true',
            });
            var eventHandlers146 = [
               {
                     'method' : 'submitEsig',
                     'artifactId' : 'Platform.EsigLoginView_Save_button_eventHandlers_click_submitEsig',
                     'id' : 'awa9f3497f',
                     'event' : 'click',
                     'class' : 'platform.handlers.EsigHandler',
               }
            ];
            button072.eventHandlers = eventHandlers146;
            container075.addChild( button072 );

            var eventHandlers147 = [
               {
                     'method' : 'initializeEsig',
                     'artifactId' : 'Platform.EsigLoginView_eventHandlers_show_initializeEsig',
                     'id' : 'aw681e6384',
                     'event' : 'show',
                     'class' : 'platform.handlers.EsigHandler',
               }
            ];
            dialog031.eventHandlers = eventHandlers147;

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'Platform.Signature', false);
               trackTimer.startTracking();
            }

            var view025 = new View({
               'id' : 'Platform.Signature',
               'label' : MessageService.createStaticMessage('Capture Real Signature'),
            });
            ui001.addChild( view025 );

            var requiredResources024 = {
               'PlatformAttachmentInfoResource' : {
                  'artifactId' : 'Platform.Signature_PlatformAttachmentInfoResource',
                  'id' : 'aw8cc44736',
               },
            };
            view025.addRequiredResources( requiredResources024 );

            var footer007 = new Footer({
               'artifactId' : 'Platform.Signature_footer',
               'id' : 'aw16b9ee39',
            });
            view025.addChild( footer007 );


            var button073 = new Button({
               'artifactId' : 'Platform.Signature_Cancel_button',
               'id' : 'aw9088fe5b',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers148 = [
               {
                     'method' : 'cancelSignature',
                     'artifactId' : 'Platform.Signature_Cancel_button_eventHandlers_click_handleBackButtonClickEditAssetView',
                     'id' : 'awc27cd6a4',
                     'event' : 'click',
                     'class' : 'platform.signature.handler.SignatureHandler',
               }
            ];
            button073.eventHandlers = eventHandlers148;
            footer007.addChild( button073 );


            var button074 = new Button({
               'artifactId' : 'Platform.Signature_Clear_button',
               'id' : 'awc6576044',
               'label' : MessageService.createStaticMessage('Clear'),
            });
            var eventHandlers149 = [
               {
                     'method' : 'clearSignature',
                     'artifactId' : 'Platform.Signature_Clear_button_eventHandlers_click_handleBackButtonClickEditAssetView',
                     'id' : 'aw90653ab1',
                     'event' : 'click',
                     'class' : 'platform.signature.handler.SignatureHandler',
               }
            ];
            button074.eventHandlers = eventHandlers149;
            footer007.addChild( button074 );


            var button075 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'Platform.Signature_Save_button',
               'id' : 'awbc1f2293',
               'label' : MessageService.createStaticMessage('Save'),
               'primary' : 'true',
            });
            var eventHandlers150 = [
               {
                     'method' : 'saveSignature',
                     'artifactId' : 'Platform.Signature_Save_button_eventHandlers_click_saveSignature',
                     'id' : 'aw7d8e432b',
                     'event' : 'click',
                     'class' : 'platform.signature.handler.SignatureHandler',
               }
            ];
            button075.eventHandlers = eventHandlers150;
            footer007.addChild( button075 );

            var eventHandlers151 = [
               {
                     'method' : 'initSignature',
                     'artifactId' : 'Platform.Signature_eventHandlers_show_initStopWorkView',
                     'id' : 'awb8cf4cb7',
                     'event' : 'initialize',
                     'class' : 'platform.signature.handler.SignatureHandler',
               }
            ];
            view025.eventHandlers = eventHandlers151;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            var dialog032 = new Dialog({
               'id' : 'Platform.SignatureDialog',
            });
            ui001.addChild( dialog032 );


            var container076 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.SignatureDialog_container_buttons',
               'id' : 'aw91450791',
            });
            dialog032.addChild( container076 );


            var button076 = new Button({
               'cssClass' : 'dialogButton',
               'artifactId' : 'Platform.SignatureDialog_container_buttons_Cancel_button',
               'id' : 'aw51ebe6e8',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers152 = [
               {
                     'method' : 'cancelSignatureDialog',
                     'artifactId' : 'Platform.SignatureDialog_container_buttons_Cancel_button_eventHandlers_click_handleBackButtonClickEditAssetView',
                     'id' : 'aw198ca753',
                     'event' : 'click',
                     'class' : 'platform.signature.handler.SignatureHandler',
               }
            ];
            button076.eventHandlers = eventHandlers152;
            container076.addChild( button076 );


            var button077 = new Button({
               'cssClass' : 'dialogButton',
               'artifactId' : 'Platform.SignatureDialog_container_buttons_clear_button',
               'id' : 'awdc63a382',
               'label' : MessageService.createStaticMessage('Clear'),
            });
            var eventHandlers153 = [
               {
                     'method' : 'clearSignature',
                     'artifactId' : 'Platform.SignatureDialog_container_buttons_clear_button_eventHandlers_click_handleBackButtonClickEditAssetView',
                     'id' : 'aw72eacc40',
                     'event' : 'click',
                     'class' : 'platform.signature.handler.SignatureHandler',
               }
            ];
            button077.eventHandlers = eventHandlers153;
            container076.addChild( button077 );


            var button078 = new Button({
               'cssClass' : 'mblPrimaryButton dialogButton',
               'artifactId' : 'Platform.SignatureDialog_container_buttons_Save_button',
               'id' : 'awd4941650',
               'label' : MessageService.createStaticMessage('Save'),
               'primary' : 'true',
            });
            var eventHandlers154 = [
               {
                     'method' : 'saveSignature',
                     'artifactId' : 'Platform.SignatureDialog_container_buttons_Save_button_eventHandlers_click_saveSignature',
                     'id' : 'awa59c7577',
                     'event' : 'click',
                     'class' : 'platform.signature.handler.SignatureHandler',
               }
            ];
            button078.eventHandlers = eventHandlers154;
            container076.addChild( button078 );

            var eventHandlers155 = [
               {
                     'method' : 'initSignature',
                     'artifactId' : 'Platform.SignatureDialog_eventHandlers_show_initStopWorkView',
                     'id' : 'aw71e7bce4',
                     'event' : 'show',
                     'class' : 'platform.signature.handler.SignatureHandler',
               }
            ];
            dialog032.eventHandlers = eventHandlers155;
            app001.addHandler( {name : 'application.handlers.SRAttachmentHandler', 'class': new SRAttachmentHandler()} );
            app001.addHandler( {name : 'application.handlers.SRDetailHandler', 'class': new SRDetailHandler()} );
            app001.addHandler( {name : 'application.handlers.WorkLogHandler', 'class': new WorkLogHandler()} );
            app001.addHandler( {name : 'platform.handlers.AdditionalDataDialogHandler', 'class': new AdditionalDataDialogHandler()} );
            app001.addHandler( {name : 'platform.handlers.AttachmentHandler', 'class': new AttachmentHandler()} );
            app001.addHandler( {name : 'platform.handlers.ChangePasswordHandler', 'class': new ChangePasswordHandler()} );
            app001.addHandler( {name : 'platform.handlers.CreateQueryBaseHandler', 'class': new CreateQueryBaseHandler()} );
            app001.addHandler( {name : 'platform.handlers.DialogHandler', 'class': new DialogHandler()} );
            app001.addHandler( {name : 'platform.handlers.EsigHandler', 'class': new EsigHandler()} );
            app001.addHandler( {name : 'platform.handlers.LoginHandler', 'class': new LoginHandler()} );
            app001.addHandler( {name : 'platform.handlers.LookupHandler', 'class': new LookupHandler()} );
            app001.addHandler( {name : 'platform.handlers.PseudoOfflineModeHandler', 'class': new PseudoOfflineModeHandler()} );
            app001.addHandler( {name : 'platform.handlers.PushNotificationDialogHandler', 'class': new PushNotificationDialogHandler()} );
            app001.addHandler( {name : 'platform.handlers.SSOHandler', 'class': new SSOHandler()} );
            app001.addHandler( {name : 'platform.handlers.SettingsHandler', 'class': new SettingsHandler()} );
            app001.addHandler( {name : 'platform.handlers.WorkOfflineHandler', 'class': new WorkOfflineHandler()} );
            app001.addHandler( {name : 'platform.handlers._ApplicationHandlerBase', 'class': new _ApplicationHandlerBase()} );
            app001.addHandler( {name : 'platform.logging.handler.LoggerReportHandler', 'class': new LoggerReportHandler()} );
            app001.addHandler( {name : 'platform.performance.handler.TimeTrackHandler', 'class': new TimeTrackHandler()} );
            app001.addHandler( {name : 'platform.signature.handler.SignatureHandler', 'class': new SignatureHandler()} );


            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating Resources in ApplicationUIBuilder', false);
               trackTimer.startTracking();
            }
            var that001 = this;
            all([
               app001.createResource(null, null, 'PlatformDemoModeResource'),
               app001.createResource(null, null, 'LastADDownload'),
               app001.createResource(null, null, 'DeviceSizeResource'),
               app001.createResource(null, null, 'SSODialogResource'),
               app001.createResource(null, null, 'PlatformLongPressResource'),
               app001.createResource(null, null, 'PlatformDateLookupResource')
            ]).then(
               function(){
                  that001.addApplication( app001 );
               }
            );

            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }
            console.log('Finished Creating App');
         }
      });
});
