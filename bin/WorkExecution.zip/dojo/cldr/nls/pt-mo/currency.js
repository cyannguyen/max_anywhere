define(
//begin v1.x content
{
	"MOP_symbol": "MOP$"
}
//end v1.x content
);