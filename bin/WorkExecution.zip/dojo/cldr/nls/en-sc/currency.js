define(
//begin v1.x content
{
	"SCR_symbol": "SR",
	"USD_symbol": "US$"
}
//end v1.x content
);