define(
//begin v1.x content
{
	"COP_symbol": "$"
}
//end v1.x content
);