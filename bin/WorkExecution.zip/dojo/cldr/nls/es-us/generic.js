define(
//begin v1.x content
{
	"dateFormatItem-yMd": "M/d/y",
	"dateFormat-medium": "MMM d, y G",
	"dateFormatItem-MMMEd": "E, MMM d",
	"dateFormatItem-MEd": "E, MM/dd",
	"dateFormatItem-yMEd": "E, M/d/y",
	"dateFormatItem-yMMMd": "MMM d, y",
	"timeFormat-full": "h:mm:ss a zzzz",
	"dateFormatItem-Md": "M/d",
	"dayPeriods-format-wide-pm": "PM",
	"dateFormatItem-MMd": "MM/d",
	"dayPeriods-format-wide-am": "AM",
	"timeFormat-medium": "h:mm:ss a",
	"dateFormat-short": "M/d/yy GGGGG",
	"dateFormatItem-yMMMEd": "E, MMM d, y",
	"dateFormatItem-yM": "M/y",
	"timeFormat-short": "h:mm a",
	"timeFormat-long": "h:mm:ss a z",
	"dateFormatItem-MMMd": "MMM d"
}
//end v1.x content
);