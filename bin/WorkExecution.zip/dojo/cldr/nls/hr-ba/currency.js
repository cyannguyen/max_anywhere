define(
//begin v1.x content
{
	"BAM_symbol": "KM"
}
//end v1.x content
);