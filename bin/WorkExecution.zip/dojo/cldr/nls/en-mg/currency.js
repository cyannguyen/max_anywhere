define(
//begin v1.x content
{
	"MGA_symbol": "Ar",
	"USD_symbol": "US$"
}
//end v1.x content
);