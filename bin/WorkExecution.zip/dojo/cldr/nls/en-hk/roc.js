define(
//begin v1.x content
{
	"field-year-relative+0": "This Year",
	"field-year-relative+1": "Next Year",
	"field-week-relative+1": "Next Week",
	"dateFormat-medium": "d MMM, y G",
	"dateFormat-full": "EEEE, d MMMM, y G",
	"dateFormat-short": "d/M/yy GGGGG",
	"field-year-relative+-1": "Last Year",
	"dateFormat-long": "d MMMM, y G",
	"dateFormatItem-MMMEd": "E, d MMM"
}
//end v1.x content
);