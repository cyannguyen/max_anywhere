define(
//begin v1.x content
{
	"group": "."
}
//end v1.x content
);