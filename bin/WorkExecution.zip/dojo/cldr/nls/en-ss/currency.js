define(
//begin v1.x content
{
	"GBP_symbol": "GB£",
	"SSP_symbol": "£",
	"USD_symbol": "US$"
}
//end v1.x content
);