define(
//begin v1.x content
{
	"TND_symbol": "DT"
}
//end v1.x content
);