define(
//begin v1.x content
{
	"PTE_decimal": ",",
	"PTE_group": " ",
	"CVE_decimal": "$"
}
//end v1.x content
);