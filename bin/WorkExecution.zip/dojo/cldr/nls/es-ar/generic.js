define(
//begin v1.x content
{
	"timeFormat-long": "H:mm:ss z",
	"dateFormatItem-MEd": "E d-M",
	"timeFormat-full": "HH'h'''mm:ss zzzz",
	"dateFormatItem-yM": "M-y"
}
//end v1.x content
);