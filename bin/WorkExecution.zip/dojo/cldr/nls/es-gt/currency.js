define(
//begin v1.x content
{
	"GTQ_symbol": "Q"
}
//end v1.x content
);