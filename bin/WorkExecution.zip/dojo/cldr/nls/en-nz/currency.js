define(
//begin v1.x content
{
	"NZD_symbol": "$",
	"USD_symbol": "US$"
}
//end v1.x content
);