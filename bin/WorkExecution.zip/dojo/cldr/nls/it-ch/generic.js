define(
//begin v1.x content
{
	"dateFormat-short": "dd.MM.yy GGGGG",
	"dateFormat-medium": "d-MMM-y G",
	"dateFormat-long": "d MMMM y G",
	"dateFormat-full": "EEEE, d MMMM y G"
}
//end v1.x content
);