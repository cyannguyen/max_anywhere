define(
//begin v1.x content
{
	"JMD_symbol": "$",
	"USD_symbol": "US$"
}
//end v1.x content
);