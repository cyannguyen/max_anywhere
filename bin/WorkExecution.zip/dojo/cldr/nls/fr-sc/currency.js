define(
//begin v1.x content
{
	"SCR_symbol": "SR"
}
//end v1.x content
);