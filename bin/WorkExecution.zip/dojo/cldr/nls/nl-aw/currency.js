define(
//begin v1.x content
{
	"AWG_symbol": "Afl."
}
//end v1.x content
);