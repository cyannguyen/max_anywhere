define(
//begin v1.x content
{
	"dateFormat-medium": "G y-MM-dd",
	"field-year-relative+-1": "L'année dernière",
	"dateFormatItem-MMdd": "MM-dd",
	"dateFormatItem-MEd": "E M-d",
	"field-month-relative+-1": "Le mois dernier",
	"dateFormatItem-Md": "M-d",
	"dateFormatItem-yyyyMEd": "E G y-MM-dd",
	"field-week-relative+0": "Cette semaine",
	"dateFormatItem-MMd": "MM-d",
	"field-week-relative+1": "La semaine prochaine",
	"dateFormatItem-yyyyMM": "G y-MM",
	"field-week-relative+-1": "La semaine dernière",
	"field-month-relative+0": "Ce mois-ci",
	"field-month-relative+1": "Le mois prochain",
	"dateFormat-short": "GGGGG yy-MM-dd",
	"field-year-relative+0": "Cette année",
	"field-year-relative+1": "L'année prochaine",
	"dateFormatItem-yyyyM": "G y-MM",
	"dateFormatItem-yyyyMd": "G y-MM-dd"
}
//end v1.x content
);