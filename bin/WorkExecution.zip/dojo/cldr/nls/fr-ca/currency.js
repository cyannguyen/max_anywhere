define(
//begin v1.x content
{
	"PGK_symbol": "PGK",
	"AFN_symbol": "AFN",
	"MVR_symbol": "MVR",
	"XOF_symbol": "F CFA",
	"VUV_symbol": "VUV",
	"IDR_symbol": "IDR",
	"WST_symbol": "WST",
	"CAD_symbol": "$",
	"DJF_symbol": "DJF",
	"MYR_symbol": "MYR",
	"BAM_symbol": "BAM",
	"MMK_symbol": "MMK",
	"BDT_symbol": "BDT",
	"CNY_symbol": "CN¥",
	"MNT_symbol": "MNT",
	"TOP_symbol": "TOP"
}
//end v1.x content
);