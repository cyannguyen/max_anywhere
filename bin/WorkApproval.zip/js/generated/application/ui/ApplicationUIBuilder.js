/* 
 * Licensed Materials - Property of IBM
 * "Restricted Materials of IBM"
 *
 * 5725-M39
 *
 * (C) COPYRIGHT IBM CORP. 2021 All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with
 * IBM Corp. 
 *
 */
 
//----------------------------------------------------------------//
// This is auto generated code. Do not modify it manually.
// Product and Version: IBM Maximo Anywhere Version 7.5
// Build: 2021-06-01 07:38:00
//----------------------------------------------------------------//
define(   "generated/application/ui/ApplicationUIBuilder", 
      [
         "dojo/_base/declare", 
         "dojo/promise/all", 
         "platform/ui/builder/_UIBuilderBase", 
         "dojo/_base/window", 
         "dojo/_base/array", 
         "dojo/io-query", 
         "platform/model/AdditionalDataManager", 
         "platform/model/AdditionalDataUIManager", 
         "platform/translation/MessageService", 
         "platform/ui/control/Application", 
         "platform/ui/control/UserInterface", 
         "platform/ui/control/Dialog", 
         "platform/ui/control/Container", 
         "platform/ui/control/Text", 
         "platform/ui/control/Button", 
         "platform/handlers/SSOHandler", 
         "platform/handlers/LoginHandler", 
         "platform/ui/control/View", 
         "platform/ui/control/Image", 
         "platform/handlers/_ApplicationHandlerBase", 
         "platform/ui/control/Queries", 
         "platform/ui/control/Query", 
         "application/handlers/WOListHandler", 
         "platform/ui/control/Actions", 
         "platform/ui/control/Action", 
         "platform/handlers/WorkOfflineHandler", 
         "platform/ui/control/ProgressIndicator", 
         "platform/ui/control/List", 
         "platform/ui/control/SortOptions", 
         "platform/ui/control/SortOption", 
         "platform/ui/control/SortAttribute", 
         "platform/ui/control/ListItemTemplate", 
         "platform/ui/control/ListText", 
         "application/handlers/StatusChangeHandler", 
         "application/handlers/WODetailsHandler", 
         "platform/ui/control/ErrorIndicator", 
         "platform/ui/control/Group", 
         "platform/ui/control/GroupItem", 
         "application/handlers/WorkLogHandler", 
         "platform/ui/control/LastUpdateText", 
         "platform/ui/control/Footer", 
         "platform/ui/control/CheckBox", 
         "platform/ui/control/TextArea", 
         "platform/ui/control/Lookup", 
         "platform/ui/control/SearchAttributes", 
         "platform/ui/control/SearchAttribute", 
         "platform/ui/control/ReturnAttributes", 
         "platform/ui/control/ReturnAttribute", 
         "platform/handlers/AttachmentHandler", 
         "platform/handlers/PseudoOfflineModeHandler", 
         "platform/handlers/CreateQueryBaseHandler", 
         "platform/ui/control/ErrorActions", 
         "platform/handlers/LookupHandler", 
         "platform/handlers/PushNotificationDialogHandler", 
         "platform/ui/control/DateTimePicker", 
         "platform/handlers/SettingsHandler", 
         "platform/handlers/ChangePasswordHandler", 
         "platform/handlers/AdditionalDataDialogHandler", 
         "platform/ui/control/RadioButton", 
         "platform/logging/handler/LoggerReportHandler", 
         "platform/performance/handler/TimeTrackHandler", 
         "platform/handlers/DialogHandler", 
         "platform/ui/control/DurationPicker", 
         "platform/handlers/EsigHandler", 
         "platform/signature/handler/SignatureHandler"
      ],

function(declare, all, BuilderBase, window, array, ioQuery, AdditionalDataManager, AdditionalDataUIManager, MessageService, Application, UserInterface, Dialog, Container, Text, Button, SSOHandler, LoginHandler, View, Image, _ApplicationHandlerBase, Queries, Query, WOListHandler, Actions, Action, WorkOfflineHandler, ProgressIndicator, List, SortOptions, SortOption, SortAttribute, ListItemTemplate, ListText, StatusChangeHandler, WODetailsHandler, ErrorIndicator, Group, GroupItem, WorkLogHandler, LastUpdateText, Footer, CheckBox, TextArea, Lookup, SearchAttributes, SearchAttribute, ReturnAttributes, ReturnAttribute, AttachmentHandler, PseudoOfflineModeHandler, CreateQueryBaseHandler, ErrorActions, LookupHandler, PushNotificationDialogHandler, DateTimePicker, SettingsHandler, ChangePasswordHandler, AdditionalDataDialogHandler, RadioButton, LoggerReportHandler, TimeTrackHandler, DialogHandler, DurationPicker, EsigHandler, SignatureHandler) {
      return declare("generated.application.ui.ApplicationUIBuilder", BuilderBase, {

         build : function() {
            console.log('Creating App');

            MessageService.init('artifact');


            var app001 = new Application({
               'logLevel' : 0,
               'xsi:noNamespaceSchemaLocation' : '..\/..\/..\/build\/app.xsd',
               'xmlns:xsi' : 'http:\/\/www.w3.org\/2001\/XMLSchema-instance',
               'id' : 'WorkApproval',
               'blindQuerySupport' : 'false',
               'version' : '201507140725',
               'requiredRole' : 'ANYWHERE_APPROVER',
            });
            app001.setFeatures({
            'update.artifact.timestamps' : false,
            'esig.enabled' : true,
            'gps.enabled' : false,
            'enableDataEncryption' : true,
            'barcode.enabled' : false,
            'attachments.enabled' : false,
            'globalization.use.mock' : false,
            'run.bvt.scripts' : false,
            'build.update.check.enabled' : true,
            'pushnotification.enabled' : false,
            'map.enabled' : false,

            });

            var ui001 = new UserInterface({
               'artifactId' : 'ui',
               'id' : 'aw27ff46b0',
            });
            app001.addChild( ui001 );
            AdditionalDataManager._setAdditionalDataUIManager(new AdditionalDataUIManager(ui001));

            var dialog001 = new Dialog({
               'id' : 'Platform.SSOError',
               'label' : MessageService.createStaticMessage('SSO Login Error'),
            });
            ui001.addChild( dialog001 );


            var container001 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'resource' : 'SSODialogResource',
               'artifactId' : 'Platform.SSOError_SSODialogResource_container_0',
               'id' : 'aw8b213d94',
            });
            dialog001.addChild( container001 );


            var text001 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.SSOError_SSODialogResource_container_0_ErrorusingSSOLogi',
               'id' : 'awa51c0f06',
               'value' : MessageService.createStaticMessage('Error using SSO Login'),
            });
            container001.addChild( text001 );


            var text002 = new Text({
               'resourceAttribute' : 'errorMsg',
               'editable' : false,
               'artifactId' : 'Platform.SSOError_SSODialogResource_container_0_errorMsg',
               'id' : 'awf2a9265',
            });
            container001.addChild( text002 );


            var container002 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.SSOError_container_0',
               'id' : 'awbf273d01',
            });
            dialog001.addChild( container002 );


            var button001 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'Platform.SSOError_Retry_button',
               'id' : 'aw7e9aa474',
               'label' : MessageService.createStaticMessage('Retry'),
            });
            var eventHandlers001 = [
               {
                     'method' : 'performSSOLogin',
                     'artifactId' : 'Platform.SSOError_Retry_button_eventHandlers_click_performSSOLogin',
                     'id' : 'aw18912c1f',
                     'event' : 'click',
                     'class' : 'platform.handlers.SSOHandler',
               }
            ];
            button001.eventHandlers = eventHandlers001;
            container002.addChild( button001 );


            var dialog002 = new Dialog({
               'id' : 'Platform.SSOUserNameError',
               'label' : MessageService.createStaticMessage('SSO User Name Error'),
            });
            ui001.addChild( dialog002 );


            var container003 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'resource' : 'SSODialogResource',
               'artifactId' : 'Platform.SSOUserNameError_SSODialogResource_container_0',
               'id' : 'awe49a2936',
            });
            dialog002.addChild( container003 );


            var text003 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.SSOUserNameError_SSODialogResource_container_0_Errorretrievingthe',
               'id' : 'aw1211d176',
               'value' : MessageService.createStaticMessage('Error retrieving the user name from the device'),
            });
            container003.addChild( text003 );


            var text004 = new Text({
               'resourceAttribute' : 'errorMsg',
               'editable' : false,
               'artifactId' : 'Platform.SSOUserNameError_SSODialogResource_container_0_errorMsg',
               'id' : 'awe659a10b',
            });
            container003.addChild( text004 );


            var container004 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.SSOUserNameError_container_0',
               'id' : 'awd7539907',
            });
            dialog002.addChild( container004 );


            var button002 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'Platform.SSOUserNameError_Retry_button',
               'id' : 'aw979175e5',
               'label' : MessageService.createStaticMessage('Retry'),
            });
            var eventHandlers002 = [
               {
                     'method' : 'performSSOLogin',
                     'artifactId' : 'Platform.SSOUserNameError_Retry_button_eventHandlers_click_performSSOLogin',
                     'id' : 'aw74e4917c',
                     'event' : 'click',
                     'class' : 'platform.handlers.SSOHandler',
               }
            ];
            button002.eventHandlers = eventHandlers002;
            container004.addChild( button002 );


            var dialog003 = new Dialog({
               'id' : 'Platform.DownloadError',
               'label' : MessageService.createStaticMessage('System Data Download Error'),
            });
            ui001.addChild( dialog003 );


            var container005 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.DownloadError.container',
               'id' : 'awb89e88b',
            });
            dialog003.addChild( container005 );


            var text005 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.DownloadError.text',
               'id' : 'aw63a3744e',
               'value' : MessageService.createStaticMessage('Error downloading System Data'),
            });
            container005.addChild( text005 );


            var container006 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.DownloadError.container2',
               'id' : 'aw60b46d4d',
            });
            dialog003.addChild( container006 );


            var button003 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'Platform.DownloadError.button',
               'id' : 'awcf9d5479',
               'label' : MessageService.createStaticMessage('Retry'),
            });
            var eventHandlers003 = [
               {
                     'method' : 'retrySystemDownload',
                     'artifactId' : 'Platform.DownloadError.eventHandler',
                     'id' : 'awa24338f8',
                     'event' : 'click',
                     'class' : 'platform.handlers.LoginHandler',
               }
            ];
            button003.eventHandlers = eventHandlers003;
            container006.addChild( button003 );


            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'platform.LoginView', false);
               trackTimer.startTracking();
            }

            var view001 = new View({
               'cssClass' : 'mainLogin',
               'resource' : 'PlatformLoginResource',
               'showHeader' : false,
               'id' : 'platform.LoginView',
            });
            ui001.addChild( view001 );

            var requiredResources001 = {
               'PlatformLongPressResource' : {
                  'artifactId' : 'platform.LoginView_PlatformLongPressResource',
                  'id' : 'aw9dc81534',
               },
               'PlatformProgressResource' : {
                  'artifactId' : 'platform.LoginView_PlatformProgressResource',
                  'id' : 'aw80cf2a6f',
               },
               'PlatformChangePasswordForm' : {
                  'artifactId' : 'platform.LoginView_PlatformChangePasswordForm',
                  'id' : 'aw950ff29',
               },
            };
            view001.addRequiredResources( requiredResources001 );

            var container007 = new Container({
               'cssClass' : 'loginForm',
               'artifactId' : 'platform.LoginView_container_0',
               'id' : 'aw1429aadd',
            });
            view001.addChild( container007 );


            var image001 = new Image({
               'image' : '..\/..\/..\/..\/..\/..\/images\/mdpi\/app_icon_main.svg',
               'cssClass' : 'productLogo',
               'artifactId' : 'platform.LoginView_image_0',
               'id' : 'aw9576ccdf',
            });
            container007.addChild( image001 );


            var text006 = new Text({
               'resourceAttribute' : 'appName',
               'cssClass' : 'productName',
               'editable' : false,
               'artifactId' : 'platform.LoginView_container_0_appName',
               'id' : 'aw22401029',
            });
            container007.addChild( text006 );


            var text007 = new Text({
               'resourceAttribute' : 'errorMsg',
               'cssClass' : 'errorMsg',
               'editable' : false,
               'artifactId' : 'platform.LoginView_container_0_errorMsg',
               'id' : 'aw87817020',
            });
            container007.addChild( text007 );


            var text008 = new Text({
               'border' : 'true',
               'resourceAttribute' : 'username',
               'cssClass' : 'loginUsername',
               'editable' : true,
               'artifactId' : 'platform.LoginView_container_0_username',
               'id' : 'awca3922ff',
               'placeHolder' : MessageService.createStaticMessage('Username'),
            });
            container007.addChild( text008 );


            var text009 = new Text({
               'border' : 'true',
               'resourceAttribute' : 'password',
               'cssClass' : 'loginPassword',
               'editable' : true,
               'artifactId' : 'platform.LoginView_container_0_password',
               'id' : 'aw7a5625d',
               'type' : 'password',
               'placeHolder' : MessageService.createStaticMessage('Password'),
            });
            container007.addChild( text009 );


            var button004 = new Button({
               'cssClass' : 'loginBtn',
               'artifactId' : 'platform.LoginView_LogIn_button',
               'id' : 'awe0510eac',
               'label' : MessageService.createStaticMessage('Sign In'),
               'primary' : 'true',
            });
            var eventHandlers004 = [
               {
                     'method' : 'loginClickHandler',
                     'artifactId' : 'platform.LoginView_LogIn_button_eventHandlers_click_loginClickHandler',
                     'id' : 'awa8e7b081',
                     'event' : 'click',
                     'class' : 'platform.handlers.LoginHandler',
               }
            ];
            button004.eventHandlers = eventHandlers004;
            container007.addChild( button004 );


            var text010 = new Text({
               'labelCss' : 'loginLink',
               'artifactId' : 'PrivacyPolicy_link',
               'id' : 'aw8e500c53',
               'label' : MessageService.createStaticMessage('Privacy Policy'),
            });
            container007.addChild( text010 );

            var eventHandlers005 = [
               {
                     'method' : 'privacyPolicyLinkClicked',
                     'artifactId' : 'PrivacyPolicy_link_eventHandlers_click',
                     'id' : 'aw3c2baacc',
                     'event' : 'click',
                     'class' : 'platform.handlers.LoginHandler',
               }
            ];
            text010.eventHandlers = eventHandlers005;

            var image002 = new Image({
               'image' : 'IBMLogo.svg',
               'cssClass' : 'IBMLogo',
               'artifactId' : 'platform.LoginView_image_1',
               'id' : 'awe271fc49',
            });
            container007.addChild( image002 );

            var eventHandlers006 = [
               {
                     'method' : 'initializeLogin',
                     'artifactId' : 'platform.LoginView_eventHandlers_show_initializeLogin',
                     'id' : 'aw9137190b',
                     'event' : 'show',
                     'class' : 'platform.handlers.LoginHandler',
               },
               {
                     'method' : 'changeQueryBase',
                     'artifactId' : 'platform.LoginView_eventHandlers_initialize_changeQueryBase',
                     'id' : 'aw5f76d673',
                     'event' : 'initialize',
                     'class' : 'platform.handlers._ApplicationHandlerBase',
               }
            ];
            view001.eventHandlers = eventHandlers006;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'WorkApproval.WorkListView', false);
               trackTimer.startTracking();
            }

            var view002 = new View({
               'saveonshow' : true,
               'showBackButton' : 'false',
               'resource' : 'workOrder',
               'id' : 'WorkApproval.WorkListView',
               'label' : MessageService.createStaticMessage('Approval Work List'),
            });
            ui001.addChild( view002 );


            var queries001 = new Queries({
               'resource' : 'workOrder',
               'artifactId' : 'WorkApproval.WorkListView_queries',
               'id' : 'aw7fdde3da',
            });
            view002.addChild( queries001 );


            var query001 = new Query({
               'cssClass' : 'finalQueryBaseMenuItem',
               'artifactId' : 'WorkApproval.WorkListView_myapprovals',
               'id' : 'awd8bc14d3',
               'label' : MessageService.createStaticMessage('Approval Work List'),
               'queryBase' : 'myapprovals',
            });
            queries001.addChild( query001 );


            var query002 = new Query({
               'system' : 'true',
               'artifactId' : 'WorkApproval.WorkListView___search_result__',
               'id' : 'aw4af866bb',
               'label' : MessageService.createStaticMessage('Search Results'),
               'queryBase' : '__search_result__',
            });
            queries001.addChild( query002 );

            var eventHandlers007 = [
               {
                     'method' : 'hideShowSearchedMenu',
                     'artifactId' : 'WorkApproval.WorkListView___search_result___eventHandlers_render_hideShowSearchedMenu',
                     'id' : 'aw7ca18d60',
                     'event' : 'render',
                     'class' : 'application.handlers.WOListHandler',
               }
            ];
            query002.eventHandlers = eventHandlers007;
            var requiredResources002 = {
               'workOrder' : {
                  'reload' : true,
                  'artifactId' : 'WorkApproval.WorkListView_workOrder',
                  'id' : 'aw276bd98a',
               },
               'PlatformProgressResource' : {
                  'artifactId' : 'WorkApproval.WorkListView_PlatformProgressResource',
                  'id' : 'awd5be4e8c',
               },
               'domainwostatus' : {
                  'artifactId' : 'WorkApproval.WorkListView_domainwostatus',
                  'id' : 'awac44cf26',
               },
            };
            view002.addRequiredResources( requiredResources002 );

            var actions001 = new Actions({
               'artifactId' : 'WorkApproval.WorkListView_actions',
               'id' : 'awf06d5547',
            });
            view002.addChild( actions001 );


            var action001 = new Action({
               'overflow' : true,
               'artifactId' : 'WorkApproval.WorkListView_DownloadWorkList_action',
               'id' : 'aw584e3666',
               'label' : MessageService.createStaticMessage('Download Work List'),
            });
            actions001.addChild( action001 );

            var eventHandlers008 = [
               {
                     'method' : 'workoffline',
                     'artifactId' : 'WorkApproval.WorkListView_DownloadWorkList_action_eventHandlers_click_workoffline',
                     'id' : 'aw84b515e7',
                     'event' : 'click',
                     'class' : 'platform.handlers.WorkOfflineHandler',
               },
               {
                     'method' : 'enableDisableMenu',
                     'artifactId' : 'WorkApproval.WorkListView_DownloadWorkList_action_eventHandlers_render_enableDisableMenu',
                     'id' : 'aw5cafacfc',
                     'event' : 'render',
                     'class' : 'platform.handlers.WorkOfflineHandler',
               }
            ];
            action001.eventHandlers = eventHandlers008;

            var action002 = new Action({
               'overflow' : true,
               'artifactId' : 'WorkApproval.WorkListView_SynchronizeData_action',
               'id' : 'aw32282425',
               'label' : MessageService.createStaticMessage('Synchronize Data'),
            });
            actions001.addChild( action002 );

            var eventHandlers009 = [
               {
                     'method' : 'sync',
                     'artifactId' : 'WorkApproval.WorkListView_SynchronizeData_action_eventHandlers_click_sync',
                     'id' : 'awa1410982',
                     'event' : 'click',
                     'class' : 'platform.handlers.WorkOfflineHandler',
               },
               {
                     'method' : 'enableDisableSyncMenu',
                     'artifactId' : 'WorkApproval.WorkListView_SynchronizeData_action_eventHandlers_render_enableDisableMenu',
                     'id' : 'awbc22e8f6',
                     'event' : 'render',
                     'class' : 'platform.handlers.WorkOfflineHandler',
               }
            ];
            action002.eventHandlers = eventHandlers009;

            var action003 = new Action({
               'overflow' : true,
               'transitionTo' : 'WorkApproval.SearchWorkOrderView',
               'artifactId' : 'WorkApproval.WorkListView_Search_action',
               'id' : 'aw795bec9a',
               'label' : MessageService.createStaticMessage('Search'),
            });
            actions001.addChild( action003 );

            var eventHandlers010 = [
               {
                     'method' : 'enableDisableBasedOnConnection',
                     'artifactId' : 'WorkApproval.WorkListView_Search_action_eventHandlers_render_enableDisableBasedOnConnection',
                     'id' : 'awd881261a',
                     'event' : 'render',
                     'class' : 'platform.handlers.WorkOfflineHandler',
               }
            ];
            action003.eventHandlers = eventHandlers010;

            var progressIndicator001 = new ProgressIndicator({
               'artifactId' : 'WorkApproval.WorkListView_0',
               'id' : 'aw4d0f6b8a',
            });
            view002.addChild( progressIndicator001 );


            var eventHandlers011 = [
               {
                     'method' : 'keepWorkListResource',
                     'artifactId' : 'WorkApproval.WorkListView_workOrder_list_eventHandlers_render_keepWorkListResource',
                     'id' : 'aw2c90bae6',
                     'event' : 'render',
                     'class' : 'platform.handlers.WorkOfflineHandler',
               }
            ];

            var sortOptions001 = new SortOptions({
               'artifactId' : 'WorkApproval.WorkListView_workOrder_list_sortOptions',
               'id' : 'aw8b627a7a',
            });

            var sortOption001 = new SortOption({
               'artifactId' : 'WorkApproval.WorkListView_sortOption_ScheduledStart',
               'id' : 'awa26ae03e',
               'label' : MessageService.createStaticMessage('Scheduled Start'),
            });
            sortOptions001.addChild( sortOption001 );


            var sortAttribute001 = new SortAttribute({
               'name' : 'starttimeISO',
               'artifactId' : 'WorkApproval.WorkListView_ScheduledStart_sortAttribute_starttime',
               'id' : 'aw2338261a',
               'direction' : 'asc',
            });
            sortOption001.addChild( sortAttribute001 );


            var sortOption002 = new SortOption({
               'artifactId' : 'WorkApproval.WorkListView_sortOption_Status',
               'id' : 'aw13925697',
               'label' : MessageService.createStaticMessage('Status'),
            });
            sortOptions001.addChild( sortOption002 );


            var sortAttribute002 = new SortAttribute({
               'name' : 'status',
               'artifactId' : 'WorkApproval.WorkListView_Status_sortAttribute_status',
               'id' : 'aw593fb9fd',
               'direction' : 'asc',
            });
            sortOption002.addChild( sortAttribute002 );


            var sortOption003 = new SortOption({
               'artifactId' : 'WorkApproval.WorkListView_sortOption_WorkOrder',
               'id' : 'aw97041eee',
               'label' : MessageService.createStaticMessage('Work Order'),
            });
            sortOptions001.addChild( sortOption003 );


            var sortAttribute003 = new SortAttribute({
               'name' : 'wonum',
               'artifactId' : 'WorkApproval.WorkListView_WorkOrder_sortAttribute_wonum',
               'id' : 'aw420f154f',
               'direction' : 'asc',
            });
            sortOption003.addChild( sortAttribute003 );



            var listItemTemplate001 = new ListItemTemplate({
               'layout' : 'ApprovalListItem',
               'artifactId' : 'WorkApproval.WorkListView_workOrder_listItemTemplate_ApprovalListItem',
               'id' : 'aw6da5178f',
            });

            var listtext001 = new ListText({
               'resourceAttribute' : 'wonum',
               'layoutInsertAt' : 'item1',
               'artifactId' : 'WorkApproval.WorkListView_workOrder_ApprovalListItem_wonum',
               'id' : 'aw62c6775f',
            });
            listItemTemplate001.addChild( listtext001 );


            var listtext002 = new ListText({
               'resourceAttribute' : 'starttime',
               'layoutInsertAt' : 'item2',
               'artifactId' : 'WorkApproval.WorkListView_workOrder_ApprovalListItem_starttime',
               'id' : 'aw69d8400b',
            });
            listItemTemplate001.addChild( listtext002 );


            var listtext003 = new ListText({
               'resourceAttribute' : 'statusdesc',
               'layoutInsertAt' : 'item4',
               'artifactId' : 'WorkApproval.WorkListView_workOrder_ApprovalListItem_statusdesc',
               'id' : 'aw6b4fd89a',
            });
            listItemTemplate001.addChild( listtext003 );


            var listtext004 = new ListText({
               'resourceAttribute' : 'description',
               'cssClass' : 'bold textappearance-medium',
               'layoutInsertAt' : 'item3',
               'artifactId' : 'WorkApproval.WorkListView_workOrder_ApprovalListItem_description',
               'id' : 'aw747b886a',
            });
            listItemTemplate001.addChild( listtext004 );


            var listtext005 = new ListText({
               'resourceAttribute' : 'assetnumanddescription',
               'layoutInsertAt' : 'item5',
               'artifactId' : 'WorkApproval.WorkListView_workOrder_ApprovalListItem_assetnumanddescription',
               'id' : 'aw797254de',
            });
            listItemTemplate001.addChild( listtext005 );


            var button005 = new Button({
               'resourceAttribute' : 'status',
               'layoutInsertAt' : 'button1',
               'artifactId' : 'WorkApproval.WorkListView_workOrder_status_Approve_button',
               'id' : 'aw18107cab',
               'label' : MessageService.createStaticMessage('Approve'),
            });
            var eventHandlers012 = [
               {
                     'method' : 'handleApproveWorkClick',
                     'artifactId' : 'WorkApproval.WorkListView_workOrder_status_Approve_button_eventHandlers_click_handleApproveWorkClick',
                     'id' : 'aw40b9f779',
                     'event' : 'click',
                     'class' : 'application.handlers.StatusChangeHandler',
               },
               {
                     'method' : 'enableApproveButton',
                     'artifactId' : 'WorkApproval.WorkListView_workOrder_status_Approve_button_eventHandlers_datachange_enableApproveButton',
                     'id' : 'awe3b2a1b9',
                     'event' : 'datachange',
                     'class' : 'application.handlers.StatusChangeHandler',
               }
            ];
            button005.eventHandlers = eventHandlers012;
            listItemTemplate001.addChild( button005 );


            var button006 = new Button({
               'resourceAttribute' : 'status',
               'layoutInsertAt' : 'button2',
               'artifactId' : 'WorkApproval.WorkListView_workOrder_status_Cancel_button',
               'id' : 'aw13b323b5',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers013 = [
               {
                     'method' : 'handleCancelWorkClick',
                     'artifactId' : 'WorkApproval.WorkListView_workOrder_status_Cancel_button_eventHandlers_click_handleCancelWorkClick',
                     'id' : 'awfe5e3a50',
                     'event' : 'click',
                     'class' : 'application.handlers.StatusChangeHandler',
               },
               {
                     'method' : 'enableCancelButton',
                     'artifactId' : 'WorkApproval.WorkListView_workOrder_status_Cancel_button_eventHandlers_datachange_enableCancelButton',
                     'id' : 'aw26f8a91d',
                     'event' : 'datachange',
                     'class' : 'application.handlers.StatusChangeHandler',
               }
            ];
            button006.eventHandlers = eventHandlers013;
            listItemTemplate001.addChild( button006 );


            var actions002 = new Actions({
               'artifactId' : 'WorkApproval.WorkListView_workOrder_listItemTemplate_ApprovalListItem_workOrder_actions',
               'id' : 'aw34bc4e5d',
            });
            listItemTemplate001.addChild( actions002 );


            var action004 = new Action({
               'transitionTo' : 'WorkApproval.EditStatusView',
               'artifactId' : 'WorkApproval.WorkListView_ChangeStatus_action',
               'id' : 'awf4cae5ab',
               'label' : MessageService.createStaticMessage('Change Status'),
            });
            actions002.addChild( action004 );

            var eventHandlers014 = [
               {
                     'method' : 'renderWorkOrderActionIfNotLocked',
                     'artifactId' : 'WorkApproval.WorkListView_ChangeStatus_action_eventHandlers_render_renderWorkOrderActionIfNotLocked',
                     'id' : 'awe99bb192',
                     'event' : 'render',
                     'class' : 'application.handlers.WOListHandler',
               }
            ];
            action004.eventHandlers = eventHandlers014;

            var action005 = new Action({
               'transitionTo' : 'WorkApproval.CostsView',
               'artifactId' : 'WorkApproval.WorkListView_ViewCost_action',
               'id' : 'awaa2df692',
               'label' : MessageService.createStaticMessage('View Cost'),
            });
            actions002.addChild( action005 );


            var action006 = new Action({
               'transitionTo' : 'WorkApproval.NewWorkLogView',
               'artifactId' : 'WorkApproval.WorkListView_CreateWorkLogEntry_action',
               'id' : 'aw107b2d3c',
               'label' : MessageService.createStaticMessage('Create Work Log Entry'),
            });
            actions002.addChild( action006 );

            var eventHandlers015 = [
               {
                     'method' : 'renderWorkOrderActionIfNotLocked',
                     'artifactId' : 'WorkApproval.WorkListView_CreateWorkLogEntry_action_eventHandlers_render_renderWorkOrderActionIfNotLocked',
                     'id' : 'aw2de0f98',
                     'event' : 'render',
                     'class' : 'application.handlers.WOListHandler',
               }
            ];
            action006.eventHandlers = eventHandlers015;


            var list001 = new List({
               'recordLabel' : MessageService.createDynamicMessage('Work Order {0}', 'application.handlers.WODetailsHandler', 'resolveWonumLabel'),
               'resource' : 'workOrder',
               'transitionTo' : 'WorkApproval.WorkListDetailsView',
               'sortOptions' : sortOptions001,
               'listItemTemplate' : listItemTemplate001,
               'artifactId' : 'WorkApproval.WorkListView_workOrder_list',
               'eventHandlers' : eventHandlers011,
               'id' : 'aw27a04087',
               'resolverFunction' : 'resolveWonumLabel',
               'resolverClass' : 'application.handlers.WODetailsHandler',
            });
            view002.addChild( list001 );

            var eventHandlers016 = [
               {
                     'method' : 'showBusyList',
                     'artifactId' : 'WorkApproval.WorkListView_eventHandlers_render_showBusyList',
                     'id' : 'aw3e2b2e44',
                     'event' : 'render',
                     'class' : 'application.handlers.WODetailsHandler',
               }
            ];
            view002.eventHandlers = eventHandlers016;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'WorkApproval.WorkListDetailsView', false);
               trackTimer.startTracking();
            }

            var view003 = new View({
               'resource' : 'workOrder',
               'id' : 'WorkApproval.WorkListDetailsView',
               'label' : MessageService.createStaticMessage('Work Order Details'),
            });
            ui001.addChild( view003 );

            var requiredResources003 = {
               'workOrder' : {
                  'artifactId' : 'WorkApproval.WorkListDetailsView_workOrder',
                  'id' : 'awc5a823c7',
                  'related' : {
                     'tasklist' : {
                        'artifactId' : 'WorkApproval.WorkListDetailsView_workOrder_tasklist',
                        'id' : 'awd6df453f',
                     },
                  },
               },
               'domainwostatus' : {
                  'artifactId' : 'WorkApproval.WorkListDetailsView_domainwostatus',
                  'id' : 'aw1a5d1c6a',
               },
               'workCosts' : {
                  'artifactId' : 'WorkApproval.WorkListDetailsView_workCosts',
                  'id' : 'aw9f9ce7f7',
               },
            };
            view003.addRequiredResources( requiredResources003 );
            var eventHandlers017 = [
               {
                     'method' : 'InitializeAllListSizes',
                     'artifactId' : 'WorkApproval.WorkListDetailsView_eventHandlers_initialize_InitializeAllListSizes',
                     'id' : 'awc677582f',
                     'event' : 'initialize',
                     'class' : 'application.handlers.WOListHandler',
               }
            ];
            view003.eventHandlers = eventHandlers017;

            var container008 = new Container({
               'artifactId' : 'WorkApproval.WorkListDetailsView_container_0',
               'id' : 'aw319c1b08',
            });
            view003.addChild( container008 );


            var errorIndicator001 = new ErrorIndicator({
               'artifactId' : 'WorkApproval.WorkListDetailsView_errorIndicator',
               'id' : 'awb709299e',
            });
            container008.addChild( errorIndicator001 );


            var group001 = new Group({
               'artifactId' : 'WorkApproval.WorkListDetailsView_group_0',
               'id' : 'aw59486be8',
            });
            container008.addChild( group001 );


            var groupitem001 = new GroupItem({
               'transitionTo' : 'WorkApproval.EditStatusView',
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.EditStatusView_0',
               'id' : 'aw8500f532',
            });
            group001.addChild( groupitem001 );


            var text011 = new Text({
               'resourceAttribute' : 'statusdesc',
               'editable' : false,
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.EditStatusView_0_statusdesc_Status',
               'id' : 'awbce7116f',
               'label' : MessageService.createStaticMessage('Status'),
            });
            groupitem001.addChild( text011 );


            var button007 = new Button({
               'resourceAttribute' : 'status',
               'artifactId' : 'WorkApproval.WorkListDetailsView_status_Approve_button',
               'id' : 'aw44bf76a2',
               'label' : MessageService.createStaticMessage('Approve'),
            });
            var eventHandlers018 = [
               {
                     'method' : 'handleApproveWorkClick',
                     'artifactId' : 'WorkApproval.WorkListDetailsView_status_Approve_button_eventHandlers_click_handleApproveWorkClick',
                     'id' : 'aw2e219a8c',
                     'event' : 'click',
                     'class' : 'application.handlers.StatusChangeHandler',
               },
               {
                     'method' : 'enableApproveButton',
                     'artifactId' : 'WorkApproval.WorkListDetailsView_status_Approve_button_eventHandlers_datachange_enableApproveButton',
                     'id' : 'awb97ac73c',
                     'event' : 'datachange',
                     'class' : 'application.handlers.StatusChangeHandler',
               }
            ];
            button007.eventHandlers = eventHandlers018;
            groupitem001.addChild( button007 );


            var button008 = new Button({
               'resourceAttribute' : 'status',
               'artifactId' : 'WorkApproval.WorkListDetailsView_status_Cancel_button',
               'id' : 'awfd32e0e',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers019 = [
               {
                     'method' : 'handleCancelWorkClick',
                     'artifactId' : 'WorkApproval.WorkListDetailsView_status_Cancel_button_eventHandlers_click_handleCancelWorkClick',
                     'id' : 'aw2c3de542',
                     'event' : 'click',
                     'class' : 'application.handlers.StatusChangeHandler',
               },
               {
                     'method' : 'enableCancelButton',
                     'artifactId' : 'WorkApproval.WorkListDetailsView_status_Cancel_button_eventHandlers_datachange_enableCancelButton',
                     'id' : 'aw4860c4e8',
                     'event' : 'datachange',
                     'class' : 'application.handlers.StatusChangeHandler',
               }
            ];
            button008.eventHandlers = eventHandlers019;
            groupitem001.addChild( button008 );


            var groupitem002 = new GroupItem({
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_0',
               'id' : 'aw74478a1b',
            });
            group001.addChild( groupitem002 );


            var text012 = new Text({
               'resourceAttribute' : 'wonum',
               'editable' : false,
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_0_wonum_WorkOrder',
               'id' : 'aw4904148d',
               'label' : MessageService.createStaticMessage('Work Order'),
            });
            groupitem002.addChild( text012 );


            var groupitem003 = new GroupItem({
               'transitionTo' : 'WorkApproval.DescriptionView',
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.DescriptionView_0',
               'id' : 'aw42e91c73',
            });
            group001.addChild( groupitem003 );


            var text013 = new Text({
               'resourceAttribute' : 'description',
               'editable' : false,
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.DescriptionView_0_description_Description',
               'id' : 'aw21fdf981',
               'label' : MessageService.createStaticMessage('Description'),
            });
            groupitem003.addChild( text013 );


            var groupitem004 = new GroupItem({
               'transitionTo' : 'WorkApproval.AssetView',
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.AssetView_0',
               'id' : 'aw5c039b56',
            });
            group001.addChild( groupitem004 );


            var text014 = new Text({
               'resourceAttribute' : 'assetnumanddescription',
               'editable' : false,
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.AssetView_0_assetnumanddescription_Asset',
               'id' : 'aw432ee4d5',
               'label' : MessageService.createStaticMessage('Asset'),
            });
            groupitem004.addChild( text014 );


            var groupitem005 = new GroupItem({
               'transitionTo' : 'WorkApproval.LocationView',
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.LocationView_0',
               'id' : 'awd8ac419a',
            });
            group001.addChild( groupitem005 );


            var text015 = new Text({
               'resourceAttribute' : 'locationanddescription',
               'editable' : false,
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.LocationView_0_locationanddescription_Location',
               'id' : 'aw30f08efe',
               'label' : MessageService.createStaticMessage('Location'),
            });
            groupitem005.addChild( text015 );


            var groupitem006 = new GroupItem({
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_1',
               'id' : 'aw340ba8d',
            });
            group001.addChild( groupitem006 );


            var text016 = new Text({
               'resourceAttribute' : 'woserviceaddress',
               'editable' : false,
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_1_woserviceaddress_ServiceAddress',
               'id' : 'aw73108b0a',
               'label' : MessageService.createStaticMessage('Service Address'),
            });
            groupitem006.addChild( text016 );


            var groupitem007 = new GroupItem({
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_2',
               'id' : 'aw9a49eb37',
            });
            group001.addChild( groupitem007 );


            var text017 = new Text({
               'resourceAttribute' : 'targetstart',
               'editable' : false,
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_2_targetstart_TargetStart',
               'id' : 'aw1293a573',
               'label' : MessageService.createStaticMessage('Target Start'),
            });
            groupitem007.addChild( text017 );


            var groupitem008 = new GroupItem({
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_3',
               'id' : 'awed4edba1',
            });
            group001.addChild( groupitem008 );


            var text018 = new Text({
               'resourceAttribute' : 'targetfinish',
               'editable' : false,
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_3_targetfinish_TargetFinish',
               'id' : 'aw6bfa7a68',
               'label' : MessageService.createStaticMessage('Target Finish'),
            });
            groupitem008.addChild( text018 );


            var groupitem009 = new GroupItem({
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_4',
               'id' : 'aw732a4e02',
            });
            group001.addChild( groupitem009 );


            var text019 = new Text({
               'resourceAttribute' : 'starttime',
               'editable' : false,
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_4_starttime_ScheduledStart',
               'id' : 'aw46aee80e',
               'label' : MessageService.createStaticMessage('Scheduled Start'),
            });
            groupitem009.addChild( text019 );


            var groupitem010 = new GroupItem({
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_5',
               'id' : 'aw42d7e94',
            });
            group001.addChild( groupitem010 );


            var text020 = new Text({
               'resourceAttribute' : 'finishtime',
               'editable' : false,
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_5_finishtime_ScheduledFinish',
               'id' : 'aw6200483b',
               'label' : MessageService.createStaticMessage('Scheduled Finish'),
            });
            groupitem010.addChild( text020 );


            var groupitem011 = new GroupItem({
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_6',
               'id' : 'aw9d242f2e',
            });
            group001.addChild( groupitem011 );


            var text021 = new Text({
               'resourceAttribute' : 'worktype',
               'editable' : false,
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_6_worktype_WorkType',
               'id' : 'aw2243f4ec',
               'label' : MessageService.createStaticMessage('Work Type'),
            });
            groupitem011.addChild( text021 );


            var groupitem012 = new GroupItem({
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_7',
               'id' : 'awea231fb8',
            });
            group001.addChild( groupitem012 );


            var text022 = new Text({
               'resourceAttribute' : 'priority',
               'editable' : false,
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_7_priority_Priority',
               'id' : 'awe19d8801',
               'label' : MessageService.createStaticMessage('Priority'),
            });
            groupitem012.addChild( text022 );


            var groupitem013 = new GroupItem({
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_8',
               'id' : 'aw7a9c0229',
            });
            group001.addChild( groupitem013 );


            var text023 = new Text({
               'resourceAttribute' : 'reportedby',
               'editable' : false,
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_8_reportedby_ReportedBy',
               'id' : 'awd2b319bb',
               'label' : MessageService.createStaticMessage('Reported By'),
            });
            groupitem013.addChild( text023 );


            var groupitem014 = new GroupItem({
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_9',
               'id' : 'awd9b32bf',
            });
            group001.addChild( groupitem014 );


            var text024 = new Text({
               'resourceAttribute' : 'reporteddate',
               'editable' : false,
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_9_reporteddate_ReportedDate',
               'id' : 'aw2221a415',
               'label' : MessageService.createStaticMessage('Reported Date'),
            });
            groupitem014.addChild( text024 );


            var groupitem015 = new GroupItem({
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_10',
               'id' : 'aw67d16006',
            });
            group001.addChild( groupitem015 );


            var text025 = new Text({
               'resourceAttribute' : 'glaccount',
               'editable' : false,
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_10_glaccount_GLAccount',
               'id' : 'awf3812464',
               'label' : MessageService.createStaticMessage('GL Account'),
            });
            groupitem015.addChild( text025 );


            var group002 = new Group({
               'artifactId' : 'WorkApproval.WorkListDetailsView_group_1',
               'id' : 'aw2e4f5b7e',
            });
            container008.addChild( group002 );


            var groupitem016 = new GroupItem({
               'layout' : 'ViewCostLine',
               'transitionTo' : 'WorkApproval.CostsView',
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.CostsView_0',
               'id' : 'aw4c4b4cca',
            });
            group002.addChild( groupitem016 );


            var text026 = new Text({
               'cssClass' : 'relatedRecords',
               'editable' : false,
               'layoutInsertAt' : 'item1',
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.CostsView_0_Costs',
               'id' : 'awfc01b732',
               'value' : MessageService.createStaticMessage('Costs'),
            });
            groupitem016.addChild( text026 );


            var text027 = new Text({
               'resourceAttribute' : 'localtotalcost',
               'editable' : false,
               'layoutInsertAt' : 'item2',
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.CostsView_0_localtotalcost',
               'id' : 'aw7a9dbb09',
            });
            groupitem016.addChild( text027 );

            var eventHandlers020 = [
               {
                     'method' : 'calculateWOCost',
                     'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.CostsView_0_localtotalcost_eventHandlers_render_calculateWOCost',
                     'id' : 'awa59ffc3f',
                     'event' : 'render',
                     'class' : 'application.handlers.WOListHandler',
               }
            ];
            text027.eventHandlers = eventHandlers020;

            var groupitem017 = new GroupItem({
               'layout' : 'Item1Count1Button1',
               'transitionTo' : 'WorkApproval.MultipleAssetsLocationsView',
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.MultipleAssetsLocationsView_0',
               'id' : 'aw4d62c597',
            });
            group002.addChild( groupitem017 );


            var text028 = new Text({
               'cssClass' : 'relatedRecords',
               'editable' : false,
               'layoutInsertAt' : 'item1',
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.MultipleAssetsLocationsView_0_MultipleAssetsLo',
               'id' : 'aw53904b87',
               'value' : MessageService.createStaticMessage('Multiple Assets & Locations'),
            });
            groupitem017.addChild( text028 );


            var text029 = new Text({
               'resourceAttribute' : 'multiassetloclistsize',
               'editable' : false,
               'layoutInsertAt' : 'count1',
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.MultipleAssetsLocationsView_0_multiassetloclistsize',
               'id' : 'awc7675eae',
            });
            groupitem017.addChild( text029 );

            var eventHandlers021 = [
               {
                     'method' : 'UpdateMultiAssetLocListSize',
                     'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.MultipleAssetsLocationsView_0_multiassetloclistsize_eventHandlers_render_UpdateMultiAssetLocListSize',
                     'id' : 'aw4b6096b7',
                     'event' : 'render',
                     'class' : 'application.handlers.WOListHandler',
               }
            ];
            text029.eventHandlers = eventHandlers021;

            var groupitem018 = new GroupItem({
               'layout' : 'Item1Count1Button1',
               'transitionTo' : 'WorkApproval.TasksView',
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.TasksView_0',
               'id' : 'aw70d48eb6',
            });
            group002.addChild( groupitem018 );


            var text030 = new Text({
               'cssClass' : 'relatedRecords',
               'editable' : false,
               'layoutInsertAt' : 'item1',
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.TasksView_0_Tasks',
               'id' : 'aw24231e0a',
               'value' : MessageService.createStaticMessage('Tasks'),
            });
            groupitem018.addChild( text030 );


            var text031 = new Text({
               'resourceAttribute' : 'tasklistsize',
               'editable' : false,
               'layoutInsertAt' : 'count1',
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.TasksView_0_tasklistsize',
               'id' : 'aw5d15bd39',
            });
            groupitem018.addChild( text031 );

            var eventHandlers022 = [
               {
                     'method' : 'UpdateTaskListSize',
                     'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.TasksView_0_tasklistsize_eventHandlers_render_UpdateTaskListSize',
                     'id' : 'aw7459fc73',
                     'event' : 'render',
                     'class' : 'application.handlers.WOListHandler',
               }
            ];
            text031.eventHandlers = eventHandlers022;

            var group003 = new Group({
               'artifactId' : 'WorkApproval.WorkListDetailsView_group_2',
               'id' : 'awb7460ac4',
            });
            container008.addChild( group003 );


            var groupitem019 = new GroupItem({
               'layout' : 'Item1Count1Button1',
               'transitionTo' : 'WorkApproval.PlannedLaborView',
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.PlannedLaborView_0',
               'id' : 'awa4dc0506',
            });
            group003.addChild( groupitem019 );


            var text032 = new Text({
               'cssClass' : 'relatedRecords',
               'editable' : false,
               'layoutInsertAt' : 'item1',
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.PlannedLaborView_0_PlannedLabor',
               'id' : 'awf62176c8',
               'value' : MessageService.createStaticMessage('Planned Labor'),
            });
            groupitem019.addChild( text032 );


            var text033 = new Text({
               'resourceAttribute' : 'laborlistsize',
               'editable' : false,
               'layoutInsertAt' : 'count1',
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.PlannedLaborView_0_laborlistsize',
               'id' : 'aw426ee9ef',
            });
            groupitem019.addChild( text033 );

            var eventHandlers023 = [
               {
                     'method' : 'UpdateLaborListSize',
                     'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.PlannedLaborView_0_laborlistsize_eventHandlers_render_UpdateLaborListSize',
                     'id' : 'aw50d87d6b',
                     'event' : 'render',
                     'class' : 'application.handlers.WOListHandler',
               }
            ];
            text033.eventHandlers = eventHandlers023;

            var groupitem020 = new GroupItem({
               'layout' : 'Item1Count1Button1',
               'transitionTo' : 'WorkApproval.PlannedMaterialView',
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.PlannedMaterialView_0',
               'id' : 'aw76a804f2',
            });
            group003.addChild( groupitem020 );


            var text034 = new Text({
               'cssClass' : 'relatedRecords',
               'editable' : false,
               'layoutInsertAt' : 'item1',
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.PlannedMaterialView_0_PlannedMaterials',
               'id' : 'aw6d7f2067',
               'value' : MessageService.createStaticMessage('Planned Materials'),
            });
            groupitem020.addChild( text034 );


            var text035 = new Text({
               'resourceAttribute' : 'materiallistsize',
               'editable' : false,
               'layoutInsertAt' : 'count1',
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.PlannedMaterialView_0_materiallistsize',
               'id' : 'aw268cd51',
            });
            groupitem020.addChild( text035 );

            var eventHandlers024 = [
               {
                     'method' : 'UpdateMaterialListSize',
                     'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.PlannedMaterialView_0_materiallistsize_eventHandlers_render_UpdateMaterialListSize',
                     'id' : 'awb37ed020',
                     'event' : 'render',
                     'class' : 'application.handlers.WOListHandler',
               }
            ];
            text035.eventHandlers = eventHandlers024;

            var groupitem021 = new GroupItem({
               'layout' : 'Item1Count1Button1',
               'transitionTo' : 'WorkApproval.PlannedToolsView',
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.PlannedToolsView_0',
               'id' : 'aw7797fb3b',
            });
            group003.addChild( groupitem021 );


            var text036 = new Text({
               'cssClass' : 'relatedRecords',
               'editable' : false,
               'layoutInsertAt' : 'item1',
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.PlannedToolsView_0_PlannedTools',
               'id' : 'awbe3a3704',
               'value' : MessageService.createStaticMessage('Planned Tools'),
            });
            groupitem021.addChild( text036 );


            var text037 = new Text({
               'resourceAttribute' : 'toollistsize',
               'editable' : false,
               'layoutInsertAt' : 'count1',
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.PlannedToolsView_0_toollistsize',
               'id' : 'awa0494d8a',
            });
            groupitem021.addChild( text037 );

            var eventHandlers025 = [
               {
                     'method' : 'UpdateToolListSize',
                     'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.PlannedToolsView_0_toollistsize_eventHandlers_render_UpdateToolListSize',
                     'id' : 'aw7fbfb77',
                     'event' : 'render',
                     'class' : 'application.handlers.WOListHandler',
               }
            ];
            text037.eventHandlers = eventHandlers025;

            var groupitem022 = new GroupItem({
               'layout' : 'Item1Count1Button1',
               'transitionTo' : 'WorkApproval.PlannedServicesView',
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.PlannedServicesView_0',
               'id' : 'aw9cad12fe',
            });
            group003.addChild( groupitem022 );


            var text038 = new Text({
               'cssClass' : 'relatedRecords',
               'editable' : false,
               'layoutInsertAt' : 'item1',
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.PlannedServicesView_0_PlannedServices',
               'id' : 'aw73fd07cb',
               'value' : MessageService.createStaticMessage('Planned Services'),
            });
            groupitem022.addChild( text038 );


            var text039 = new Text({
               'resourceAttribute' : 'servicelistsize',
               'editable' : false,
               'layoutInsertAt' : 'count1',
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.PlannedServicesView_0_servicelistsize',
               'id' : 'aw55f8ae7f',
            });
            groupitem022.addChild( text039 );

            var eventHandlers026 = [
               {
                     'method' : 'UpdateServiceListSize',
                     'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.PlannedServicesView_0_servicelistsize_eventHandlers_render_UpdateServiceListSize',
                     'id' : 'aw7df0a495',
                     'event' : 'render',
                     'class' : 'application.handlers.WOListHandler',
               }
            ];
            text039.eventHandlers = eventHandlers026;

            var group004 = new Group({
               'artifactId' : 'WorkApproval.WorkListDetailsView_group_3',
               'id' : 'awc0413a52',
            });
            container008.addChild( group004 );


            var groupitem023 = new GroupItem({
               'layout' : 'Item1Count1Button1',
               'transitionTo' : 'WorkApproval.WorkLogView',
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.WorkLogView_0',
               'id' : 'awfb81377d',
            });
            group004.addChild( groupitem023 );


            var text040 = new Text({
               'cssClass' : 'relatedRecords',
               'editable' : false,
               'layoutInsertAt' : 'item1',
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.WorkLogView_0_WorkLog',
               'id' : 'aw616bd983',
               'value' : MessageService.createStaticMessage('Work Log'),
            });
            groupitem023.addChild( text040 );


            var text041 = new Text({
               'resourceAttribute' : 'workloglistsize',
               'editable' : false,
               'layoutInsertAt' : 'count1',
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.WorkLogView_0_workloglistsize',
               'id' : 'aw80ff753f',
            });
            groupitem023.addChild( text041 );

            var eventHandlers027 = [
               {
                     'method' : 'UpdateWorkLogListSize',
                     'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_WorkApproval.WorkLogView_0_workloglistsize_eventHandlers_render_UpdateWorkLogListSize',
                     'id' : 'aw9752e8d7',
                     'event' : 'render',
                     'class' : 'application.handlers.WOListHandler',
               }
            ];
            text041.eventHandlers = eventHandlers027;

            var button009 = new Button({
               'image' : 'action_addNew_OFF.svg',
               'transitionTo' : 'WorkApproval.NewWorkLogView',
               'layoutInsertAt' : 'button1',
               'artifactId' : 'WorkApproval.WorkListDetailsView_CreateWorkLogEntry_action_addNew_OFF.svg_button',
               'id' : 'aw49eb86fe',
               'label' : MessageService.createStaticMessage('Create Work Log Entry'),
            });
            var eventHandlers028 = [
               {
                     'method' : 'enableAddWorkLogButton',
                     'artifactId' : 'WorkApproval.WorkListDetailsView_CreateWorkLogEntry_action_addNew_OFF.svg_button_eventHandlers_datachange_enableAddWorkLogButton',
                     'id' : 'awcd6229e3',
                     'event' : 'datachange',
                     'class' : 'application.handlers.WorkLogHandler',
               }
            ];
            button009.eventHandlers = eventHandlers028;
            groupitem023.addChild( button009 );


            var group005 = new Group({
               'artifactId' : 'WorkApproval.WorkListDetailsView_group_4',
               'id' : 'aw5e25aff1',
            });
            container008.addChild( group005 );


            var groupitem024 = new GroupItem({
               'artifactId' : 'WorkApproval.WorkListDetailsView_groupitem_11',
               'id' : 'aw10d65090',
            });
            group005.addChild( groupitem024 );


            var lastupdatetext001 = new LastUpdateText({
               'artifactId' : 'WorkApproval.WorkListDetailsView_lastupdatetext',
               'id' : 'aw39de619',
            });
            groupitem024.addChild( lastupdatetext001 );

            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'WorkApproval.DescriptionView', false);
               trackTimer.startTracking();
            }

            var view004 = new View({
               'resource' : 'workOrder',
               'id' : 'WorkApproval.DescriptionView',
               'label' : MessageService.createStaticMessage('Description'),
            });
            ui001.addChild( view004 );

            var requiredResources004 = {
               'workOrder' : {
                  'artifactId' : 'WorkApproval.DescriptionView_workOrder',
                  'id' : 'aw9a9d0944',
               },
            };
            view004.addRequiredResources( requiredResources004 );

            var container009 = new Container({
               'artifactId' : 'WorkApproval.DescriptionView_container_0',
               'id' : 'awfa894663',
            });
            view004.addChild( container009 );


            var group006 = new Group({
               'artifactId' : 'WorkApproval.DescriptionView_group_0',
               'id' : 'aw4e3cbb07',
            });
            container009.addChild( group006 );


            var groupitem025 = new GroupItem({
               'artifactId' : 'WorkApproval.DescriptionView_groupitem_0',
               'id' : 'awbf52d770',
            });
            group006.addChild( groupitem025 );


            var text042 = new Text({
               'resourceAttribute' : 'description',
               'editable' : false,
               'artifactId' : 'WorkApproval.DescriptionView_groupitem_0_description',
               'id' : 'aw1b4bd72d',
            });
            groupitem025.addChild( text042 );


            var groupitem026 = new GroupItem({
               'artifactId' : 'WorkApproval.DescriptionView_groupitem_1',
               'id' : 'awc855e7e6',
            });
            group006.addChild( groupitem026 );


            var text043 = new Text({
               'resourceAttribute' : 'longdescription',
               'cssClass' : 'richText',
               'editable' : false,
               'artifactId' : 'WorkApproval.DescriptionView_groupitem_1_longdescription',
               'id' : 'aw9cefe084',
            });
            groupitem026.addChild( text043 );

            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'WorkApproval.AssetView', false);
               trackTimer.startTracking();
            }

            var view005 = new View({
               'id' : 'WorkApproval.AssetView',
               'label' : MessageService.createStaticMessage('Asset'),
            });
            ui001.addChild( view005 );

            var requiredResources005 = {
               'workOrder' : {
                  'artifactId' : 'WorkApproval.AssetView_workOrder',
                  'id' : 'aw56cf8429',
               },
            };
            view005.addRequiredResources( requiredResources005 );

            var container010 = new Container({
               'resource' : 'workOrder',
               'artifactId' : 'WorkApproval.AssetView_workOrder_container_0',
               'id' : 'awce48b9f9',
            });
            view005.addChild( container010 );


            var group007 = new Group({
               'artifactId' : 'WorkApproval.AssetView_group_0',
               'id' : 'aw6a3d017f',
            });
            container010.addChild( group007 );


            var groupitem027 = new GroupItem({
               'artifactId' : 'WorkApproval.AssetView_workOrder_groupitem_0',
               'id' : 'aw8b9328ea',
            });
            group007.addChild( groupitem027 );


            var text044 = new Text({
               'resourceAttribute' : 'asset',
               'editable' : false,
               'artifactId' : 'WorkApproval.AssetView_workOrder_groupitem_0_asset',
               'id' : 'aw8c6c50ca',
            });
            groupitem027.addChild( text044 );


            var text045 = new Text({
               'resourceAttribute' : 'assetdesc',
               'editable' : false,
               'artifactId' : 'WorkApproval.AssetView_workOrder_groupitem_0_assetdesc',
               'id' : 'aw53bf6726',
            });
            groupitem027.addChild( text045 );


            var groupitem028 = new GroupItem({
               'artifactId' : 'WorkApproval.AssetView_workOrder_groupitem_1',
               'id' : 'awfc94187c',
            });
            group007.addChild( groupitem028 );


            var text046 = new Text({
               'resourceAttribute' : 'localAssetLd',
               'cssClass' : 'richText',
               'editable' : false,
               'artifactId' : 'WorkApproval.AssetView_workOrder_groupitem_1_assetld',
               'id' : 'aw8f4b650a',
            });
            groupitem028.addChild( text046 );

            var eventHandlers029 = [
               {
                     'method' : 'initAssetView',
                     'artifactId' : 'WorkApproval.AssetView_eventHandlers_initialize_initAssetView',
                     'id' : 'aw44b536c9',
                     'event' : 'initialize',
                     'class' : 'application.handlers.WODetailsHandler',
               }
            ];
            view005.eventHandlers = eventHandlers029;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'WorkApproval.LocationView', false);
               trackTimer.startTracking();
            }

            var view006 = new View({
               'id' : 'WorkApproval.LocationView',
               'label' : MessageService.createStaticMessage('Location'),
            });
            ui001.addChild( view006 );

            var requiredResources006 = {
               'workOrder' : {
                  'artifactId' : 'WorkApproval.LocationView_workOrder',
                  'id' : 'awf0cfd6b7',
               },
            };
            view006.addRequiredResources( requiredResources006 );

            var container011 = new Container({
               'resource' : 'workOrder',
               'artifactId' : 'WorkApproval.LocationView_workOrder_container_0',
               'id' : 'awfcca7778',
            });
            view006.addChild( container011 );


            var group008 = new Group({
               'artifactId' : 'WorkApproval.LocationView_group_0',
               'id' : 'aw947bece',
            });
            container011.addChild( group008 );


            var groupitem029 = new GroupItem({
               'artifactId' : 'WorkApproval.LocationView_workOrder_groupitem_0',
               'id' : 'awb911e66b',
            });
            group008.addChild( groupitem029 );


            var text047 = new Text({
               'resourceAttribute' : 'location',
               'editable' : false,
               'artifactId' : 'WorkApproval.LocationView_workOrder_groupitem_0_location',
               'id' : 'aw17bb2af3',
            });
            groupitem029.addChild( text047 );


            var text048 = new Text({
               'resourceAttribute' : 'locationdesc',
               'editable' : false,
               'artifactId' : 'WorkApproval.LocationView_workOrder_groupitem_0_locationdesc',
               'id' : 'aw2e5e249f',
            });
            groupitem029.addChild( text048 );


            var groupitem030 = new GroupItem({
               'artifactId' : 'WorkApproval.LocationView_workOrder_groupitem_1',
               'id' : 'awce16d6fd',
            });
            group008.addChild( groupitem030 );


            var text049 = new Text({
               'resourceAttribute' : 'localLocationLd',
               'cssClass' : 'richText',
               'editable' : false,
               'artifactId' : 'WorkApproval.LocationView_workOrder_groupitem_1_locationld',
               'id' : 'awbdc1b369',
            });
            groupitem030.addChild( text049 );

            var eventHandlers030 = [
               {
                     'method' : 'initLocationView',
                     'artifactId' : 'WorkApproval.LocationView_eventHandlers_initialize_initLocationView',
                     'id' : 'aw6e6b8e11',
                     'event' : 'initialize',
                     'class' : 'application.handlers.WODetailsHandler',
               }
            ];
            view006.eventHandlers = eventHandlers030;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'WorkApproval.EditStatusView', false);
               trackTimer.startTracking();
            }

            var view007 = new View({
               'resource' : 'workOrder',
               'showOverflow' : false,
               'id' : 'WorkApproval.EditStatusView',
               'label' : MessageService.createStaticMessage('Change Status'),
            });
            ui001.addChild( view007 );

            var requiredResources007 = {
               'workOrder' : {
                  'artifactId' : 'WorkApproval.EditStatusView_workOrder',
                  'id' : 'awe6a8ba9c',
                  'related' : {
                     'tasklist' : {
                        'artifactId' : 'WorkApproval.EditStatusView_workOrder_tasklist',
                        'id' : 'aw972f42d6',
                     },
                  },
               },
               'statusChangeResource' : {
                  'artifactId' : 'WorkApproval.EditStatusView_statusChangeResource',
                  'id' : 'awf6c82388',
               },
            };
            view007.addRequiredResources( requiredResources007 );

            var container012 = new Container({
               'resource' : 'workOrder',
               'artifactId' : 'WorkApproval.EditStatusView_workOrder_container_0',
               'id' : 'aw23462883',
            });
            view007.addChild( container012 );


            var group009 = new Group({
               'artifactId' : 'WorkApproval.EditStatusView_group_0',
               'id' : 'aw71f64001',
            });
            container012.addChild( group009 );


            var groupitem031 = new GroupItem({
               'artifactId' : 'WorkApproval.EditStatusView_workOrder_groupitem_0',
               'id' : 'aw669db990',
            });
            group009.addChild( groupitem031 );


            var text050 = new Text({
               'resourceAttribute' : 'wonum',
               'editable' : false,
               'artifactId' : 'WorkApproval.EditStatusView_workOrder_groupitem_0_wonum_WorkOrder',
               'id' : 'aw30ecf419',
               'label' : MessageService.createStaticMessage('Work Order'),
            });
            groupitem031.addChild( text050 );


            var text051 = new Text({
               'resourceAttribute' : 'statusdesc',
               'editable' : false,
               'artifactId' : 'WorkApproval.EditStatusView_workOrder_groupitem_0_statusdesc_Status',
               'id' : 'aw2c1467ea',
               'label' : MessageService.createStaticMessage('Status'),
            });
            groupitem031.addChild( text051 );


            var container013 = new Container({
               'resource' : 'statusChangeResource',
               'artifactId' : 'WorkApproval.EditStatusView_statusChangeResource_container_0',
               'id' : 'awf32577d0',
            });
            view007.addChild( container013 );


            var group010 = new Group({
               'artifactId' : 'WorkApproval.EditStatusView_group_1',
               'id' : 'aw6f17097',
            });
            container013.addChild( group010 );


            var groupitem032 = new GroupItem({
               'artifactId' : 'WorkApproval.EditStatusView_statusChangeResource_groupitem_0',
               'id' : 'awb6fee6c3',
            });
            group010.addChild( groupitem032 );


            var text052 = new Text({
               'resourceAttribute' : 'changedate',
               'editable' : true,
               'artifactId' : 'WorkApproval.EditStatusView_statusChangeResource_groupitem_0_changedate_StatusDate',
               'id' : 'awb6ac968d',
               'label' : MessageService.createStaticMessage('Status Date'),
               'placeHolder' : MessageService.createStaticMessage('Select'),
               'required' : true,
            });
            groupitem032.addChild( text052 );


            var groupitem033 = new GroupItem({
               'artifactId' : 'WorkApproval.EditStatusView_statusChangeResource_groupitem_1',
               'id' : 'awc1f9d655',
            });
            group010.addChild( groupitem033 );


            var text053 = new Text({
               'resourceAttribute' : 'statusdesc',
               'lookup' : 'WorkApproval.statusLookup',
               'editable' : false,
               'artifactId' : 'WorkApproval.EditStatusView_statusChangeResource_groupitem_1_statusdesc_NewStatus',
               'id' : 'aw1faa62e1',
               'label' : MessageService.createStaticMessage('New Status'),
               'placeHolder' : MessageService.createStaticMessage('Select from list'),
               'required' : true,
            });
            groupitem033.addChild( text053 );


            var groupitem034 = new GroupItem({
               'artifactId' : 'WorkApproval.EditStatusView_statusChangeResource_groupitem_2',
               'id' : 'aw58f087ef',
            });
            group010.addChild( groupitem034 );


            var text054 = new Text({
               'resourceAttribute' : 'memo',
               'editable' : true,
               'artifactId' : 'WorkApproval.EditStatusView_statusChangeResource_groupitem_2_memo_Memo',
               'id' : 'aw3682ddc7',
               'label' : MessageService.createStaticMessage('Memo'),
               'placeHolder' : MessageService.createStaticMessage('Tap to enter'),
            });
            groupitem034.addChild( text054 );


            var footer001 = new Footer({
               'artifactId' : 'WorkApproval.EditStatusView_footer',
               'id' : 'aw682ba892',
            });
            view007.addChild( footer001 );


            var button010 = new Button({
               'resource' : 'workOrder',
               'artifactId' : 'WorkApproval.EditStatusView_Cancel_button',
               'id' : 'aw2c033361',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers031 = [
               {
                     'method' : 'discardStatusChange',
                     'artifactId' : 'WorkApproval.EditStatusView_Cancel_button_eventHandlers_click_discardStatusChange',
                     'id' : 'awfd4d97e0',
                     'event' : 'click',
                     'class' : 'application.handlers.StatusChangeHandler',
               }
            ];
            button010.eventHandlers = eventHandlers031;
            footer001.addChild( button010 );


            var button011 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'resource' : 'workOrder',
               'artifactId' : 'WorkApproval.EditStatusView_Save_button',
               'id' : 'aw4abcb313',
               'label' : MessageService.createStaticMessage('Save'),
               'primary' : 'true',
            });
            var eventHandlers032 = [
               {
                     'method' : 'commitWOStatusChange',
                     'artifactId' : 'WorkApproval.EditStatusView_Save_button_eventHandlers_click_commitWOStatusChange',
                     'id' : 'awd469c958',
                     'event' : 'click',
                     'class' : 'application.handlers.StatusChangeHandler',
               },
               {
                     'method' : 'enableCommitButton',
                     'artifactId' : 'WorkApproval.EditStatusView_Save_button_eventHandlers_datachange_enableCommitButton',
                     'id' : 'aw2e0f1f90',
                     'event' : 'datachange',
                     'class' : 'application.handlers.StatusChangeHandler',
               }
            ];
            button011.eventHandlers = eventHandlers032;
            footer001.addChild( button011 );

            var eventHandlers033 = [
               {
                     'method' : 'initEditStatusView',
                     'artifactId' : 'WorkApproval.EditStatusView_eventHandlers_initialize_initEditStatusView',
                     'id' : 'aw236502e4',
                     'event' : 'initialize',
                     'class' : 'application.handlers.StatusChangeHandler',
               },
               {
                     'method' : 'cleanupEditStatusView',
                     'artifactId' : 'WorkApproval.EditStatusView_eventHandlers_cleanup_cleanupEditStatusView',
                     'id' : 'aw9b7da758',
                     'event' : 'cleanup',
                     'class' : 'application.handlers.StatusChangeHandler',
               }
            ];
            view007.eventHandlers = eventHandlers033;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'WorkApproval.EditTaskStatusView', false);
               trackTimer.startTracking();
            }

            var view008 = new View({
               'resource' : 'workOrder',
               'showOverflow' : false,
               'id' : 'WorkApproval.EditTaskStatusView',
               'label' : MessageService.createStaticMessage('Change Status'),
            });
            ui001.addChild( view008 );

            var requiredResources008 = {
               'workOrder' : {
                  'artifactId' : 'WorkApproval.EditTaskStatusView_workOrder',
                  'id' : 'aw1265e38f',
                  'related' : {
                     'tasklist' : {
                        'artifactId' : 'WorkApproval.EditTaskStatusView_workOrder_tasklist',
                        'id' : 'aw6bc271cb',
                     },
                  },
               },
               'statusChangeResource' : {
                  'artifactId' : 'WorkApproval.EditTaskStatusView_statusChangeResource',
                  'id' : 'awb674d26f',
               },
            };
            view008.addRequiredResources( requiredResources008 );

            var container014 = new Container({
               'resource' : 'workOrder',
               'artifactId' : 'WorkApproval.EditTaskStatusView_workOrder_container_0',
               'attribute' : 'tasklist',
               'id' : 'aw1d68e3a9',
            });
            view008.addChild( container014 );


            var group011 = new Group({
               'artifactId' : 'WorkApproval.EditTaskStatusView_group_0',
               'id' : 'awf1822797',
            });
            container014.addChild( group011 );


            var groupitem035 = new GroupItem({
               'artifactId' : 'WorkApproval.EditTaskStatusView_workOrder_groupitem_0',
               'id' : 'aw58b372ba',
            });
            group011.addChild( groupitem035 );


            var text055 = new Text({
               'resourceAttribute' : 'parent',
               'editable' : false,
               'artifactId' : 'WorkApproval.EditTaskStatusView_workOrder_groupitem_0_parent_WorkOrder',
               'id' : 'aw24ee62b2',
               'label' : MessageService.createStaticMessage('Work Order'),
            });
            groupitem035.addChild( text055 );


            var text056 = new Text({
               'resourceAttribute' : 'taskid',
               'editable' : false,
               'artifactId' : 'WorkApproval.EditTaskStatusView_workOrder_groupitem_0_taskid_Task',
               'id' : 'aw71973054',
               'label' : MessageService.createStaticMessage('Task'),
            });
            groupitem035.addChild( text056 );


            var text057 = new Text({
               'resourceAttribute' : 'statusdesc',
               'editable' : false,
               'artifactId' : 'WorkApproval.EditTaskStatusView_workOrder_groupitem_0_statusdesc_Status',
               'id' : 'aw27fe9421',
               'label' : MessageService.createStaticMessage('Status'),
            });
            groupitem035.addChild( text057 );


            var container015 = new Container({
               'resource' : 'statusChangeResource',
               'artifactId' : 'WorkApproval.EditTaskStatusView_statusChangeResource_container_0',
               'id' : 'awcd3d4dab',
            });
            view008.addChild( container015 );


            var group012 = new Group({
               'artifactId' : 'WorkApproval.EditTaskStatusView_group_1',
               'id' : 'aw86851701',
            });
            container015.addChild( group012 );


            var groupitem036 = new GroupItem({
               'artifactId' : 'WorkApproval.EditTaskStatusView_statusChangeResource_groupitem_0',
               'id' : 'aw88e6dcb8',
            });
            group012.addChild( groupitem036 );


            var text058 = new Text({
               'resourceAttribute' : 'changedate',
               'editable' : true,
               'artifactId' : 'WorkApproval.EditTaskStatusView_statusChangeResource_groupitem_0_changedate_StatusDate',
               'id' : 'aw1c0dffa8',
               'label' : MessageService.createStaticMessage('Status Date'),
               'placeHolder' : MessageService.createStaticMessage('Select'),
               'required' : true,
            });
            groupitem036.addChild( text058 );


            var groupitem037 = new GroupItem({
               'artifactId' : 'WorkApproval.EditTaskStatusView_statusChangeResource_groupitem_1',
               'id' : 'awffe1ec2e',
            });
            group012.addChild( groupitem037 );


            var text059 = new Text({
               'resourceAttribute' : 'statusdesc',
               'lookup' : 'WorkApproval.taskStatusLookup',
               'editable' : false,
               'artifactId' : 'WorkApproval.EditTaskStatusView_statusChangeResource_groupitem_1_statusdesc_NewStatus',
               'id' : 'awb48f188f',
               'label' : MessageService.createStaticMessage('New Status'),
               'placeHolder' : MessageService.createStaticMessage('Select from list'),
               'required' : true,
            });
            groupitem037.addChild( text059 );


            var groupitem038 = new GroupItem({
               'artifactId' : 'WorkApproval.EditTaskStatusView_statusChangeResource_groupitem_2',
               'id' : 'aw66e8bd94',
            });
            group012.addChild( groupitem038 );


            var text060 = new Text({
               'resourceAttribute' : 'memo',
               'editable' : true,
               'artifactId' : 'WorkApproval.EditTaskStatusView_statusChangeResource_groupitem_2_memo_Memo',
               'id' : 'awd4361d75',
               'label' : MessageService.createStaticMessage('Memo'),
               'placeHolder' : MessageService.createStaticMessage('Tap to enter'),
            });
            groupitem038.addChild( text060 );


            var footer002 = new Footer({
               'artifactId' : 'WorkApproval.EditTaskStatusView_footer',
               'id' : 'aw792bf507',
            });
            view008.addChild( footer002 );


            var button012 = new Button({
               'resource' : 'workOrder',
               'artifactId' : 'WorkApproval.EditTaskStatusView_Cancel_button',
               'id' : 'awc9464129',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers034 = [
               {
                     'method' : 'discardStatusChange',
                     'artifactId' : 'WorkApproval.EditTaskStatusView_Cancel_button_eventHandlers_click_discardStatusChange',
                     'id' : 'aw5668ed8e',
                     'event' : 'click',
                     'class' : 'application.handlers.StatusChangeHandler',
               }
            ];
            button012.eventHandlers = eventHandlers034;
            footer002.addChild( button012 );


            var button013 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'resource' : 'workOrder',
               'artifactId' : 'WorkApproval.EditTaskStatusView_Save_button',
               'id' : 'aw39e4ef1c',
               'label' : MessageService.createStaticMessage('Save'),
               'primary' : 'true',
            });
            var eventHandlers035 = [
               {
                     'method' : 'commitTaskStatusChange',
                     'artifactId' : 'WorkApproval.EditTaskStatusView_Save_button_eventHandlers_click_commitTaskStatusChange',
                     'id' : 'aw6fc64cc',
                     'event' : 'click',
                     'class' : 'application.handlers.StatusChangeHandler',
               }
            ];
            button013.eventHandlers = eventHandlers035;
            footer002.addChild( button013 );

            var eventHandlers036 = [
               {
                     'method' : 'initEditStatusView',
                     'artifactId' : 'WorkApproval.EditTaskStatusView_eventHandlers_initialize_initEditStatusView',
                     'id' : 'aw6e86484',
                     'event' : 'initialize',
                     'class' : 'application.handlers.StatusChangeHandler',
               }
            ];
            view008.eventHandlers = eventHandlers036;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'WorkApproval.MultipleAssetsLocationsView', false);
               trackTimer.startTracking();
            }

            var view009 = new View({
               'id' : 'WorkApproval.MultipleAssetsLocationsView',
               'label' : MessageService.createStaticMessage('Multiple Assets & Locations'),
            });
            ui001.addChild( view009 );

            var requiredResources009 = {
               'workOrder' : {
                  'artifactId' : 'WorkApproval.MultipleAssetsLocationsView_workOrder',
                  'id' : 'aw9eb90c7a',
                  'related' : {
                     'multiassetloclist' : {
                        'artifactId' : 'WorkApproval.MultipleAssetsLocationsView_workOrder_multiassetloclist',
                        'id' : 'aw9cb0f577',
                     },
                  },
               },
            };
            view009.addRequiredResources( requiredResources009 );


            var sortOptions002 = new SortOptions({
               'artifactId' : 'WorkApproval.MultipleAssetsLocationsView_workOrder_multiassetloclist_list_sortOptions',
               'id' : 'aw8e8e568a',
            });

            var sortOption004 = new SortOption({
               'artifactId' : 'WorkApproval.MultipleAssetsLocationsView_sortOption_Sequence',
               'id' : 'aw8a286cd2',
               'label' : MessageService.createStaticMessage('Sequence'),
            });
            sortOptions002.addChild( sortOption004 );


            var sortAttribute004 = new SortAttribute({
               'name' : 'sequence',
               'artifactId' : 'WorkApproval.MultipleAssetsLocationsView_Sequence_sortAttribute_sequence',
               'id' : 'awe18094d1',
               'direction' : 'asc',
            });
            sortOption004.addChild( sortAttribute004 );


            var sortOption005 = new SortOption({
               'artifactId' : 'WorkApproval.MultipleAssetsLocationsView_sortOption_Asset',
               'id' : 'awf8edb3e2',
               'label' : MessageService.createStaticMessage('Asset'),
            });
            sortOptions002.addChild( sortOption005 );


            var sortAttribute005 = new SortAttribute({
               'name' : 'assetnumanddescription',
               'artifactId' : 'WorkApproval.MultipleAssetsLocationsView_Asset_sortAttribute_assetnumanddescription',
               'id' : 'aw1bf560e1',
               'direction' : 'asc',
            });
            sortOption005.addChild( sortAttribute005 );


            var sortOption006 = new SortOption({
               'artifactId' : 'WorkApproval.MultipleAssetsLocationsView_sortOption_Location',
               'id' : 'aw86303232',
               'label' : MessageService.createStaticMessage('Location'),
            });
            sortOptions002.addChild( sortOption006 );


            var sortAttribute006 = new SortAttribute({
               'name' : 'locationanddescription',
               'artifactId' : 'WorkApproval.MultipleAssetsLocationsView_Location_sortAttribute_locationanddescription',
               'id' : 'aw3db3a16f',
               'direction' : 'asc',
            });
            sortOption006.addChild( sortAttribute006 );



            var listItemTemplate002 = new ListItemTemplate({
               'artifactId' : 'WorkApproval.MultipleAssetsLocationsView_workOrder_multiassetloclist_listItemTemplate',
               'id' : 'aw810137cf',
            });

            var listtext006 = new ListText({
               'resourceAttribute' : 'sequence',
               'artifactId' : 'WorkApproval.MultipleAssetsLocationsView_workOrder_sequence',
               'id' : 'awdce5b30f',
            });
            listItemTemplate002.addChild( listtext006 );


            var listtext007 = new ListText({
               'resourceAttribute' : 'assetnumanddescription',
               'cssClass' : 'bold textappearance-medium',
               'artifactId' : 'WorkApproval.MultipleAssetsLocationsView_workOrder_assetnumanddescription',
               'id' : 'awd849d126',
            });
            listItemTemplate002.addChild( listtext007 );


            var listtext008 = new ListText({
               'resourceAttribute' : 'locationanddescription',
               'cssClass' : 'bold textappearance-medium',
               'artifactId' : 'WorkApproval.MultipleAssetsLocationsView_workOrder_locationanddescription',
               'id' : 'aw7cb92b80',
            });
            listItemTemplate002.addChild( listtext008 );



            var list002 = new List({
               'resource' : 'workOrder',
               'sortOptions' : sortOptions002,
               'listItemTemplate' : listItemTemplate002,
               'artifactId' : 'WorkApproval.MultipleAssetsLocationsView_workOrder_multiassetloclist_list',
               'attribute' : 'multiassetloclist',
               'id' : 'awfb0d694f',
            });
            view009.addChild( list002 );

            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'WorkApproval.TasksView', false);
               trackTimer.startTracking();
            }

            var view010 = new View({
               'id' : 'WorkApproval.TasksView',
               'label' : MessageService.createStaticMessage('Tasks'),
            });
            ui001.addChild( view010 );

            var requiredResources010 = {
               'workOrder' : {
                  'artifactId' : 'WorkApproval.TasksView_workOrder',
                  'id' : 'awebf3fcb3',
                  'related' : {
                     'tasklist' : {
                        'artifactId' : 'WorkApproval.TasksView_workOrder_tasklist',
                        'id' : 'awb8d96a5d',
                     },
                  },
               },
            };
            view010.addRequiredResources( requiredResources010 );


            var sortOptions003 = new SortOptions({
               'artifactId' : 'WorkApproval.TasksView_workOrder_tasklist_list_sortOptions',
               'id' : 'aw46b5aa36',
            });

            var sortOption007 = new SortOption({
               'artifactId' : 'WorkApproval.TasksView_sortOption_Task',
               'id' : 'awc7ea0bf8',
               'label' : MessageService.createStaticMessage('Task'),
            });
            sortOptions003.addChild( sortOption007 );


            var sortAttribute007 = new SortAttribute({
               'name' : 'taskid',
               'artifactId' : 'WorkApproval.TasksView_Task_sortAttribute_taskid',
               'id' : 'aw36763275',
               'direction' : 'asc',
            });
            sortOption007.addChild( sortAttribute007 );



            var listItemTemplate003 = new ListItemTemplate({
               'artifactId' : 'WorkApproval.TasksView_workOrder_tasklist_listItemTemplate',
               'id' : 'aw493acb73',
            });

            var listtext009 = new ListText({
               'resourceAttribute' : 'taskid',
               'artifactId' : 'WorkApproval.TasksView_workOrder_taskid',
               'id' : 'awc2df69fd',
            });
            listItemTemplate003.addChild( listtext009 );


            var listtext010 = new ListText({
               'resourceAttribute' : 'taskdescription',
               'cssClass' : 'bold textappearance-medium',
               'artifactId' : 'WorkApproval.TasksView_workOrder_taskdescription',
               'id' : 'awba49ba9d',
            });
            listItemTemplate003.addChild( listtext010 );


            var listtext011 = new ListText({
               'resourceAttribute' : 'statusdesc',
               'artifactId' : 'WorkApproval.TasksView_workOrder_statusdesc',
               'id' : 'aw4622a789',
            });
            listItemTemplate003.addChild( listtext011 );



            var list003 = new List({
               'resource' : 'workOrder',
               'transitionTo' : 'WorkApproval.TaskDetailView',
               'sortOptions' : sortOptions003,
               'listItemTemplate' : listItemTemplate003,
               'artifactId' : 'WorkApproval.TasksView_workOrder_tasklist_list',
               'attribute' : 'tasklist',
               'id' : 'aw23b1be11',
            });
            view010.addChild( list003 );

            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'WorkApproval.TaskDetailView', false);
               trackTimer.startTracking();
            }

            var view011 = new View({
               'id' : 'WorkApproval.TaskDetailView',
               'label' : MessageService.createStaticMessage('Task Details'),
               'resolverFunction' : 'resolveWonumLabel',
               'resolverClass' : 'application.handlers.WODetailsHandler',
            });
            ui001.addChild( view011 );

            var requiredResources011 = {
               'workOrder' : {
                  'artifactId' : 'WorkApproval.TaskDetailView_workOrder',
                  'id' : 'aw7b79cac',
                  'related' : {
                     'tasklist' : {
                        'artifactId' : 'WorkApproval.TaskDetailView_workOrder_tasklist',
                        'id' : 'awca89cdd5',
                     },
                  },
               },
            };
            view011.addRequiredResources( requiredResources011 );

            var container016 = new Container({
               'resource' : 'workOrder',
               'artifactId' : 'WorkApproval.TaskDetailView_workOrder_container_0',
               'attribute' : 'tasklist',
               'id' : 'awa2ae14de',
            });
            view011.addChild( container016 );


            var group013 = new Group({
               'artifactId' : 'WorkApproval.TaskDetailView_group_0',
               'id' : 'awced557da',
            });
            container016.addChild( group013 );


            var groupitem039 = new GroupItem({
               'transitionTo' : 'WorkApproval.EditTaskStatusView',
               'artifactId' : 'WorkApproval.TaskDetailView_workOrder_groupitem_WorkApproval.EditTaskStatusView_0',
               'id' : 'awadb8bd0c',
            });
            group013.addChild( groupitem039 );


            var text061 = new Text({
               'resourceAttribute' : 'statusdesc',
               'editable' : false,
               'artifactId' : 'WorkApproval.TaskDetailView_workOrder_groupitem_WorkApproval.EditTaskStatusView_0_statusdesc_Status',
               'id' : 'awf4c308e5',
               'label' : MessageService.createStaticMessage('Status'),
            });
            groupitem039.addChild( text061 );


            var groupitem040 = new GroupItem({
               'artifactId' : 'WorkApproval.TaskDetailView_workOrder_groupitem_0',
               'id' : 'awe77585cd',
            });
            group013.addChild( groupitem040 );


            var text062 = new Text({
               'resourceAttribute' : 'taskid',
               'editable' : false,
               'artifactId' : 'WorkApproval.TaskDetailView_workOrder_groupitem_0_taskid_Task',
               'id' : 'aw63c15b6a',
               'label' : MessageService.createStaticMessage('Task'),
            });
            groupitem040.addChild( text062 );


            var groupitem041 = new GroupItem({
               'transitionTo' : 'WorkApproval.TaskView',
               'artifactId' : 'WorkApproval.TaskDetailView_workOrder_groupitem_WorkApproval.TaskView_0',
               'id' : 'aw1865fdb2',
            });
            group013.addChild( groupitem041 );


            var text063 = new Text({
               'resourceAttribute' : 'taskdescription',
               'editable' : false,
               'artifactId' : 'WorkApproval.TaskDetailView_workOrder_groupitem_WorkApproval.TaskView_0_taskdescription_Description',
               'id' : 'aw26d763aa',
               'label' : MessageService.createStaticMessage('Description'),
            });
            groupitem041.addChild( text063 );


            var groupitem042 = new GroupItem({
               'transitionTo' : 'WorkApproval.AssetView',
               'artifactId' : 'WorkApproval.TaskDetailView_workOrder_groupitem_WorkApproval.AssetView_0',
               'id' : 'aw7e09ccfa',
            });
            group013.addChild( groupitem042 );


            var text064 = new Text({
               'resourceAttribute' : 'assetnumanddescription',
               'editable' : false,
               'artifactId' : 'WorkApproval.TaskDetailView_workOrder_groupitem_WorkApproval.AssetView_0_assetnumanddescription_Asset',
               'id' : 'aw76325c56',
               'label' : MessageService.createStaticMessage('Asset'),
            });
            groupitem042.addChild( text064 );


            var groupitem043 = new GroupItem({
               'transitionTo' : 'WorkApproval.LocationView',
               'artifactId' : 'WorkApproval.TaskDetailView_workOrder_groupitem_WorkApproval.LocationView_0',
               'id' : 'aw1de1c731',
            });
            group013.addChild( groupitem043 );


            var text065 = new Text({
               'resourceAttribute' : 'locationanddescription',
               'editable' : false,
               'artifactId' : 'WorkApproval.TaskDetailView_workOrder_groupitem_WorkApproval.LocationView_0_locationanddescription_Location',
               'id' : 'awb00c6401',
               'label' : MessageService.createStaticMessage('Location'),
            });
            groupitem043.addChild( text065 );


            var groupitem044 = new GroupItem({
               'artifactId' : 'WorkApproval.TaskDetailView_workOrder_groupitem_1',
               'id' : 'aw9072b55b',
            });
            group013.addChild( groupitem044 );


            var text066 = new Text({
               'resourceAttribute' : 'schedstart',
               'editable' : false,
               'artifactId' : 'WorkApproval.TaskDetailView_workOrder_groupitem_1_schedstart_ScheduledStart',
               'id' : 'aw3b0b325a',
               'label' : MessageService.createStaticMessage('Scheduled Start'),
            });
            groupitem044.addChild( text066 );


            var group014 = new Group({
               'artifactId' : 'WorkApproval.TaskDetailView_group_1',
               'id' : 'awb9d2674c',
            });
            container016.addChild( group014 );


            var groupitem045 = new GroupItem({
               'artifactId' : 'WorkApproval.TaskDetailView_workOrder_groupitem_2',
               'id' : 'aw97be4e1',
            });
            group014.addChild( groupitem045 );


            var lastupdatetext002 = new LastUpdateText({
               'artifactId' : 'WorkApproval.TaskDetailView_lastupdatetext',
               'id' : 'aw46d8af08',
            });
            groupitem045.addChild( lastupdatetext002 );

            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'WorkApproval.TaskView', false);
               trackTimer.startTracking();
            }

            var view012 = new View({
               'id' : 'WorkApproval.TaskView',
               'label' : MessageService.createStaticMessage('Task'),
            });
            ui001.addChild( view012 );

            var requiredResources012 = {
               'workOrder' : {
                  'artifactId' : 'WorkApproval.TaskView_workOrder',
                  'id' : 'aw34b0c715',
                  'related' : {
                     'tasklist' : {
                        'artifactId' : 'WorkApproval.TaskView_workOrder_tasklist',
                        'id' : 'aw614b1f0e',
                     },
                  },
               },
            };
            view012.addRequiredResources( requiredResources012 );

            var container017 = new Container({
               'resource' : 'workOrder',
               'artifactId' : 'WorkApproval.TaskView_workOrder_container_0',
               'attribute' : 'tasklist',
               'id' : 'awe516caa5',
            });
            view012.addChild( container017 );


            var group015 = new Group({
               'artifactId' : 'WorkApproval.TaskView_group_0',
               'id' : 'aw53af2f5c',
            });
            container017.addChild( group015 );


            var groupitem046 = new GroupItem({
               'artifactId' : 'WorkApproval.TaskView_workOrder_groupitem_0',
               'id' : 'awa0cd5bb6',
            });
            group015.addChild( groupitem046 );


            var text067 = new Text({
               'resourceAttribute' : 'taskdescription',
               'editable' : false,
               'artifactId' : 'WorkApproval.TaskView_workOrder_groupitem_0_taskdescription',
               'id' : 'awa75a9988',
            });
            groupitem046.addChild( text067 );


            var groupitem047 = new GroupItem({
               'artifactId' : 'WorkApproval.TaskView_workOrder_groupitem_1',
               'id' : 'awd7ca6b20',
            });
            group015.addChild( groupitem047 );


            var text068 = new Text({
               'resourceAttribute' : 'tasklongdesc',
               'cssClass' : 'richText',
               'editable' : false,
               'artifactId' : 'WorkApproval.TaskView_workOrder_groupitem_1_tasklongdesc',
               'id' : 'aw89022aa7',
            });
            groupitem047.addChild( text068 );

            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'WorkApproval.PlannedLaborView', false);
               trackTimer.startTracking();
            }

            var view013 = new View({
               'id' : 'WorkApproval.PlannedLaborView',
               'label' : MessageService.createStaticMessage('Planned Labor'),
            });
            ui001.addChild( view013 );

            var requiredResources013 = {
               'workOrder' : {
                  'artifactId' : 'WorkApproval.PlannedLaborView_workOrder',
                  'id' : 'aw389f605f',
                  'related' : {
                     'laborlist' : {
                        'artifactId' : 'WorkApproval.PlannedLaborView_workOrder_laborlist',
                        'id' : 'aw77c602c7',
                     },
                  },
               },
            };
            view013.addRequiredResources( requiredResources013 );


            var sortOptions004 = new SortOptions({
               'artifactId' : 'WorkApproval.PlannedLaborView_workOrder_laborlist_list_sortOptions',
               'id' : 'aw17a2c505',
            });

            var sortOption008 = new SortOption({
               'artifactId' : 'WorkApproval.PlannedLaborView_sortOption_TaskIDCraft',
               'id' : 'aw2c3f0115',
               'label' : MessageService.createStaticMessage('Task ID, Craft'),
            });
            sortOptions004.addChild( sortOption008 );


            var sortAttribute008 = new SortAttribute({
               'name' : 'taskid',
               'artifactId' : 'WorkApproval.PlannedLaborView_TaskIDCraft_sortAttribute_taskid',
               'id' : 'aw9130b544',
               'direction' : 'asc',
            });
            sortOption008.addChild( sortAttribute008 );


            var sortAttribute009 = new SortAttribute({
               'name' : 'craft',
               'artifactId' : 'WorkApproval.PlannedLaborView_TaskIDCraft_sortAttribute_craft',
               'id' : 'aw2d57565',
               'direction' : 'asc',
            });
            sortOption008.addChild( sortAttribute009 );



            var listItemTemplate004 = new ListItemTemplate({
               'layout' : 'PlannedLaborListItem',
               'artifactId' : 'WorkApproval.PlannedLaborView_workOrder_laborlist_listItemTemplate_PlannedLaborListItem',
               'id' : 'awd5344697',
            });

            var listtext012 = new ListText({
               'resourceAttribute' : 'taskid',
               'layoutInsertAt' : 'item1',
               'artifactId' : 'WorkApproval.PlannedLaborView_workOrder_PlannedLaborListItem_taskid',
               'id' : 'aw94b68315',
            });
            listItemTemplate004.addChild( listtext012 );


            var listtext013 = new ListText({
               'resourceAttribute' : 'craft',
               'layoutInsertAt' : 'item2',
               'artifactId' : 'WorkApproval.PlannedLaborView_workOrder_PlannedLaborListItem_craft',
               'id' : 'aw84b437a2',
            });
            listItemTemplate004.addChild( listtext013 );


            var listtext014 = new ListText({
               'resourceAttribute' : 'skilllevel',
               'layoutInsertAt' : 'item3',
               'artifactId' : 'WorkApproval.PlannedLaborView_workOrder_PlannedLaborListItem_skilllevel',
               'id' : 'awdf947ab1',
            });
            listItemTemplate004.addChild( listtext014 );


            var listtext015 = new ListText({
               'resourceAttribute' : 'crewtype',
               'layoutInsertAt' : 'item4',
               'artifactId' : 'WorkApproval.PlannedLaborView_workOrder_PlannedLaborListItem_crewtype',
               'id' : 'awf660c4e3',
            });
            listItemTemplate004.addChild( listtext015 );


            var listtext016 = new ListText({
               'resourceAttribute' : 'linecost',
               'layoutInsertAt' : 'item5',
               'artifactId' : 'WorkApproval.PlannedLaborView_workOrder_PlannedLaborListItem_linecost',
               'id' : 'awae86e98f',
            });
            listItemTemplate004.addChild( listtext016 );



            var list004 = new List({
               'resource' : 'workOrder',
               'transitionTo' : 'WorkApproval.PlannedLaborDetailView',
               'sortOptions' : sortOptions004,
               'listItemTemplate' : listItemTemplate004,
               'artifactId' : 'WorkApproval.PlannedLaborView_workOrder_laborlist_list',
               'attribute' : 'laborlist',
               'id' : 'aw1d8d7180',
            });
            view013.addChild( list004 );

            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'WorkApproval.PlannedLaborDetailView', false);
               trackTimer.startTracking();
            }

            var view014 = new View({
               'id' : 'WorkApproval.PlannedLaborDetailView',
               'label' : MessageService.createStaticMessage('Labor Details'),
            });
            ui001.addChild( view014 );

            var requiredResources014 = {
               'workOrder' : {
                  'artifactId' : 'WorkApproval.PlannedLaborDetailView_workOrder',
                  'id' : 'aw9a38b02c',
                  'related' : {
                     'laborlist' : {
                        'artifactId' : 'WorkApproval.PlannedLaborDetailView_workOrder_laborlist',
                        'id' : 'awe0351b7',
                     },
                  },
               },
            };
            view014.addRequiredResources( requiredResources014 );

            var container018 = new Container({
               'resource' : 'workOrder',
               'artifactId' : 'WorkApproval.PlannedLaborDetailView_workOrder_container_0',
               'attribute' : 'laborlist',
               'id' : 'aw623b91cb',
            });
            view014.addChild( container018 );


            var group016 = new Group({
               'artifactId' : 'WorkApproval.PlannedLaborDetailView_group_0',
               'id' : 'awfde1d020',
            });
            container018.addChild( group016 );


            var groupitem048 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedLaborDetailView_workOrder_groupitem_0',
               'id' : 'aw27e000d8',
            });
            group016.addChild( groupitem048 );


            var text069 = new Text({
               'resourceAttribute' : 'taskid',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedLaborDetailView_workOrder_groupitem_0_taskid_Task',
               'id' : 'aw6e8918be',
               'label' : MessageService.createStaticMessage('Task'),
            });
            groupitem048.addChild( text069 );


            var groupitem049 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedLaborDetailView_workOrder_groupitem_1',
               'id' : 'aw50e7304e',
            });
            group016.addChild( groupitem049 );


            var text070 = new Text({
               'resourceAttribute' : 'laborcode',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedLaborDetailView_workOrder_groupitem_1_laborcode_Labor',
               'id' : 'aw4fdd96c8',
               'label' : MessageService.createStaticMessage('Labor'),
            });
            groupitem049.addChild( text070 );


            var groupitem050 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedLaborDetailView_workOrder_groupitem_2',
               'id' : 'awc9ee61f4',
            });
            group016.addChild( groupitem050 );


            var text071 = new Text({
               'resourceAttribute' : 'craft',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedLaborDetailView_workOrder_groupitem_2_craft_Craft',
               'id' : 'awaef25290',
               'label' : MessageService.createStaticMessage('Craft'),
            });
            groupitem050.addChild( text071 );


            var groupitem051 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedLaborDetailView_workOrder_groupitem_3',
               'id' : 'awbee95162',
            });
            group016.addChild( groupitem051 );


            var text072 = new Text({
               'resourceAttribute' : 'skilllevel',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedLaborDetailView_workOrder_groupitem_3_skilllevel_SkillLevel',
               'id' : 'awff3ff871',
               'label' : MessageService.createStaticMessage('Skill Level'),
            });
            groupitem051.addChild( text072 );


            var groupitem052 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedLaborDetailView_workOrder_groupitem_4',
               'id' : 'aw208dc4c1',
            });
            group016.addChild( groupitem052 );


            var text073 = new Text({
               'resourceAttribute' : 'hours',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedLaborDetailView_workOrder_groupitem_4_hours_Hours',
               'id' : 'aw4d5ae57a',
               'label' : MessageService.createStaticMessage('Hours'),
            });
            groupitem052.addChild( text073 );


            var groupitem053 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedLaborDetailView_workOrder_groupitem_5',
               'id' : 'aw578af457',
            });
            group016.addChild( groupitem053 );


            var text074 = new Text({
               'resourceAttribute' : 'rate',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedLaborDetailView_workOrder_groupitem_5_rate_Rate',
               'id' : 'aw791dc299',
               'label' : MessageService.createStaticMessage('Rate'),
            });
            groupitem053.addChild( text074 );


            var groupitem054 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedLaborDetailView_workOrder_groupitem_6',
               'id' : 'awce83a5ed',
            });
            group016.addChild( groupitem054 );


            var text075 = new Text({
               'resourceAttribute' : 'linecost',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedLaborDetailView_workOrder_groupitem_6_linecost_Cost',
               'id' : 'awe416004e',
               'label' : MessageService.createStaticMessage('Cost'),
            });
            groupitem054.addChild( text075 );


            var groupitem055 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedLaborDetailView_workOrder_groupitem_7',
               'id' : 'awb984957b',
            });
            group016.addChild( groupitem055 );


            var text076 = new Text({
               'resourceAttribute' : 'vendor',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedLaborDetailView_workOrder_groupitem_7_vendor_Vendor',
               'id' : 'awc006dd93',
               'label' : MessageService.createStaticMessage('Vendor'),
            });
            groupitem055.addChild( text076 );


            var groupitem056 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedLaborDetailView_workOrder_groupitem_8',
               'id' : 'aw293b88ea',
            });
            group016.addChild( groupitem056 );


            var text077 = new Text({
               'resourceAttribute' : 'contractnum',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedLaborDetailView_workOrder_groupitem_8_contractnum_LaborContract',
               'id' : 'aw9d96fee6',
               'label' : MessageService.createStaticMessage('Labor Contract'),
            });
            groupitem056.addChild( text077 );


            var groupitem057 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedLaborDetailView_workOrder_groupitem_9',
               'id' : 'aw5e3cb87c',
            });
            group016.addChild( groupitem057 );


            var text078 = new Text({
               'resourceAttribute' : 'crewworkgroup',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedLaborDetailView_workOrder_groupitem_9_crewworkgroup_CrewWorkGroup',
               'id' : 'aw4a1766f7',
               'label' : MessageService.createStaticMessage('Crew Work Group'),
            });
            groupitem057.addChild( text078 );


            var groupitem058 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedLaborDetailView_workOrder_groupitem_10',
               'id' : 'aw65ef5486',
            });
            group016.addChild( groupitem058 );


            var text079 = new Text({
               'resourceAttribute' : 'crewtype',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedLaborDetailView_workOrder_groupitem_10_crewtype_CrewType',
               'id' : 'awe5207d05',
               'label' : MessageService.createStaticMessage('Crew Type'),
            });
            groupitem058.addChild( text079 );


            var groupitem059 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedLaborDetailView_workOrder_groupitem_11',
               'id' : 'aw12e86410',
            });
            group016.addChild( groupitem059 );


            var text080 = new Text({
               'resourceAttribute' : 'crew',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedLaborDetailView_workOrder_groupitem_11_crew_Crew',
               'id' : 'awdb8e4afd',
               'label' : MessageService.createStaticMessage('Crew'),
            });
            groupitem059.addChild( text080 );


            var group017 = new Group({
               'artifactId' : 'WorkApproval.PlannedLaborDetailView_group_1',
               'id' : 'aw8ae6e0b6',
            });
            container018.addChild( group017 );


            var groupitem060 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedLaborDetailView_workOrder_groupitem_12',
               'id' : 'aw8be135aa',
            });
            group017.addChild( groupitem060 );


            var lastupdatetext003 = new LastUpdateText({
               'artifactId' : 'WorkApproval.PlannedLaborDetailView_lastupdatetext',
               'id' : 'aw335ca7f6',
            });
            groupitem060.addChild( lastupdatetext003 );

            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'WorkApproval.CostsView', false);
               trackTimer.startTracking();
            }

            var view015 = new View({
               'resource' : 'workCosts',
               'id' : 'WorkApproval.CostsView',
               'label' : MessageService.createStaticMessage('Planned Costs'),
            });
            ui001.addChild( view015 );

            var requiredResources015 = {
               'workOrder' : {
                  'artifactId' : 'WorkApproval.CostsView_workOrder',
                  'id' : 'awc36f07df',
                  'related' : {
                     'tasklist' : {
                        'artifactId' : 'WorkApproval.CostsView_workOrder_tasklist',
                        'id' : 'aw63188be2',
                     },
                  },
               },
            };
            view015.addRequiredResources( requiredResources015 );

            var container019 = new Container({
               'artifactId' : 'WorkApproval.CostsView_container_0',
               'id' : 'aw8f846147',
            });
            view015.addChild( container019 );


            var container020 = new Container({
               'artifactId' : 'WorkApproval.CostsView_container_1',
               'id' : 'awf88351d1',
            });
            view015.addChild( container020 );


            var group018 = new Group({
               'artifactId' : 'WorkApproval.CostsView_group_0',
               'id' : 'aw79caa7ac',
            });
            container020.addChild( group018 );


            var groupitem061 = new GroupItem({
               'layout' : 'ViewCostLaborSection',
               'artifactId' : 'WorkApproval.CostsView_groupitem_0',
               'id' : 'awca5ff054',
            });
            group018.addChild( groupitem061 );


            var text081 = new Text({
               'cssClass' : 'bold textappearance-medium',
               'editable' : false,
               'layoutInsertAt' : 'item1',
               'artifactId' : 'WorkApproval.CostsView_groupitem_0_LaborTotal',
               'id' : 'awbdef13e7',
               'value' : MessageService.createStaticMessage('Labor Total'),
            });
            groupitem061.addChild( text081 );


            var text082 = new Text({
               'resourceAttribute' : 'localestlabhrs',
               'cssClass' : 'bold textappearance-medium',
               'editable' : false,
               'layoutInsertAt' : 'item2',
               'artifactId' : 'WorkApproval.CostsView_groupitem_0_localestlabhrs',
               'id' : 'aw8a328084',
            });
            groupitem061.addChild( text082 );


            var text083 = new Text({
               'cssClass' : 'bold textappearance-medium',
               'editable' : false,
               'layoutInsertAt' : 'item3',
               'artifactId' : 'WorkApproval.CostsView_groupitem_0_hours',
               'id' : 'awd05f47cf',
               'value' : MessageService.createStaticMessage('hours'),
            });
            groupitem061.addChild( text083 );


            var text084 = new Text({
               'resourceAttribute' : 'localestlabcost',
               'cssClass' : 'bold textappearance-medium',
               'editable' : false,
               'layoutInsertAt' : 'item4',
               'artifactId' : 'WorkApproval.CostsView_groupitem_0_localestlabcost',
               'id' : 'awacca9833',
            });
            groupitem061.addChild( text084 );


            var text085 = new Text({
               'cssClass' : 'bold listTextGreyed',
               'editable' : false,
               'layoutInsertAt' : 'item5',
               'artifactId' : 'WorkApproval.CostsView_groupitem_0_Internal',
               'id' : 'aw697e9a89',
               'value' : MessageService.createStaticMessage('Internal'),
            });
            groupitem061.addChild( text085 );


            var text086 = new Text({
               'resourceAttribute' : 'localestintlabhrs',
               'cssClass' : 'bold listTextGreyed',
               'editable' : false,
               'layoutInsertAt' : 'item6',
               'artifactId' : 'WorkApproval.CostsView_groupitem_0_localestintlabhrs',
               'id' : 'awbb2563cc',
            });
            groupitem061.addChild( text086 );


            var text087 = new Text({
               'resourceAttribute' : 'localestintlabcost',
               'cssClass' : 'bold listTextGreyed',
               'editable' : false,
               'layoutInsertAt' : 'item7',
               'artifactId' : 'WorkApproval.CostsView_groupitem_0_localestintlabcost',
               'id' : 'awd4fc4672',
            });
            groupitem061.addChild( text087 );


            var text088 = new Text({
               'cssClass' : 'bold listTextGreyed',
               'editable' : false,
               'layoutInsertAt' : 'item8',
               'artifactId' : 'WorkApproval.CostsView_groupitem_0_External',
               'id' : 'aw3adf2632',
               'value' : MessageService.createStaticMessage('External'),
            });
            groupitem061.addChild( text088 );


            var text089 = new Text({
               'resourceAttribute' : 'localestoutlabhrs',
               'cssClass' : 'bold listTextGreyed',
               'editable' : false,
               'layoutInsertAt' : 'item9',
               'artifactId' : 'WorkApproval.CostsView_groupitem_0_localestoutlabhrs',
               'id' : 'awe9ee373b',
            });
            groupitem061.addChild( text089 );


            var text090 = new Text({
               'resourceAttribute' : 'localestoutlabcost',
               'cssClass' : 'bold listTextGreyed',
               'editable' : false,
               'layoutInsertAt' : 'item10',
               'artifactId' : 'WorkApproval.CostsView_groupitem_0_localestoutlabcost',
               'id' : 'awf777ea99',
            });
            groupitem061.addChild( text090 );


            var container021 = new Container({
               'artifactId' : 'WorkApproval.CostsView_container_2',
               'id' : 'aw618a006b',
            });
            view015.addChild( container021 );


            var group019 = new Group({
               'artifactId' : 'WorkApproval.CostsView_group_1',
               'id' : 'awecd973a',
            });
            container021.addChild( group019 );


            var groupitem062 = new GroupItem({
               'layout' : 'ViewCostLine',
               'artifactId' : 'WorkApproval.CostsView_groupitem_1',
               'id' : 'awbd58c0c2',
            });
            group019.addChild( groupitem062 );


            var text091 = new Text({
               'cssClass' : 'bold textappearance-medium',
               'editable' : false,
               'layoutInsertAt' : 'item1',
               'artifactId' : 'WorkApproval.CostsView_groupitem_1_Materials',
               'id' : 'aw57962ecc',
               'value' : MessageService.createStaticMessage('Materials'),
            });
            groupitem062.addChild( text091 );


            var text092 = new Text({
               'resourceAttribute' : 'localestmatcost',
               'cssClass' : 'bold textappearance-medium',
               'editable' : false,
               'layoutInsertAt' : 'item2',
               'artifactId' : 'WorkApproval.CostsView_groupitem_1_localestmatcost',
               'id' : 'aw62bb3ae6',
            });
            groupitem062.addChild( text092 );


            var container022 = new Container({
               'artifactId' : 'WorkApproval.CostsView_container_3',
               'id' : 'aw168d30fd',
            });
            view015.addChild( container022 );


            var group020 = new Group({
               'artifactId' : 'WorkApproval.CostsView_group_2',
               'id' : 'aw97c4c680',
            });
            container022.addChild( group020 );


            var groupitem063 = new GroupItem({
               'layout' : 'ViewCostLine',
               'artifactId' : 'WorkApproval.CostsView_groupitem_2',
               'id' : 'aw24519178',
            });
            group020.addChild( groupitem063 );


            var text093 = new Text({
               'cssClass' : 'bold textappearance-medium',
               'editable' : false,
               'layoutInsertAt' : 'item1',
               'artifactId' : 'WorkApproval.CostsView_groupitem_2_Services',
               'id' : 'aw154ab6de',
               'value' : MessageService.createStaticMessage('Services'),
            });
            groupitem063.addChild( text093 );


            var text094 = new Text({
               'resourceAttribute' : 'localestservcost',
               'cssClass' : 'bold textappearance-medium',
               'editable' : false,
               'layoutInsertAt' : 'item2',
               'artifactId' : 'WorkApproval.CostsView_groupitem_2_localestservcost',
               'id' : 'awd56bf433',
            });
            groupitem063.addChild( text094 );


            var container023 = new Container({
               'artifactId' : 'WorkApproval.CostsView_container_4',
               'id' : 'aw88e9a55e',
            });
            view015.addChild( container023 );


            var group021 = new Group({
               'artifactId' : 'WorkApproval.CostsView_group_3',
               'id' : 'awe0c3f616',
            });
            container023.addChild( group021 );


            var groupitem064 = new GroupItem({
               'layout' : 'ViewCostLine',
               'artifactId' : 'WorkApproval.CostsView_groupitem_3',
               'id' : 'aw5356a1ee',
            });
            group021.addChild( groupitem064 );


            var text095 = new Text({
               'cssClass' : 'bold textappearance-medium',
               'editable' : false,
               'layoutInsertAt' : 'item1',
               'artifactId' : 'WorkApproval.CostsView_groupitem_3_Tools',
               'id' : 'aw409611ac',
               'value' : MessageService.createStaticMessage('Tools'),
            });
            groupitem064.addChild( text095 );


            var text096 = new Text({
               'resourceAttribute' : 'localesttoolcost',
               'cssClass' : 'bold textappearance-medium',
               'editable' : false,
               'layoutInsertAt' : 'item2',
               'artifactId' : 'WorkApproval.CostsView_groupitem_3_localesttoolcost',
               'id' : 'aw1948ae3',
            });
            groupitem064.addChild( text096 );


            var container024 = new Container({
               'artifactId' : 'WorkApproval.CostsView_container_5',
               'id' : 'awffee95c8',
            });
            view015.addChild( container024 );


            var group022 = new Group({
               'artifactId' : 'WorkApproval.CostsView_group_4',
               'id' : 'aw7ea763b5',
            });
            container024.addChild( group022 );


            var groupitem065 = new GroupItem({
               'layout' : 'ViewCostLine',
               'artifactId' : 'WorkApproval.CostsView_groupitem_4',
               'id' : 'awcd32344d',
            });
            group022.addChild( groupitem065 );


            var text097 = new Text({
               'cssClass' : 'bold textappearance-large',
               'editable' : false,
               'layoutInsertAt' : 'item1',
               'artifactId' : 'WorkApproval.CostsView_groupitem_4_TotalCost',
               'id' : 'awe146f60e',
               'value' : MessageService.createStaticMessage('Total Cost'),
            });
            groupitem065.addChild( text097 );


            var text098 = new Text({
               'resourceAttribute' : 'localesttotalcost',
               'cssClass' : 'bold textappearance-large',
               'editable' : false,
               'layoutInsertAt' : 'item2',
               'artifactId' : 'WorkApproval.CostsView_groupitem_4_localesttotalcost',
               'id' : 'awbdeac9fb',
            });
            groupitem065.addChild( text098 );

            var eventHandlers037 = [
               {
                     'method' : 'initCostsView',
                     'artifactId' : 'WorkApproval.CostsView_eventHandlers_show_initCostsView',
                     'id' : 'aw9b8cd7c8',
                     'event' : 'show',
                     'class' : 'application.handlers.WODetailsHandler',
               }
            ];
            view015.eventHandlers = eventHandlers037;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'WorkApproval.PlannedMaterialView', false);
               trackTimer.startTracking();
            }

            var view016 = new View({
               'id' : 'WorkApproval.PlannedMaterialView',
               'label' : MessageService.createStaticMessage('Planned Materials'),
            });
            ui001.addChild( view016 );

            var requiredResources016 = {
               'workOrder' : {
                  'artifactId' : 'WorkApproval.PlannedMaterialView_workOrder',
                  'id' : 'awf09dc37f',
                  'related' : {
                     'materiallist' : {
                        'artifactId' : 'WorkApproval.PlannedMaterialView_workOrder_materiallist',
                        'id' : 'aw5db30c26',
                     },
                  },
               },
            };
            view016.addRequiredResources( requiredResources016 );


            var sortOptions005 = new SortOptions({
               'artifactId' : 'WorkApproval.PlannedMaterialView_workOrder_materiallist_list_sortOptions',
               'id' : 'aw5367a26f',
            });

            var sortOption009 = new SortOption({
               'artifactId' : 'WorkApproval.PlannedMaterialView_sortOption_TaskIDItem',
               'id' : 'aw63f186a',
               'label' : MessageService.createStaticMessage('Task ID, Item'),
            });
            sortOptions005.addChild( sortOption009 );


            var sortAttribute010 = new SortAttribute({
               'name' : 'taskid',
               'artifactId' : 'WorkApproval.PlannedMaterialView_TaskIDItem_sortAttribute_taskid',
               'id' : 'aw99bc182f',
               'direction' : 'asc',
            });
            sortOption009.addChild( sortAttribute010 );


            var sortAttribute011 = new SortAttribute({
               'name' : 'itemanddescription',
               'artifactId' : 'WorkApproval.PlannedMaterialView_TaskIDItem_sortAttribute_itemanddescription',
               'id' : 'aw7a33839d',
               'direction' : 'asc',
            });
            sortOption009.addChild( sortAttribute011 );



            var listItemTemplate005 = new ListItemTemplate({
               'layout' : 'PlannedMaterialListItem',
               'artifactId' : 'WorkApproval.PlannedMaterialView_workOrder_materiallist_listItemTemplate_PlannedMaterialListItem',
               'id' : 'aw190125ee',
            });

            var listtext017 = new ListText({
               'resourceAttribute' : 'taskid',
               'layoutInsertAt' : 'item1',
               'artifactId' : 'WorkApproval.PlannedMaterialView_workOrder_PlannedMaterialListItem_taskid',
               'id' : 'aw8aa0aaeb',
            });
            listItemTemplate005.addChild( listtext017 );


            var listtext018 = new ListText({
               'resourceAttribute' : 'itemanddescription',
               'cssClass' : 'bold textappearance-medium',
               'layoutInsertAt' : 'item2',
               'artifactId' : 'WorkApproval.PlannedMaterialView_workOrder_PlannedMaterialListItem_itemanddescription',
               'id' : 'aw86a9b862',
            });
            listItemTemplate005.addChild( listtext018 );


            var listtext019 = new ListText({
               'resourceAttribute' : 'quantity',
               'layoutInsertAt' : 'item3',
               'artifactId' : 'WorkApproval.PlannedMaterialView_workOrder_PlannedMaterialListItem_quantity',
               'id' : 'aw5ffe0bac',
            });
            listItemTemplate005.addChild( listtext019 );


            var listtext020 = new ListText({
               'resourceAttribute' : 'linecost',
               'layoutInsertAt' : 'item4',
               'artifactId' : 'WorkApproval.PlannedMaterialView_workOrder_PlannedMaterialListItem_linecost',
               'id' : 'aw660ba3c6',
            });
            listItemTemplate005.addChild( listtext020 );



            var list005 = new List({
               'resource' : 'workOrder',
               'transitionTo' : 'WorkApproval.PlannedMaterialDetailView',
               'sortOptions' : sortOptions005,
               'listItemTemplate' : listItemTemplate005,
               'artifactId' : 'WorkApproval.PlannedMaterialView_workOrder_materiallist_list',
               'attribute' : 'materiallist',
               'id' : 'awd5b78e4f',
            });
            view016.addChild( list005 );

            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'WorkApproval.PlannedMaterialDetailView', false);
               trackTimer.startTracking();
            }

            var view017 = new View({
               'id' : 'WorkApproval.PlannedMaterialDetailView',
               'label' : MessageService.createStaticMessage('Material Details'),
            });
            ui001.addChild( view017 );

            var requiredResources017 = {
               'workOrder' : {
                  'artifactId' : 'WorkApproval.PlannedMaterialDetailView_workOrder',
                  'id' : 'aw9fa65f2f',
                  'related' : {
                     'materiallist' : {
                        'artifactId' : 'WorkApproval.PlannedMaterialDetailView_workOrder_materiallist',
                        'id' : 'aw164b676f',
                     },
                  },
               },
            };
            view017.addRequiredResources( requiredResources017 );

            var container025 = new Container({
               'resource' : 'workOrder',
               'artifactId' : 'WorkApproval.PlannedMaterialDetailView_workOrder_container_0',
               'attribute' : 'materiallist',
               'id' : 'aw349de94f',
            });
            view017.addChild( container025 );


            var group023 = new Group({
               'artifactId' : 'WorkApproval.PlannedMaterialDetailView_group_0',
               'id' : 'aw2164b427',
            });
            container025.addChild( group023 );


            var groupitem066 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedMaterialDetailView_workOrder_groupitem_0',
               'id' : 'aw7146785c',
            });
            group023.addChild( groupitem066 );


            var text099 = new Text({
               'resourceAttribute' : 'taskid',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedMaterialDetailView_workOrder_groupitem_0_taskid_Task',
               'id' : 'aweca7bdfd',
               'label' : MessageService.createStaticMessage('Task'),
            });
            groupitem066.addChild( text099 );


            var groupitem067 = new GroupItem({
               'transitionTo' : 'WorkApproval.MaterialView',
               'artifactId' : 'WorkApproval.PlannedMaterialDetailView_workOrder_groupitem_WorkApproval.MaterialView_0',
               'id' : 'aw905c7f31',
            });
            group023.addChild( groupitem067 );


            var text100 = new Text({
               'resourceAttribute' : 'itemanddescription',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedMaterialDetailView_workOrder_groupitem_WorkApproval.MaterialView_0_itemanddescription_Item',
               'id' : 'aw2d68981a',
               'label' : MessageService.createStaticMessage('Item'),
            });
            groupitem067.addChild( text100 );


            var groupitem068 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedMaterialDetailView_workOrder_groupitem_1',
               'id' : 'aw64148ca',
            });
            group023.addChild( groupitem068 );


            var text101 = new Text({
               'resourceAttribute' : 'quantity',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedMaterialDetailView_workOrder_groupitem_1_quantity_Quantity',
               'id' : 'awc560485b',
               'label' : MessageService.createStaticMessage('Quantity'),
            });
            groupitem068.addChild( text101 );


            var groupitem069 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedMaterialDetailView_workOrder_groupitem_2',
               'id' : 'aw9f481970',
            });
            group023.addChild( groupitem069 );


            var text102 = new Text({
               'resourceAttribute' : 'unitcost',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedMaterialDetailView_workOrder_groupitem_2_unitcost_UnitCost',
               'id' : 'aw5753d06f',
               'label' : MessageService.createStaticMessage('Unit Cost'),
            });
            groupitem069.addChild( text102 );


            var groupitem070 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedMaterialDetailView_workOrder_groupitem_3',
               'id' : 'awe84f29e6',
            });
            group023.addChild( groupitem070 );


            var text103 = new Text({
               'resourceAttribute' : 'linecost',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedMaterialDetailView_workOrder_groupitem_3_linecost_LineCost',
               'id' : 'aw8dc5fde6',
               'label' : MessageService.createStaticMessage('Line Cost'),
            });
            groupitem070.addChild( text103 );


            var groupitem071 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedMaterialDetailView_workOrder_groupitem_4',
               'id' : 'aw762bbc45',
            });
            group023.addChild( groupitem071 );


            var text104 = new Text({
               'resourceAttribute' : 'linetype',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedMaterialDetailView_workOrder_groupitem_4_linetype_LineType',
               'id' : 'aw28dcd131',
               'label' : MessageService.createStaticMessage('Line Type'),
            });
            groupitem071.addChild( text104 );


            var groupitem072 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedMaterialDetailView_workOrder_groupitem_5',
               'id' : 'aw12c8cd3',
            });
            group023.addChild( groupitem072 );


            var text105 = new Text({
               'resourceAttribute' : 'storeroom',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedMaterialDetailView_workOrder_groupitem_5_storeroom_Storeroom',
               'id' : 'aw7f50c0b9',
               'label' : MessageService.createStaticMessage('Storeroom'),
            });
            groupitem072.addChild( text105 );


            var text106 = new Text({
               'resourceAttribute' : 'storeroomdesc',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedMaterialDetailView_workOrder_groupitem_5_storeroomdesc',
               'id' : 'awb8345cf6',
            });
            groupitem072.addChild( text106 );


            var groupitem073 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedMaterialDetailView_workOrder_groupitem_6',
               'id' : 'aw9825dd69',
            });
            group023.addChild( groupitem073 );


            var checkbox001 = new CheckBox({
               'resourceAttribute' : 'directrequest',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedMaterialDetailView_directrequest_checkbox',
               'id' : 'aw7894d22e',
               'label' : MessageService.createStaticMessage('Direct Request'),
            });
            groupitem073.addChild( checkbox001 );


            var group024 = new Group({
               'artifactId' : 'WorkApproval.PlannedMaterialDetailView_group_1',
               'id' : 'aw566384b1',
            });
            container025.addChild( group024 );


            var groupitem074 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedMaterialDetailView_workOrder_groupitem_7',
               'id' : 'awef22edff',
            });
            group024.addChild( groupitem074 );


            var lastupdatetext004 = new LastUpdateText({
               'artifactId' : 'WorkApproval.PlannedMaterialDetailView_lastupdatetext',
               'id' : 'aw701aedf7',
            });
            groupitem074.addChild( lastupdatetext004 );

            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'WorkApproval.PlannedToolsView', false);
               trackTimer.startTracking();
            }

            var view018 = new View({
               'id' : 'WorkApproval.PlannedToolsView',
               'label' : MessageService.createStaticMessage('Planned Tools'),
            });
            ui001.addChild( view018 );

            var requiredResources018 = {
               'workOrder' : {
                  'artifactId' : 'WorkApproval.PlannedToolsView_workOrder',
                  'id' : 'awb9dc9851',
                  'related' : {
                     'toollist' : {
                        'artifactId' : 'WorkApproval.PlannedToolsView_workOrder_toollist',
                        'id' : 'aw1600e855',
                     },
                  },
               },
            };
            view018.addRequiredResources( requiredResources018 );


            var sortOptions006 = new SortOptions({
               'artifactId' : 'WorkApproval.PlannedToolsView_workOrder_toollist_list_sortOptions',
               'id' : 'aw4818ec63',
            });

            var sortOption010 = new SortOption({
               'artifactId' : 'WorkApproval.PlannedToolsView_sortOption_TaskIDTool',
               'id' : 'aw900188e1',
               'label' : MessageService.createStaticMessage('Task ID, Tool'),
            });
            sortOptions006.addChild( sortOption010 );


            var sortAttribute012 = new SortAttribute({
               'name' : 'taskid',
               'artifactId' : 'WorkApproval.PlannedToolsView_TaskIDTool_sortAttribute_taskid',
               'id' : 'awddf9b8c9',
               'direction' : 'asc',
            });
            sortOption010.addChild( sortAttribute012 );


            var sortAttribute013 = new SortAttribute({
               'name' : 'toolanddescription',
               'artifactId' : 'WorkApproval.PlannedToolsView_TaskIDTool_sortAttribute_toolanddescription',
               'id' : 'awe5907e62',
               'direction' : 'asc',
            });
            sortOption010.addChild( sortAttribute013 );



            var listItemTemplate006 = new ListItemTemplate({
               'layout' : 'PlannedToolListItem',
               'artifactId' : 'WorkApproval.PlannedToolsView_workOrder_toollist_listItemTemplate_PlannedToolListItem',
               'id' : 'awb15ddd67',
            });

            var listtext021 = new ListText({
               'resourceAttribute' : 'taskid',
               'layoutInsertAt' : 'item1',
               'artifactId' : 'WorkApproval.PlannedToolsView_workOrder_PlannedToolListItem_taskid',
               'id' : 'awe517733f',
            });
            listItemTemplate006.addChild( listtext021 );


            var listtext022 = new ListText({
               'resourceAttribute' : 'toolanddescription',
               'cssClass' : 'bold textappearance-medium',
               'layoutInsertAt' : 'item2',
               'artifactId' : 'WorkApproval.PlannedToolsView_workOrder_PlannedToolListItem_toolanddescription',
               'id' : 'aw706ac1aa',
            });
            listItemTemplate006.addChild( listtext022 );


            var listtext023 = new ListText({
               'resourceAttribute' : 'quantity',
               'layoutInsertAt' : 'item3',
               'artifactId' : 'WorkApproval.PlannedToolsView_workOrder_PlannedToolListItem_quantity',
               'id' : 'aw45a50e70',
            });
            listItemTemplate006.addChild( listtext023 );


            var listtext024 = new ListText({
               'resourceAttribute' : 'linecost',
               'layoutInsertAt' : 'item4',
               'artifactId' : 'WorkApproval.PlannedToolsView_workOrder_PlannedToolListItem_linecost',
               'id' : 'aw7c50a61a',
            });
            listItemTemplate006.addChild( listtext024 );



            var list006 = new List({
               'resource' : 'workOrder',
               'transitionTo' : 'WorkApproval.PlannedToolsDetailView',
               'sortOptions' : sortOptions006,
               'listItemTemplate' : listItemTemplate006,
               'artifactId' : 'WorkApproval.PlannedToolsView_workOrder_toollist_list',
               'attribute' : 'toollist',
               'id' : 'awe64d14b8',
            });
            view018.addChild( list006 );

            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'WorkApproval.PlannedToolsDetailView', false);
               trackTimer.startTracking();
            }

            var view019 = new View({
               'id' : 'WorkApproval.PlannedToolsDetailView',
               'label' : MessageService.createStaticMessage('Tool Details'),
            });
            ui001.addChild( view019 );

            var requiredResources019 = {
               'workOrder' : {
                  'artifactId' : 'WorkApproval.PlannedToolsDetailView_workOrder',
                  'id' : 'awb1204ca4',
                  'related' : {
                     'toollist' : {
                        'artifactId' : 'WorkApproval.PlannedToolsDetailView_workOrder_toollist',
                        'id' : 'aw7bbc4a6',
                     },
                  },
               },
            };
            view019.addRequiredResources( requiredResources019 );

            var container026 = new Container({
               'resource' : 'workOrder',
               'artifactId' : 'WorkApproval.PlannedToolsDetailView_workOrder_container_0',
               'attribute' : 'toollist',
               'id' : 'awb3f4a01c',
            });
            view019.addChild( container026 );


            var group025 = new Group({
               'artifactId' : 'WorkApproval.PlannedToolsDetailView_group_0',
               'id' : 'awe7022a0b',
            });
            container026.addChild( group025 );


            var groupitem075 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedToolsDetailView_workOrder_groupitem_0',
               'id' : 'awf62f310f',
            });
            group025.addChild( groupitem075 );


            var text107 = new Text({
               'resourceAttribute' : 'taskid',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedToolsDetailView_workOrder_groupitem_0_taskid_Task',
               'id' : 'aw25815057',
               'label' : MessageService.createStaticMessage('Task'),
            });
            groupitem075.addChild( text107 );


            var groupitem076 = new GroupItem({
               'transitionTo' : 'WorkApproval.ToolView',
               'artifactId' : 'WorkApproval.PlannedToolsDetailView_workOrder_groupitem_WorkApproval.ToolView_0',
               'id' : 'aw2f0a2931',
            });
            group025.addChild( groupitem076 );


            var text108 = new Text({
               'resourceAttribute' : 'toolanddescription',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedToolsDetailView_workOrder_groupitem_WorkApproval.ToolView_0_toolanddescription_Tool',
               'id' : 'aw5f49040d',
               'label' : MessageService.createStaticMessage('Tool'),
            });
            groupitem076.addChild( text108 );


            var groupitem077 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedToolsDetailView_workOrder_groupitem_1',
               'id' : 'aw81280199',
            });
            group025.addChild( groupitem077 );


            var text109 = new Text({
               'resourceAttribute' : 'quantity',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedToolsDetailView_workOrder_groupitem_1_quantity_Quantity',
               'id' : 'awb6842490',
               'label' : MessageService.createStaticMessage('Quantity'),
            });
            groupitem077.addChild( text109 );


            var groupitem078 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedToolsDetailView_workOrder_groupitem_2',
               'id' : 'aw18215023',
            });
            group025.addChild( groupitem078 );


            var text110 = new Text({
               'resourceAttribute' : 'rate',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedToolsDetailView_workOrder_groupitem_2_rate_Rate',
               'id' : 'aw7a93cad1',
               'label' : MessageService.createStaticMessage('Rate'),
            });
            groupitem078.addChild( text110 );


            var groupitem079 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedToolsDetailView_workOrder_groupitem_3',
               'id' : 'aw6f2660b5',
            });
            group025.addChild( groupitem079 );


            var text111 = new Text({
               'resourceAttribute' : 'hours',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedToolsDetailView_workOrder_groupitem_3_hours_Hours',
               'id' : 'aw7b21abcb',
               'label' : MessageService.createStaticMessage('Hours'),
            });
            groupitem079.addChild( text111 );


            var groupitem080 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedToolsDetailView_workOrder_groupitem_4',
               'id' : 'awf142f516',
            });
            group025.addChild( groupitem080 );


            var text112 = new Text({
               'resourceAttribute' : 'linecost',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedToolsDetailView_workOrder_groupitem_4_linecost_LineCost',
               'id' : 'awb41f1a66',
               'label' : MessageService.createStaticMessage('Line Cost'),
            });
            groupitem080.addChild( text112 );


            var groupitem081 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedToolsDetailView_workOrder_groupitem_5',
               'id' : 'aw8645c580',
            });
            group025.addChild( groupitem081 );


            var text113 = new Text({
               'resourceAttribute' : 'storeroom',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedToolsDetailView_workOrder_groupitem_5_storeroom_Storeroom',
               'id' : 'aw135a90ab',
               'label' : MessageService.createStaticMessage('Storeroom'),
            });
            groupitem081.addChild( text113 );


            var text114 = new Text({
               'resourceAttribute' : 'storeroomdesc',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedToolsDetailView_workOrder_groupitem_5_storeroomdesc',
               'id' : 'aw32675f76',
            });
            groupitem081.addChild( text114 );


            var group026 = new Group({
               'artifactId' : 'WorkApproval.PlannedToolsDetailView_group_1',
               'id' : 'aw90051a9d',
            });
            container026.addChild( group026 );


            var groupitem082 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedToolsDetailView_workOrder_groupitem_6',
               'id' : 'aw1f4c943a',
            });
            group026.addChild( groupitem082 );


            var lastupdatetext005 = new LastUpdateText({
               'artifactId' : 'WorkApproval.PlannedToolsDetailView_lastupdatetext',
               'id' : 'aw1a3ffa1b',
            });
            groupitem082.addChild( lastupdatetext005 );

            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'WorkApproval.PlannedServicesView', false);
               trackTimer.startTracking();
            }

            var view020 = new View({
               'id' : 'WorkApproval.PlannedServicesView',
               'label' : MessageService.createStaticMessage('Planned Services'),
            });
            ui001.addChild( view020 );

            var requiredResources020 = {
               'workOrder' : {
                  'artifactId' : 'WorkApproval.PlannedServicesView_workOrder',
                  'id' : 'aw91953109',
                  'related' : {
                     'servicelist' : {
                        'artifactId' : 'WorkApproval.PlannedServicesView_workOrder_servicelist',
                        'id' : 'awfb6f9bf6',
                     },
                  },
               },
            };
            view020.addRequiredResources( requiredResources020 );


            var sortOptions007 = new SortOptions({
               'artifactId' : 'WorkApproval.PlannedServicesView_workOrder_servicelist_list_sortOptions',
               'id' : 'awd7e1dff0',
            });

            var sortOption011 = new SortOption({
               'artifactId' : 'WorkApproval.PlannedServicesView_sortOption_TaskIDService',
               'id' : 'awa1ae9376',
               'label' : MessageService.createStaticMessage('Task ID, Service'),
            });
            sortOptions007.addChild( sortOption011 );


            var sortAttribute014 = new SortAttribute({
               'name' : 'taskid',
               'artifactId' : 'WorkApproval.PlannedServicesView_TaskIDService_sortAttribute_taskid',
               'id' : 'aw588d50bb',
               'direction' : 'asc',
            });
            sortOption011.addChild( sortAttribute014 );


            var sortAttribute015 = new SortAttribute({
               'name' : 'serviceanddescription',
               'artifactId' : 'WorkApproval.PlannedServicesView_TaskIDService_sortAttribute_serviceanddescription',
               'id' : 'aw186d35ce',
               'direction' : 'asc',
            });
            sortOption011.addChild( sortAttribute015 );



            var listItemTemplate007 = new ListItemTemplate({
               'layout' : 'PlannedServiceListItem',
               'artifactId' : 'WorkApproval.PlannedServicesView_workOrder_servicelist_listItemTemplate_PlannedServiceListItem',
               'id' : 'aw4d48874b',
            });

            var listtext025 = new ListText({
               'resourceAttribute' : 'taskid',
               'layoutInsertAt' : 'item1',
               'artifactId' : 'WorkApproval.PlannedServicesView_workOrder_PlannedServiceListItem_taskid',
               'id' : 'awb89b2638',
            });
            listItemTemplate007.addChild( listtext025 );


            var listtext026 = new ListText({
               'resourceAttribute' : 'serviceanddescription',
               'layoutInsertAt' : 'item2',
               'artifactId' : 'WorkApproval.PlannedServicesView_workOrder_PlannedServiceListItem_serviceanddescription',
               'id' : 'aw94d2d10',
            });
            listItemTemplate007.addChild( listtext026 );


            var listtext027 = new ListText({
               'resourceAttribute' : 'quantity',
               'layoutInsertAt' : 'item3',
               'artifactId' : 'WorkApproval.PlannedServicesView_workOrder_PlannedServiceListItem_quantity',
               'id' : 'aw11e56040',
            });
            listItemTemplate007.addChild( listtext027 );


            var listtext028 = new ListText({
               'resourceAttribute' : 'linecost',
               'layoutInsertAt' : 'item4',
               'artifactId' : 'WorkApproval.PlannedServicesView_workOrder_PlannedServiceListItem_linecost',
               'id' : 'aw2810c82a',
            });
            listItemTemplate007.addChild( listtext028 );



            var list007 = new List({
               'resource' : 'workOrder',
               'transitionTo' : 'WorkApproval.PlannedServicesDetailView',
               'sortOptions' : sortOptions007,
               'listItemTemplate' : listItemTemplate007,
               'artifactId' : 'WorkApproval.PlannedServicesView_workOrder_servicelist_list',
               'attribute' : 'servicelist',
               'id' : 'aw1bff30',
            });
            view020.addChild( list007 );

            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'WorkApproval.PlannedServicesDetailView', false);
               trackTimer.startTracking();
            }

            var view021 = new View({
               'id' : 'WorkApproval.PlannedServicesDetailView',
               'label' : MessageService.createStaticMessage('Service Details'),
            });
            ui001.addChild( view021 );

            var requiredResources021 = {
               'workOrder' : {
                  'artifactId' : 'WorkApproval.PlannedServicesDetailView_workOrder',
                  'id' : 'awfc883b36',
                  'related' : {
                     'servicelist' : {
                        'artifactId' : 'WorkApproval.PlannedServicesDetailView_workOrder_servicelist',
                        'id' : 'aw106ac',
                     },
                  },
               },
            };
            view021.addRequiredResources( requiredResources021 );

            var container027 = new Container({
               'resource' : 'workOrder',
               'artifactId' : 'WorkApproval.PlannedServicesDetailView_workOrder_container_0',
               'attribute' : 'servicelist',
               'id' : 'aw715b559a',
            });
            view021.addChild( container027 );


            var group027 = new Group({
               'artifactId' : 'WorkApproval.PlannedServicesDetailView_group_0',
               'id' : 'aw2b1c371f',
            });
            container027.addChild( group027 );


            var groupitem083 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedServicesDetailView_workOrder_groupitem_0',
               'id' : 'aw3480c489',
            });
            group027.addChild( groupitem083 );


            var text115 = new Text({
               'resourceAttribute' : 'taskid',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedServicesDetailView_workOrder_groupitem_0_taskid_Task',
               'id' : 'aw9c8d2beb',
               'label' : MessageService.createStaticMessage('Task'),
            });
            groupitem083.addChild( text115 );


            var groupitem084 = new GroupItem({
               'transitionTo' : 'WorkApproval.ServiceView',
               'artifactId' : 'WorkApproval.PlannedServicesDetailView_workOrder_groupitem_WorkApproval.ServiceView_0',
               'id' : 'aw981748ba',
            });
            group027.addChild( groupitem084 );


            var text116 = new Text({
               'resourceAttribute' : 'serviceanddescription',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedServicesDetailView_workOrder_groupitem_WorkApproval.ServiceView_0_serviceanddescription_Service',
               'id' : 'aw51742f5e',
               'label' : MessageService.createStaticMessage('Service'),
            });
            groupitem084.addChild( text116 );


            var groupitem085 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedServicesDetailView_workOrder_groupitem_1',
               'id' : 'aw4387f41f',
            });
            group027.addChild( groupitem085 );


            var text117 = new Text({
               'resourceAttribute' : 'quantity',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedServicesDetailView_workOrder_groupitem_1_quantity_Quantity',
               'id' : 'awd5d75c67',
               'label' : MessageService.createStaticMessage('Quantity'),
            });
            groupitem085.addChild( text117 );


            var groupitem086 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedServicesDetailView_workOrder_groupitem_2',
               'id' : 'awda8ea5a5',
            });
            group027.addChild( groupitem086 );


            var text118 = new Text({
               'resourceAttribute' : 'unitcost',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedServicesDetailView_workOrder_groupitem_2_unitcost_UnitCost',
               'id' : 'aw47e4c453',
               'label' : MessageService.createStaticMessage('Unit Cost'),
            });
            groupitem086.addChild( text118 );


            var groupitem087 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedServicesDetailView_workOrder_groupitem_3',
               'id' : 'awad899533',
            });
            group027.addChild( groupitem087 );


            var text119 = new Text({
               'resourceAttribute' : 'linecost',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedServicesDetailView_workOrder_groupitem_3_linecost_LineCost',
               'id' : 'aw9d72e9da',
               'label' : MessageService.createStaticMessage('Line Cost'),
            });
            groupitem087.addChild( text119 );


            var groupitem088 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedServicesDetailView_workOrder_groupitem_4',
               'id' : 'aw33ed0090',
            });
            group027.addChild( groupitem088 );


            var text120 = new Text({
               'resourceAttribute' : 'vendor',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedServicesDetailView_workOrder_groupitem_4_vendor_Vendor',
               'id' : 'awa9678de9',
               'label' : MessageService.createStaticMessage('Vendor'),
            });
            groupitem088.addChild( text120 );


            var groupitem089 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedServicesDetailView_workOrder_groupitem_5',
               'id' : 'aw44ea3006',
            });
            group027.addChild( groupitem089 );


            var text121 = new Text({
               'resourceAttribute' : 'linetype',
               'editable' : false,
               'artifactId' : 'WorkApproval.PlannedServicesDetailView_workOrder_groupitem_5_linetype_LineType',
               'id' : 'awef894555',
               'label' : MessageService.createStaticMessage('Line Type'),
            });
            groupitem089.addChild( text121 );


            var group028 = new Group({
               'artifactId' : 'WorkApproval.PlannedServicesDetailView_group_1',
               'id' : 'aw5c1b0789',
            });
            container027.addChild( group028 );


            var groupitem090 = new GroupItem({
               'artifactId' : 'WorkApproval.PlannedServicesDetailView_workOrder_groupitem_6',
               'id' : 'awdde361bc',
            });
            group028.addChild( groupitem090 );


            var lastupdatetext006 = new LastUpdateText({
               'artifactId' : 'WorkApproval.PlannedServicesDetailView_lastupdatetext',
               'id' : 'awd5ad2bde',
            });
            groupitem090.addChild( lastupdatetext006 );

            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'WorkApproval.MaterialView', false);
               trackTimer.startTracking();
            }

            var view022 = new View({
               'id' : 'WorkApproval.MaterialView',
               'label' : MessageService.createStaticMessage('Material'),
            });
            ui001.addChild( view022 );

            var requiredResources022 = {
               'workOrder' : {
                  'artifactId' : 'WorkApproval.MaterialView_workOrder',
                  'id' : 'aw5aba452c',
                  'related' : {
                     'materiallist' : {
                        'artifactId' : 'WorkApproval.MaterialView_workOrder_materiallist',
                        'id' : 'aw77d49dd5',
                     },
                  },
               },
            };
            view022.addRequiredResources( requiredResources022 );

            var container028 = new Container({
               'resource' : 'workOrder',
               'artifactId' : 'WorkApproval.MaterialView_workOrder_container_0',
               'attribute' : 'materiallist',
               'id' : 'awc0988091',
            });
            view022.addChild( container028 );


            var group029 = new Group({
               'artifactId' : 'WorkApproval.MaterialView_group_0',
               'id' : 'awbc8e6b82',
            });
            container028.addChild( group029 );


            var groupitem091 = new GroupItem({
               'artifactId' : 'WorkApproval.MaterialView_workOrder_groupitem_0',
               'id' : 'aw85431182',
            });
            group029.addChild( groupitem091 );


            var text122 = new Text({
               'resourceAttribute' : 'item',
               'editable' : false,
               'artifactId' : 'WorkApproval.MaterialView_workOrder_groupitem_0_item',
               'id' : 'aw5595d99a',
            });
            groupitem091.addChild( text122 );


            var text123 = new Text({
               'resourceAttribute' : 'itemdesc',
               'editable' : false,
               'artifactId' : 'WorkApproval.MaterialView_workOrder_groupitem_0_itemdesc',
               'id' : 'aw4c27780f',
            });
            groupitem091.addChild( text123 );


            var groupitem092 = new GroupItem({
               'artifactId' : 'WorkApproval.MaterialView_workOrder_groupitem_1',
               'id' : 'awf2442114',
            });
            group029.addChild( groupitem092 );


            var text124 = new Text({
               'resourceAttribute' : 'itemlongdesc',
               'cssClass' : 'richText',
               'editable' : false,
               'artifactId' : 'WorkApproval.MaterialView_workOrder_groupitem_1_itemlongdesc',
               'id' : 'awcc9283c',
            });
            groupitem092.addChild( text124 );

            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'WorkApproval.ToolView', false);
               trackTimer.startTracking();
            }

            var view023 = new View({
               'id' : 'WorkApproval.ToolView',
               'label' : MessageService.createStaticMessage('Tool'),
            });
            ui001.addChild( view023 );

            var requiredResources023 = {
               'workOrder' : {
                  'artifactId' : 'WorkApproval.ToolView_workOrder',
                  'id' : 'awaf90ddcf',
                  'related' : {
                     'toollist' : {
                        'artifactId' : 'WorkApproval.ToolView_workOrder_toollist',
                        'id' : 'aw230e43fb',
                     },
                  },
               },
            };
            view023.addRequiredResources( requiredResources023 );

            var container029 = new Container({
               'resource' : 'workOrder',
               'artifactId' : 'WorkApproval.ToolView_workOrder_container_0',
               'attribute' : 'toollist',
               'id' : 'aw18595454',
            });
            view023.addChild( container029 );


            var group030 = new Group({
               'artifactId' : 'WorkApproval.ToolView_group_0',
               'id' : 'aw8fe89c30',
            });
            container029.addChild( group030 );


            var groupitem093 = new GroupItem({
               'artifactId' : 'WorkApproval.ToolView_workOrder_groupitem_0',
               'id' : 'aw5d82c547',
            });
            group030.addChild( groupitem093 );


            var text125 = new Text({
               'resourceAttribute' : 'tool',
               'editable' : false,
               'artifactId' : 'WorkApproval.ToolView_workOrder_groupitem_0_tool',
               'id' : 'aw3b323850',
            });
            groupitem093.addChild( text125 );


            var text126 = new Text({
               'resourceAttribute' : 'tooldesc',
               'editable' : false,
               'artifactId' : 'WorkApproval.ToolView_workOrder_groupitem_0_tooldesc',
               'id' : 'awb6bbaa8b',
            });
            groupitem093.addChild( text126 );


            var groupitem094 = new GroupItem({
               'artifactId' : 'WorkApproval.ToolView_workOrder_groupitem_1',
               'id' : 'aw2a85f5d1',
            });
            group030.addChild( groupitem094 );


            var text127 = new Text({
               'resourceAttribute' : 'toollongdesc',
               'cssClass' : 'richText',
               'editable' : false,
               'artifactId' : 'WorkApproval.ToolView_workOrder_groupitem_1_toollongdesc',
               'id' : 'aw6063361a',
            });
            groupitem094.addChild( text127 );

            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'WorkApproval.ServiceView', false);
               trackTimer.startTracking();
            }

            var view024 = new View({
               'id' : 'WorkApproval.ServiceView',
               'label' : MessageService.createStaticMessage('Service'),
            });
            ui001.addChild( view024 );

            var requiredResources024 = {
               'workOrder' : {
                  'artifactId' : 'WorkApproval.ServiceView_workOrder',
                  'id' : 'aw15edd9f0',
                  'related' : {
                     'servicelist' : {
                        'artifactId' : 'WorkApproval.ServiceView_workOrder_servicelist',
                        'id' : 'aw619a99be',
                     },
                  },
               },
            };
            view024.addRequiredResources( requiredResources024 );

            var container030 = new Container({
               'resource' : 'workOrder',
               'artifactId' : 'WorkApproval.ServiceView_workOrder_container_0',
               'attribute' : 'servicelist',
               'id' : 'aw10c0ca88',
            });
            view024.addChild( container030 );


            var group031 = new Group({
               'artifactId' : 'WorkApproval.ServiceView_group_0',
               'id' : 'awda5a2e5a',
            });
            container030.addChild( group031 );


            var groupitem095 = new GroupItem({
               'artifactId' : 'WorkApproval.ServiceView_workOrder_groupitem_0',
               'id' : 'aw551b5b9b',
            });
            group031.addChild( groupitem095 );


            var text128 = new Text({
               'resourceAttribute' : 'service',
               'editable' : false,
               'artifactId' : 'WorkApproval.ServiceView_workOrder_groupitem_0_service',
               'id' : 'aw5f0fdca6',
            });
            groupitem095.addChild( text128 );


            var text129 = new Text({
               'resourceAttribute' : 'servicedesc',
               'editable' : false,
               'artifactId' : 'WorkApproval.ServiceView_workOrder_groupitem_0_servicedesc',
               'id' : 'aw9b6a7673',
            });
            groupitem095.addChild( text129 );


            var groupitem096 = new GroupItem({
               'artifactId' : 'WorkApproval.ServiceView_workOrder_groupitem_1',
               'id' : 'aw221c6b0d',
            });
            group031.addChild( groupitem096 );


            var text130 = new Text({
               'resourceAttribute' : 'serviceld',
               'cssClass' : 'richText',
               'editable' : false,
               'artifactId' : 'WorkApproval.ServiceView_workOrder_groupitem_1_serviceld',
               'id' : 'aw74f8964a',
            });
            groupitem096.addChild( text130 );

            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'WorkApproval.WorkLogView', false);
               trackTimer.startTracking();
            }

            var view025 = new View({
               'id' : 'WorkApproval.WorkLogView',
               'label' : MessageService.createStaticMessage('Work Log'),
            });
            ui001.addChild( view025 );

            var requiredResources025 = {
               'workOrder' : {
                  'artifactId' : 'WorkApproval.WorkLogView_workOrder',
                  'id' : 'aw58a052a9',
                  'related' : {
                     'workloglist' : {
                        'artifactId' : 'WorkApproval.WorkLogView_workOrder_workloglist',
                        'id' : 'awcf6e58b5',
                     },
                  },
               },
            };
            view025.addRequiredResources( requiredResources025 );

            var actions003 = new Actions({
               'artifactId' : 'WorkApproval.WorkLogView_actions',
               'id' : 'awa76667e6',
            });
            view025.addChild( actions003 );


            var action007 = new Action({
               'image' : 'header_add_OFF.svg',
               'transitionTo' : 'WorkApproval.NewWorkLogView',
               'artifactId' : 'WorkApproval.WorkLogView_CreateWorkLogEntry_action',
               'id' : 'awae893eb9',
               'label' : MessageService.createStaticMessage('Create Work Log Entry'),
            });
            actions003.addChild( action007 );

            var eventHandlers038 = [
               {
                     'method' : 'enableAddWorkLogButton',
                     'artifactId' : 'WorkApproval.WorkLogView_CreateWorkLogEntry_action_eventHandlers_datachange_enableAddWorkLogButton',
                     'id' : 'aw2eeeb72d',
                     'event' : 'datachange',
                     'class' : 'application.handlers.WorkLogHandler',
               }
            ];
            action007.eventHandlers = eventHandlers038;


            var sortOptions008 = new SortOptions({
               'artifactId' : 'WorkApproval.WorkLogView_workOrder_workloglist_list_sortOptions',
               'id' : 'aw89f75e3b',
            });

            var sortOption012 = new SortOption({
               'artifactId' : 'WorkApproval.WorkLogView_sortOption_CreatedDate',
               'id' : 'awb0cc4eb3',
               'label' : MessageService.createStaticMessage('Created Date'),
            });
            sortOptions008.addChild( sortOption012 );


            var sortAttribute016 = new SortAttribute({
               'name' : 'createdate',
               'artifactId' : 'WorkApproval.WorkLogView_CreatedDate_sortAttribute_createdate',
               'id' : 'awf943ebb9',
               'direction' : 'asc',
            });
            sortOption012.addChild( sortAttribute016 );


            var sortOption013 = new SortOption({
               'artifactId' : 'WorkApproval.WorkLogView_sortOption_CreatedBy',
               'id' : 'aw9a25209a',
               'label' : MessageService.createStaticMessage('Created By'),
            });
            sortOptions008.addChild( sortOption013 );


            var sortAttribute017 = new SortAttribute({
               'name' : 'createby',
               'artifactId' : 'WorkApproval.WorkLogView_CreatedBy_sortAttribute_createby',
               'id' : 'aw9852f471',
               'direction' : 'asc',
            });
            sortOption013.addChild( sortAttribute017 );



            var listItemTemplate008 = new ListItemTemplate({
               'layout' : 'WorkLogListItem',
               'artifactId' : 'WorkApproval.WorkLogView_workOrder_workloglist_listItemTemplate_WorkLogListItem',
               'id' : 'awe3eacf02',
            });

            var listtext029 = new ListText({
               'resourceAttribute' : 'createdate',
               'layoutInsertAt' : 'item1',
               'artifactId' : 'WorkApproval.WorkLogView_workOrder_WorkLogListItem_createdate',
               'id' : 'aw9f146363',
            });
            listItemTemplate008.addChild( listtext029 );


            var listtext030 = new ListText({
               'resourceAttribute' : 'createby',
               'layoutInsertAt' : 'item2',
               'artifactId' : 'WorkApproval.WorkLogView_workOrder_WorkLogListItem_createby',
               'id' : 'aw762e27e4',
            });
            listItemTemplate008.addChild( listtext030 );


            var listtext031 = new ListText({
               'resourceAttribute' : 'summary',
               'cssClass' : 'bold textappearance-medium',
               'layoutInsertAt' : 'item3',
               'artifactId' : 'WorkApproval.WorkLogView_workOrder_WorkLogListItem_summary',
               'id' : 'aw687a70f1',
            });
            listItemTemplate008.addChild( listtext031 );



            var list008 = new List({
               'resource' : 'workOrder',
               'transitionTo' : 'WorkApproval.WorkLogDetailView',
               'sortOptions' : sortOptions008,
               'listItemTemplate' : listItemTemplate008,
               'artifactId' : 'WorkApproval.WorkLogView_workOrder_workloglist_list',
               'attribute' : 'workloglist',
               'id' : 'awc1580581',
            });
            view025.addChild( list008 );

            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'WorkApproval.WorkLogDetailView', false);
               trackTimer.startTracking();
            }

            var view026 = new View({
               'id' : 'WorkApproval.WorkLogDetailView',
               'label' : MessageService.createStaticMessage('Work Log Entry'),
               'editableView' : 'WorkApproval.NewWorkLogView',
            });
            ui001.addChild( view026 );

            var requiredResources026 = {
               'workOrder' : {
                  'artifactId' : 'WorkApproval.WorkLogDetailView_workOrder',
                  'id' : 'aw628d8219',
                  'related' : {
                     'workloglist' : {
                        'artifactId' : 'WorkApproval.WorkLogDetailView_workOrder_workloglist',
                        'id' : 'awb5632bc6',
                     },
                  },
               },
            };
            view026.addRequiredResources( requiredResources026 );

            var container031 = new Container({
               'resource' : 'workOrder',
               'artifactId' : 'WorkApproval.WorkLogDetailView_workOrder_container_0',
               'attribute' : 'workloglist',
               'id' : 'awdb4603fd',
            });
            view026.addChild( container031 );


            var group032 = new Group({
               'artifactId' : 'WorkApproval.WorkLogDetailView_group_0',
               'id' : 'aw6c6fe3c1',
            });
            container031.addChild( group032 );


            var groupitem097 = new GroupItem({
               'artifactId' : 'WorkApproval.WorkLogDetailView_workOrder_groupitem_0',
               'id' : 'aw9e9d92ee',
            });
            group032.addChild( groupitem097 );


            var text131 = new Text({
               'resourceAttribute' : 'createdate',
               'editable' : false,
               'artifactId' : 'WorkApproval.WorkLogDetailView_workOrder_groupitem_0_createdate',
               'id' : 'aw2af8a9f3',
            });
            groupitem097.addChild( text131 );


            var groupitem098 = new GroupItem({
               'artifactId' : 'WorkApproval.WorkLogDetailView_workOrder_groupitem_1',
               'id' : 'awe99aa278',
            });
            group032.addChild( groupitem098 );


            var text132 = new Text({
               'resourceAttribute' : 'createby',
               'editable' : false,
               'artifactId' : 'WorkApproval.WorkLogDetailView_workOrder_groupitem_1_createby_CreatedBy',
               'id' : 'aw3ccda107',
               'label' : MessageService.createStaticMessage('Created By'),
            });
            groupitem098.addChild( text132 );


            var groupitem099 = new GroupItem({
               'artifactId' : 'WorkApproval.WorkLogDetailView_workOrder_groupitem_2',
               'id' : 'aw7093f3c2',
            });
            group032.addChild( groupitem099 );


            var checkbox002 = new CheckBox({
               'resourceAttribute' : 'clientviewable',
               'editable' : false,
               'artifactId' : 'WorkApproval.WorkLogDetailView_clientviewable_checkbox',
               'id' : 'aw7c35490e',
               'label' : MessageService.createStaticMessage('Display to Client'),
            });
            groupitem099.addChild( checkbox002 );


            var groupitem100 = new GroupItem({
               'artifactId' : 'WorkApproval.WorkLogDetailView_workOrder_groupitem_3',
               'id' : 'aw794c354',
            });
            group032.addChild( groupitem100 );


            var text133 = new Text({
               'resourceAttribute' : 'logtype',
               'editable' : false,
               'artifactId' : 'WorkApproval.WorkLogDetailView_workOrder_groupitem_3_logtype_Type',
               'id' : 'aw84301fa1',
               'label' : MessageService.createStaticMessage('Type'),
            });
            groupitem100.addChild( text133 );


            var groupitem101 = new GroupItem({
               'artifactId' : 'WorkApproval.WorkLogDetailView_workOrder_groupitem_4',
               'id' : 'aw99f056f7',
            });
            group032.addChild( groupitem101 );


            var text134 = new Text({
               'resourceAttribute' : 'summary',
               'editable' : false,
               'artifactId' : 'WorkApproval.WorkLogDetailView_workOrder_groupitem_4_summary_Summary',
               'id' : 'aw2b3b15d2',
               'label' : MessageService.createStaticMessage('Summary'),
            });
            groupitem101.addChild( text134 );


            var groupitem102 = new GroupItem({
               'artifactId' : 'WorkApproval.WorkLogDetailView_workOrder_groupitem_5',
               'id' : 'aweef76661',
            });
            group032.addChild( groupitem102 );


            var text135 = new Text({
               'resourceAttribute' : 'details',
               'cssClass' : 'richText',
               'editable' : false,
               'artifactId' : 'WorkApproval.WorkLogDetailView_workOrder_groupitem_5_details_Details',
               'id' : 'aw89502472',
               'label' : MessageService.createStaticMessage('Details'),
            });
            groupitem102.addChild( text135 );


            var group033 = new Group({
               'artifactId' : 'WorkApproval.WorkLogDetailView_group_1',
               'id' : 'aw1b68d357',
            });
            container031.addChild( group033 );


            var groupitem103 = new GroupItem({
               'artifactId' : 'WorkApproval.WorkLogDetailView_workOrder_groupitem_6',
               'id' : 'aw77fe37db',
            });
            group033.addChild( groupitem103 );


            var lastupdatetext007 = new LastUpdateText({
               'artifactId' : 'WorkApproval.WorkLogDetailView_lastupdatetext',
               'id' : 'aw1f4ff764',
            });
            groupitem103.addChild( lastupdatetext007 );

            var eventHandlers039 = [
               {
                     'method' : 'initWorkLogDetailView',
                     'artifactId' : 'WorkApproval.WorkLogDetailView_eventHandlers_show_initWorkLogDetailView',
                     'id' : 'awfdcacec6',
                     'event' : 'show',
                     'class' : 'application.handlers.WorkLogHandler',
               }
            ];
            view026.eventHandlers = eventHandlers039;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'WorkApproval.NewWorkLogView', false);
               trackTimer.startTracking();
            }

            var view027 = new View({
               'showOverflow' : false,
               'id' : 'WorkApproval.NewWorkLogView',
               'label' : MessageService.createStaticMessage('Work Log Entry'),
            });
            ui001.addChild( view027 );

            var requiredResources027 = {
               'workOrder' : {
                  'artifactId' : 'WorkApproval.NewWorkLogView_workOrder',
                  'id' : 'awdc66c6fa',
                  'related' : {
                     'workloglist' : {
                        'artifactId' : 'WorkApproval.NewWorkLogView_workOrder_workloglist',
                        'id' : 'awa35d7d3a',
                     },
                  },
               },
               'domainlogtype' : {
                  'artifactId' : 'WorkApproval.NewWorkLogView_domainlogtype',
                  'id' : 'aw8f8fd9a8',
               },
            };
            view027.addRequiredResources( requiredResources027 );

            var container032 = new Container({
               'resource' : 'workOrder',
               'artifactId' : 'WorkApproval.NewWorkLogView_workOrder_container_0',
               'attribute' : 'workloglist',
               'id' : 'awcd785501',
            });
            view027.addChild( container032 );


            var group034 = new Group({
               'artifactId' : 'WorkApproval.NewWorkLogView_group_0',
               'id' : 'awed758fcb',
            });
            container032.addChild( group034 );


            var groupitem104 = new GroupItem({
               'artifactId' : 'WorkApproval.NewWorkLogView_workOrder_groupitem_0',
               'id' : 'aw88a3c412',
            });
            group034.addChild( groupitem104 );


            var text136 = new Text({
               'resourceAttribute' : 'createdate',
               'editable' : false,
               'artifactId' : 'WorkApproval.NewWorkLogView_workOrder_groupitem_0_createdate',
               'id' : 'aw410c89bb',
            });
            groupitem104.addChild( text136 );


            var groupitem105 = new GroupItem({
               'artifactId' : 'WorkApproval.NewWorkLogView_workOrder_groupitem_1',
               'id' : 'awffa4f484',
            });
            group034.addChild( groupitem105 );


            var text137 = new Text({
               'resourceAttribute' : 'createby',
               'editable' : false,
               'artifactId' : 'WorkApproval.NewWorkLogView_workOrder_groupitem_1_createby_CreatedBy',
               'id' : 'aw69e95c90',
               'label' : MessageService.createStaticMessage('Created By'),
            });
            groupitem105.addChild( text137 );


            var groupitem106 = new GroupItem({
               'artifactId' : 'WorkApproval.NewWorkLogView_workOrder_groupitem_2',
               'id' : 'aw66ada53e',
            });
            group034.addChild( groupitem106 );


            var checkbox003 = new CheckBox({
               'resourceAttribute' : 'clientviewable',
               'editable' : true,
               'artifactId' : 'WorkApproval.NewWorkLogView_clientviewable_checkbox',
               'id' : 'aw46340540',
               'label' : MessageService.createStaticMessage('Display to Client'),
            });
            groupitem106.addChild( checkbox003 );


            var groupitem107 = new GroupItem({
               'artifactId' : 'WorkApproval.NewWorkLogView_workOrder_groupitem_3',
               'id' : 'aw11aa95a8',
            });
            group034.addChild( groupitem107 );


            var text138 = new Text({
               'resourceAttribute' : 'logtype',
               'lookup' : 'WorkApproval.LogTypeLookup',
               'editable' : true,
               'artifactId' : 'WorkApproval.NewWorkLogView_workOrder_groupitem_3_logtype_Type',
               'id' : 'aw87fe9190',
               'label' : MessageService.createStaticMessage('Type'),
               'lookupAttribute' : 'value',
               'placeHolder' : MessageService.createStaticMessage('Tap to enter'),
               'required' : true,
            });
            groupitem107.addChild( text138 );

            var eventHandlers040 = [
               {
                     'method' : 'validateLogType',
                     'artifactId' : 'WorkApproval.NewWorkLogView_workOrder_groupitem_3_logtype_Type_eventHandlers_validate_validateLogType',
                     'id' : 'awebb0fc1c',
                     'event' : 'validate',
                     'class' : 'application.handlers.WorkLogHandler',
               }
            ];
            text138.eventHandlers = eventHandlers040;

            var groupitem108 = new GroupItem({
               'artifactId' : 'WorkApproval.NewWorkLogView_workOrder_groupitem_4',
               'id' : 'aw8fce000b',
            });
            group034.addChild( groupitem108 );


            var text139 = new Text({
               'resourceAttribute' : 'summary',
               'editable' : true,
               'artifactId' : 'WorkApproval.NewWorkLogView_workOrder_groupitem_4_summary_Summary',
               'id' : 'awd74ec004',
               'label' : MessageService.createStaticMessage('Summary'),
               'placeHolder' : MessageService.createStaticMessage('Tap to enter'),
            });
            groupitem108.addChild( text139 );


            var groupitem109 = new GroupItem({
               'artifactId' : 'WorkApproval.NewWorkLogView_workOrder_groupitem_5',
               'id' : 'awf8c9309d',
            });
            group034.addChild( groupitem109 );


            var textarea001 = new TextArea({
               'resourceAttribute' : 'details',
               'editable' : true,
               'artifactId' : 'WorkApproval.NewWorkLogView_details_0',
               'id' : 'aw40f503e2',
               'label' : MessageService.createStaticMessage('Work Log Details'),
               'placeHolder' : MessageService.createStaticMessage('Tap to enter'),
            });
            groupitem109.addChild( textarea001 );


            var footer003 = new Footer({
               'artifactId' : 'WorkApproval.NewWorkLogView_footer',
               'id' : 'awe2e2cb56',
            });
            view027.addChild( footer003 );


            var button014 = new Button({
               'artifactId' : 'WorkApproval.NewWorkLogView_Cancel_button',
               'id' : 'awfcd029f8',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers041 = [
               {
                     'method' : 'discardNewWorkLogEntry',
                     'artifactId' : 'WorkApproval.NewWorkLogView_Cancel_button_eventHandlers_click_discardNewWorkLogEntry',
                     'id' : 'aw40831412',
                     'event' : 'click',
                     'class' : 'application.handlers.WorkLogHandler',
               }
            ];
            button014.eventHandlers = eventHandlers041;
            footer003.addChild( button014 );


            var button015 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'WorkApproval.NewWorkLogView_Create_button',
               'id' : 'aw4760c94',
               'label' : MessageService.createStaticMessage('Create'),
               'primary' : 'true',
            });
            var eventHandlers042 = [
               {
                     'method' : 'commitWorkLogEntryView',
                     'artifactId' : 'WorkApproval.NewWorkLogView_Create_button_eventHandlers_click_commitWorkLogEntryView',
                     'id' : 'awa15d4f40',
                     'event' : 'click',
                     'class' : 'application.handlers.WorkLogHandler',
               }
            ];
            button015.eventHandlers = eventHandlers042;
            footer003.addChild( button015 );

            var eventHandlers043 = [
               {
                     'method' : 'initNewWorkLogEntry',
                     'artifactId' : 'WorkApproval.NewWorkLogView_eventHandlers_initialize_initNewWorkLogEntry',
                     'id' : 'awfeaf8a6c',
                     'event' : 'initialize',
                     'class' : 'application.handlers.WorkLogHandler',
               },
               {
                     'method' : 'handleBackButtonClick',
                     'artifactId' : 'WorkApproval.NewWorkLogView_eventHandlers_cleanup_handleBackButtonClick',
                     'id' : 'aw8f1735bd',
                     'event' : 'cleanup',
                     'class' : 'application.handlers.WorkLogHandler',
               },
               {
                     'method' : 'showFooter',
                     'artifactId' : 'WorkApproval.NewWorkLogView_eventHandlers_show_showFooter',
                     'id' : 'aw5108682f',
                     'event' : 'show',
                     'class' : 'application.handlers.WorkLogHandler',
               }
            ];
            view027.eventHandlers = eventHandlers043;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'WorkApproval.SearchWorkOrderView', false);
               trackTimer.startTracking();
            }

            var view028 = new View({
               'id' : 'WorkApproval.SearchWorkOrderView',
               'label' : MessageService.createStaticMessage('Search Work Orders'),
            });
            ui001.addChild( view028 );

            var requiredResources028 = {
               'searchWorkOrder' : {
                  'artifactId' : 'WorkApproval.SearchWorkOrderView_searchWorkOrder',
                  'id' : 'aw4481b6d8',
               },
               'workOrder' : {
                  'artifactId' : 'WorkApproval.SearchWorkOrderView_workOrder',
                  'id' : 'aw8f627516',
               },
               'statusChangeResource' : {
                  'artifactId' : 'WorkApproval.SearchWorkOrderView_statusChangeResource',
                  'id' : 'aw87f29f9',
               },
               'domainAssetstatus' : {
                  'artifactId' : 'WorkApproval.SearchWorkOrderView_domainAssetstatus',
                  'id' : 'awb5db99f',
               },
               'domainwoclass' : {
                  'artifactId' : 'WorkApproval.SearchWorkOrderView_domainwoclass',
                  'id' : 'aw8a08a7f5',
               },
            };
            view028.addRequiredResources( requiredResources028 );

            var container033 = new Container({
               'resource' : 'searchWorkOrder',
               'artifactId' : 'WorkApproval.SearchWorkOrderView_searchWorkOrder_container_0',
               'id' : 'aw6323b4bb',
            });
            view028.addChild( container033 );


            var group035 = new Group({
               'artifactId' : 'WorkApproval.SearchWorkOrderView_group_0',
               'id' : 'aw70f546b5',
            });
            container033.addChild( group035 );


            var groupitem110 = new GroupItem({
               'artifactId' : 'WorkApproval.SearchWorkOrderView_searchWorkOrder_groupitem_0',
               'id' : 'aw26f825a8',
            });
            group035.addChild( groupitem110 );


            var text140 = new Text({
               'resourceAttribute' : 'wonum',
               'editable' : true,
               'artifactId' : 'WorkApproval.SearchWorkOrderView_searchWorkOrder_groupitem_0_wonum_WorkOrder',
               'id' : 'aw4804984a',
               'label' : MessageService.createStaticMessage('Work Order'),
               'placeHolder' : MessageService.createStaticMessage('Tap to enter'),
            });
            groupitem110.addChild( text140 );


            var groupitem111 = new GroupItem({
               'artifactId' : 'WorkApproval.SearchWorkOrderView_searchWorkOrder_groupitem_1',
               'id' : 'aw51ff153e',
            });
            group035.addChild( groupitem111 );


            var text141 = new Text({
               'resourceAttribute' : 'description',
               'editable' : true,
               'artifactId' : 'WorkApproval.SearchWorkOrderView_searchWorkOrder_groupitem_1_description_Description',
               'id' : 'aw4d39edce',
               'label' : MessageService.createStaticMessage('Description'),
               'placeHolder' : MessageService.createStaticMessage('Tap to enter'),
            });
            groupitem111.addChild( text141 );


            var groupitem112 = new GroupItem({
               'artifactId' : 'WorkApproval.SearchWorkOrderView_searchWorkOrder_groupitem_2',
               'id' : 'awc8f64484',
            });
            group035.addChild( groupitem112 );


            var text142 = new Text({
               'resourceAttribute' : 'statusdesc',
               'lookup' : 'WorkApproval.statusLookup',
               'editable' : false,
               'artifactId' : 'WorkApproval.SearchWorkOrderView_searchWorkOrder_groupitem_2_statusdesc_Status',
               'id' : 'aw8d323a17',
               'label' : MessageService.createStaticMessage('Status'),
               'placeHolder' : MessageService.createStaticMessage('Tap to select from list'),
            });
            groupitem112.addChild( text142 );


            var groupitem113 = new GroupItem({
               'artifactId' : 'WorkApproval.SearchWorkOrderView_searchWorkOrder_groupitem_3',
               'id' : 'awbff17412',
            });
            group035.addChild( groupitem113 );


            var text143 = new Text({
               'resourceAttribute' : 'asset',
               'lookup' : 'WorkApproval.AssetLookup',
               'editable' : true,
               'artifactId' : 'WorkApproval.SearchWorkOrderView_searchWorkOrder_groupitem_3_asset_Asset',
               'id' : 'awce035318',
               'label' : MessageService.createStaticMessage('Asset'),
               'lookupAttribute' : 'assetnum',
               'placeHolder' : MessageService.createStaticMessage('Tap to enter'),
            });
            groupitem113.addChild( text143 );


            var groupitem114 = new GroupItem({
               'artifactId' : 'WorkApproval.SearchWorkOrderView_searchWorkOrder_groupitem_4',
               'id' : 'aw2195e1b1',
            });
            group035.addChild( groupitem114 );


            var text144 = new Text({
               'resourceAttribute' : 'location',
               'lookup' : 'WorkApproval.LocationLookup',
               'editable' : true,
               'artifactId' : 'WorkApproval.SearchWorkOrderView_searchWorkOrder_groupitem_4_location_Location',
               'id' : 'aw37b67778',
               'label' : MessageService.createStaticMessage('Location'),
               'lookupAttribute' : 'location',
               'placeHolder' : MessageService.createStaticMessage('Tap to enter'),
            });
            groupitem114.addChild( text144 );


            var groupitem115 = new GroupItem({
               'artifactId' : 'WorkApproval.SearchWorkOrderView_searchWorkOrder_groupitem_5',
               'id' : 'aw5692d127',
            });
            group035.addChild( groupitem115 );


            var text145 = new Text({
               'resourceAttribute' : 'priority',
               'editable' : true,
               'artifactId' : 'WorkApproval.SearchWorkOrderView_searchWorkOrder_groupitem_5_priority_Priority',
               'id' : 'awf59c0172',
               'label' : MessageService.createStaticMessage('Priority'),
               'placeHolder' : MessageService.createStaticMessage('Tap to enter'),
            });
            groupitem115.addChild( text145 );


            var groupitem116 = new GroupItem({
               'artifactId' : 'WorkApproval.SearchWorkOrderView_searchWorkOrder_groupitem_6',
               'id' : 'awcf9b809d',
            });
            group035.addChild( groupitem116 );


            var text146 = new Text({
               'resourceAttribute' : 'startdate',
               'editable' : true,
               'artifactId' : 'WorkApproval.SearchWorkOrderView_searchWorkOrder_groupitem_6_startdate_ScheduledStartDateRange',
               'id' : 'aw1d7fb009',
               'label' : MessageService.createStaticMessage('Scheduled Start Date Range'),
               'placeHolder' : MessageService.createStaticMessage('Tap to enter start date range'),
            });
            groupitem116.addChild( text146 );


            var text147 = new Text({
               'resourceAttribute' : 'enddate',
               'editable' : true,
               'artifactId' : 'WorkApproval.SearchWorkOrderView_searchWorkOrder_groupitem_6_enddate',
               'id' : 'awc54bd8d8',
               'placeHolder' : MessageService.createStaticMessage('Tap to enter end date range'),
            });
            groupitem116.addChild( text147 );


            var footer004 = new Footer({
               'artifactId' : 'WorkApproval.SearchWorkOrderView_footer',
               'id' : 'awb05c1ad3',
            });
            view028.addChild( footer004 );


            var button016 = new Button({
               'artifactId' : 'WorkApproval.SearchWorkOrderView_Clear_button',
               'id' : 'awf0683ee5',
               'label' : MessageService.createStaticMessage('Clear'),
            });
            var eventHandlers044 = [
               {
                     'method' : 'clearSearchFields',
                     'artifactId' : 'WorkApproval.SearchWorkOrderView_Clear_button_eventHandlers_click_clearSearchFields',
                     'id' : 'aw3aea4b0b',
                     'event' : 'click',
                     'class' : 'application.handlers.WODetailsHandler',
               }
            ];
            button016.eventHandlers = eventHandlers044;
            footer004.addChild( button016 );


            var button017 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'WorkApproval.SearchWorkOrderView_Search_button',
               'id' : 'aw2aaaa6be',
               'label' : MessageService.createStaticMessage('Search'),
               'primary' : 'true',
            });
            var eventHandlers045 = [
               {
                     'method' : 'setSearchQuery',
                     'artifactId' : 'WorkApproval.SearchWorkOrderView_Search_button_eventHandlers_click_setSearchQuery',
                     'id' : 'awee63d5ec',
                     'event' : 'click',
                     'class' : 'application.handlers.WODetailsHandler',
               }
            ];
            button017.eventHandlers = eventHandlers045;
            footer004.addChild( button017 );

            var eventHandlers046 = [
               {
                     'method' : 'initSearchData',
                     'artifactId' : 'WorkApproval.SearchWorkOrderView_eventHandlers_initialize_initSearchData',
                     'id' : 'aw886c9e0c',
                     'event' : 'initialize',
                     'class' : 'application.handlers.WODetailsHandler',
               },
               {
                     'method' : 'showSearch',
                     'artifactId' : 'WorkApproval.SearchWorkOrderView_eventHandlers_show_showSearch',
                     'id' : 'aw8eae58ed',
                     'event' : 'show',
                     'class' : 'application.handlers.WODetailsHandler',
               },
               {
                     'method' : 'hideSearch',
                     'artifactId' : 'WorkApproval.SearchWorkOrderView_eventHandlers_hide_hideSearch',
                     'id' : 'awebc3b307',
                     'event' : 'hide',
                     'class' : 'application.handlers.WODetailsHandler',
               },
               {
                     'method' : 'discardSummaryView',
                     'artifactId' : 'WorkApproval.SearchWorkOrderView_eventHandlers_cleanup_discardSummaryView',
                     'id' : 'aw2aea67a0',
                     'event' : 'cleanup',
                     'class' : 'application.handlers.WODetailsHandler',
               }
            ];
            view028.eventHandlers = eventHandlers046;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            var dialog004 = new Dialog({
               'id' : 'WorkApproval.RequiredSearchFieldMissing',
            });
            ui001.addChild( dialog004 );


            var container034 = new Container({
               'artifactId' : 'WorkApproval.RequiredSearchFieldMissing_container_0',
               'id' : 'aw5513b0d',
            });
            dialog004.addChild( container034 );


            var text148 = new Text({
               'editable' : false,
               'artifactId' : 'WorkApproval.RequiredSearchFieldMissing_container_0_Somerequiredfields',
               'id' : 'awb064a935',
               'value' : MessageService.createStaticMessage('Some required fields are empty. Specify the missing information.'),
            });
            container034.addChild( text148 );


            var button018 = new Button({
               'artifactId' : 'WorkApproval.RequiredSearchFieldMissing_Ok_button',
               'id' : 'aw24a5b34f',
               'label' : MessageService.createStaticMessage('Ok'),
            });
            var eventHandlers047 = [
               {
                     'method' : 'hideDialog',
                     'artifactId' : 'WorkApproval.RequiredSearchFieldMissing_Ok_button_eventHandlers_click_hideDialog',
                     'id' : 'aw99340523',
                     'event' : 'click',
                     'class' : 'application.handlers.WODetailsHandler',
               }
            ];
            button018.eventHandlers = eventHandlers047;
            container034.addChild( button018 );


            var dialog005 = new Dialog({
               'id' : 'WorkApproval.CancelConfirmationDialog',
            });
            ui001.addChild( dialog005 );


            var container035 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'WorkApproval.CancelConfirmationDialog_container_0',
               'id' : 'aw40968101',
            });
            dialog005.addChild( container035 );


            var text149 = new Text({
               'artifactId' : 'WorkApproval.CancelConfirmationDialog_container_0_Doyouwanttocance',
               'id' : 'awbc0e3e0e',
               'value' : MessageService.createStaticMessage('Do you want to cancel the work order?'),
            });
            container035.addChild( text149 );


            var container036 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'WorkApproval.CancelConfirmationDialog_container_1',
               'id' : 'aw3791b197',
            });
            dialog005.addChild( container036 );


            var button019 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'WorkApproval.CancelConfirmationDialog_Yes_button',
               'id' : 'aw296ddcb8',
               'label' : MessageService.createStaticMessage('Yes'),
            });
            var eventHandlers048 = [
               {
                     'method' : 'handleYesCancelWorkClick',
                     'artifactId' : 'WorkApproval.CancelConfirmationDialog_Yes_button_eventHandlers_click_handleYesCancelWorkClick',
                     'id' : 'aw7c642f10',
                     'event' : 'click',
                     'class' : 'application.handlers.StatusChangeHandler',
               }
            ];
            button019.eventHandlers = eventHandlers048;
            container036.addChild( button019 );


            var button020 = new Button({
               'artifactId' : 'WorkApproval.CancelConfirmationDialog_No_button',
               'id' : 'awe6aaf321',
               'label' : MessageService.createStaticMessage('No'),
            });
            var eventHandlers049 = [
               {
                     'method' : 'handleNoCancelWorkClick',
                     'artifactId' : 'WorkApproval.CancelConfirmationDialog_No_button_eventHandlers_click_handleNoCancelWorkClick',
                     'id' : 'awb9f1d45a',
                     'event' : 'click',
                     'class' : 'application.handlers.StatusChangeHandler',
               }
            ];
            button020.eventHandlers = eventHandlers049;
            container036.addChild( button020 );


            var dialog006 = new Dialog({
               'id' : 'WorkApproval.WOAssetToLocationDialog',
            });
            ui001.addChild( dialog006 );


            var container037 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'WorkApproval.WOAssetToLocationDialog_container_0',
               'id' : 'awf316a9b',
            });
            dialog006.addChild( container037 );


            var text150 = new Text({
               'artifactId' : 'WorkApproval.WOAssetToLocationDialog_container_0_Thespecifiedasset',
               'id' : 'aw26e4cd84',
               'value' : MessageService.createDynamicMessage('The specified asset is in location {0}. Do you want to replace the current location with location {1}? - If you do not want to update the current asset or the current location, click Close.', 'application.handlers.WODetailsHandler', 'resolveAssetLocation'),
               'resolverFunction' : 'resolveAssetLocation',
               'resolverClass' : 'application.handlers.WODetailsHandler',
            });
            container037.addChild( text150 );


            var container038 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'WorkApproval.WOAssetToLocationDialog_container_1',
               'id' : 'aw78365a0d',
            });
            dialog006.addChild( container038 );


            var button021 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'WorkApproval.WOAssetToLocationDialog_Yes_button',
               'id' : 'aw5174141b',
               'label' : MessageService.createStaticMessage('Yes'),
            });
            var eventHandlers050 = [
               {
                     'method' : 'asyncyesOnWOAssetToLocation',
                     'artifactId' : 'WorkApproval.WOAssetToLocationDialog_Yes_button_eventHandlers_click_asyncyesOnWOAssetToLocation',
                     'id' : 'aw57bd8dde',
                     'event' : 'click',
                     'class' : 'application.handlers.WODetailsHandler',
               }
            ];
            button021.eventHandlers = eventHandlers050;
            container038.addChild( button021 );


            var button022 = new Button({
               'artifactId' : 'WorkApproval.WOAssetToLocationDialog_Close_button',
               'id' : 'aw61211d57',
               'label' : MessageService.createStaticMessage('Close'),
            });
            var eventHandlers051 = [
               {
                     'method' : 'closeOnWOAssetToLocation',
                     'artifactId' : 'WorkApproval.WOAssetToLocationDialog_Close_button_eventHandlers_click_closeOnWOAssetToLocation',
                     'id' : 'aw32978dbf',
                     'event' : 'click',
                     'class' : 'application.handlers.WODetailsHandler',
               }
            ];
            button022.eventHandlers = eventHandlers051;
            container038.addChild( button022 );


            var button023 = new Button({
               'artifactId' : 'WorkApproval.WOAssetToLocationDialog_No_button',
               'id' : 'awf8abf269',
               'label' : MessageService.createStaticMessage('No'),
            });
            var eventHandlers052 = [
               {
                     'method' : 'noOnWOAssetToLocation',
                     'artifactId' : 'WorkApproval.WOAssetToLocationDialog_No_button_eventHandlers_click_noOnWOAssetToLocation',
                     'id' : 'aw75f971a3',
                     'event' : 'click',
                     'class' : 'application.handlers.WODetailsHandler',
               }
            ];
            button023.eventHandlers = eventHandlers052;
            container038.addChild( button023 );


            var dialog007 = new Dialog({
               'id' : 'WorkApproval.WOLocationToAssetDialog',
            });
            ui001.addChild( dialog007 );


            var container039 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'WorkApproval.WOLocationToAssetDialog_container_0',
               'id' : 'aw3d1c573d',
            });
            dialog007.addChild( container039 );


            var text151 = new Text({
               'artifactId' : 'WorkApproval.WOLocationToAssetDialog_container_0_Thespecifiedlocati',
               'id' : 'awa9a37c67',
               'value' : MessageService.createDynamicMessage('The specified location does not match the location of asset {0}. Do you want to update location and clear the asset? -  If you do not want to apply changes to the location or asset, click Close.', 'application.handlers.WODetailsHandler', 'resolveExistingAsset'),
               'resolverFunction' : 'resolveExistingAsset',
               'resolverClass' : 'application.handlers.WODetailsHandler',
            });
            container039.addChild( text151 );


            var container040 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'WorkApproval.WOLocationToAssetDialog_container_1',
               'id' : 'aw4a1b67ab',
            });
            dialog007.addChild( container040 );


            var button024 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'WorkApproval.WOLocationToAssetDialog_Yes_button',
               'id' : 'awa4255137',
               'label' : MessageService.createStaticMessage('Yes'),
            });
            var eventHandlers053 = [
               {
                     'method' : 'yesOnWOLocationToAsset',
                     'artifactId' : 'WorkApproval.WOLocationToAssetDialog_Yes_button_eventHandlers_click_yesOnWOLocationToAsset',
                     'id' : 'aweb6309b3',
                     'event' : 'click',
                     'class' : 'application.handlers.WODetailsHandler',
               }
            ];
            button024.eventHandlers = eventHandlers053;
            container040.addChild( button024 );


            var button025 = new Button({
               'artifactId' : 'WorkApproval.WOLocationToAssetDialog_Close_button',
               'id' : 'aw5ea636b7',
               'label' : MessageService.createStaticMessage('Close'),
            });
            var eventHandlers054 = [
               {
                     'method' : 'closeOnWOLocationToAsset',
                     'artifactId' : 'WorkApproval.WOLocationToAssetDialog_Close_button_eventHandlers_click_closeOnWOLocationToAsset',
                     'id' : 'aw7b3eef3',
                     'event' : 'click',
                     'class' : 'application.handlers.WODetailsHandler',
               }
            ];
            button025.eventHandlers = eventHandlers054;
            container040.addChild( button025 );


            var button026 = new Button({
               'artifactId' : 'WorkApproval.WOLocationToAssetDialog_No_button',
               'id' : 'awa62a893e',
               'label' : MessageService.createStaticMessage('No'),
            });
            var eventHandlers055 = [
               {
                     'method' : 'noOnWOLocationToAsset',
                     'artifactId' : 'WorkApproval.WOLocationToAssetDialog_No_button_eventHandlers_click_noOnWOLocationToAsset',
                     'id' : 'aw211d7a68',
                     'event' : 'click',
                     'class' : 'application.handlers.WODetailsHandler',
               }
            ];
            button026.eventHandlers = eventHandlers055;
            container040.addChild( button026 );


            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'WorkApproval.EditAssetView', false);
               trackTimer.startTracking();
            }

            var view029 = new View({
               'id' : 'WorkApproval.EditAssetView',
               'label' : MessageService.createStaticMessage('Asset'),
            });
            ui001.addChild( view029 );

            var requiredResources029 = {
               'workOrder' : {
                  'artifactId' : 'WorkApproval.EditAssetView_workOrder',
                  'id' : 'awb69d9c5d',
               },
               'additionalasset' : {
                  'artifactId' : 'WorkApproval.EditAssetView_additionalasset',
                  'id' : 'awac138c77',
               },
               'domainAssetstatus' : {
                  'artifactId' : 'WorkApproval.EditAssetView_domainAssetstatus',
                  'id' : 'awa167f5db',
               },
            };
            view029.addRequiredResources( requiredResources029 );

            var container041 = new Container({
               'resource' : 'workOrder',
               'artifactId' : 'WorkApproval.EditAssetView_workOrder_container_0',
               'id' : 'aw7ae6f162',
            });
            view029.addChild( container041 );


            var group036 = new Group({
               'artifactId' : 'WorkApproval.EditAssetView_group_0',
               'id' : 'aw93f4d9ee',
            });
            container041.addChild( group036 );


            var groupitem117 = new GroupItem({
               'artifactId' : 'WorkApproval.EditAssetView_workOrder_groupitem_0',
               'id' : 'aw3f3d6071',
            });
            group036.addChild( groupitem117 );


            var text152 = new Text({
               'resourceAttribute' : 'asset',
               'lookup' : 'WorkApproval.AssetLookup',
               'editable' : true,
               'artifactId' : 'WorkApproval.EditAssetView_workOrder_groupitem_0_asset',
               'id' : 'awfcad9d38',
               'lookupAttribute' : 'assetnum',
               'placeHolder' : MessageService.createStaticMessage('Tap to enter'),
            });
            groupitem117.addChild( text152 );

            var eventHandlers056 = [
               {
                     'method' : 'validateAsset',
                     'artifactId' : 'WorkApproval.EditAssetView_workOrder_groupitem_0_asset_eventHandlers_validate_validateAsset',
                     'id' : 'aw5834c772',
                     'event' : 'validate',
                     'class' : 'application.handlers.WODetailsHandler',
               },
               {
                     'method' : 'initAssetField',
                     'artifactId' : 'WorkApproval.EditAssetView_workOrder_groupitem_0_asset_eventHandlers_render_initAssetField',
                     'id' : 'aw87c83c3a',
                     'event' : 'render',
                     'class' : 'application.handlers.WODetailsHandler',
               }
            ];
            text152.eventHandlers = eventHandlers056;

            var text153 = new Text({
               'resourceAttribute' : 'assetdesc',
               'editable' : false,
               'artifactId' : 'WorkApproval.EditAssetView_workOrder_groupitem_0_assetdesc',
               'id' : 'aw64432b2a',
            });
            groupitem117.addChild( text153 );


            var groupitem118 = new GroupItem({
               'artifactId' : 'WorkApproval.EditAssetView_workOrder_groupitem_1',
               'id' : 'aw483a50e7',
            });
            group036.addChild( groupitem118 );


            var text154 = new Text({
               'resourceAttribute' : 'localAssetLd',
               'cssClass' : 'richText',
               'editable' : false,
               'artifactId' : 'WorkApproval.EditAssetView_workOrder_groupitem_1_assetld',
               'id' : 'aw4c1428f9',
            });
            groupitem118.addChild( text154 );


            var footer005 = new Footer({
               'artifactId' : 'WorkApproval.EditAssetView_footer',
               'id' : 'awd2c8535b',
            });
            view029.addChild( footer005 );


            var button027 = new Button({
               'artifactId' : 'WorkApproval.EditAssetView_Cancel_button',
               'id' : 'aw17681312',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers057 = [
               {
                     'method' : 'handleBackButtonClickEditAssetView',
                     'artifactId' : 'WorkApproval.EditAssetView_Cancel_button_eventHandlers_click_handleBackButtonClickEditAssetView',
                     'id' : 'aw637967f1',
                     'event' : 'click',
                     'class' : 'application.handlers.WODetailsHandler',
               }
            ];
            button027.eventHandlers = eventHandlers057;
            footer005.addChild( button027 );


            var button028 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'WorkApproval.EditAssetView_Save_button',
               'id' : 'aw4a5080d4',
               'label' : MessageService.createStaticMessage('Save'),
               'primary' : 'true',
            });
            var eventHandlers058 = [
               {
                     'method' : 'commitAssetEntryView',
                     'artifactId' : 'WorkApproval.EditAssetView_Save_button_eventHandlers_click_commitAssetEntryView',
                     'id' : 'aw83f18ca0',
                     'event' : 'click',
                     'class' : 'application.handlers.WODetailsHandler',
               }
            ];
            button028.eventHandlers = eventHandlers058;
            footer005.addChild( button028 );

            var eventHandlers059 = [
               {
                     'method' : 'initEditAssetView',
                     'artifactId' : 'WorkApproval.EditAssetView_eventHandlers_initialize_initEditAssetView',
                     'id' : 'aw810bb4ea',
                     'event' : 'initialize',
                     'class' : 'application.handlers.WODetailsHandler',
               },
               {
                     'method' : 'cleanupEditAssetView',
                     'artifactId' : 'WorkApproval.EditAssetView_eventHandlers_cleanup_cleanupEditAssetView',
                     'id' : 'aw240b07dd',
                     'event' : 'cleanup',
                     'class' : 'application.handlers.WODetailsHandler',
               }
            ];
            view029.eventHandlers = eventHandlers059;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'WorkApproval.EditLocationView', false);
               trackTimer.startTracking();
            }

            var view030 = new View({
               'id' : 'WorkApproval.EditLocationView',
               'label' : MessageService.createStaticMessage('Location'),
            });
            ui001.addChild( view030 );

            var requiredResources030 = {
               'workOrder' : {
                  'artifactId' : 'WorkApproval.EditLocationView_workOrder',
                  'id' : 'awa449be5a',
               },
               'domainAssetstatus' : {
                  'artifactId' : 'WorkApproval.EditLocationView_domainAssetstatus',
                  'id' : 'aw600f4eac',
               },
               'additionallocations' : {
                  'artifactId' : 'WorkApproval.EditLocationView_additionallocations',
                  'id' : 'awac020001',
               },
               'additionalasset' : {
                  'artifactId' : 'WorkApproval.EditLocationView_additionalasset',
                  'id' : 'awbc83997b',
               },
            };
            view030.addRequiredResources( requiredResources030 );

            var container042 = new Container({
               'resource' : 'workOrder',
               'artifactId' : 'WorkApproval.EditLocationView_workOrder_container_0',
               'id' : 'aw4426b3f',
            });
            view030.addChild( container042 );


            var group037 = new Group({
               'artifactId' : 'WorkApproval.EditLocationView_group_0',
               'id' : 'aw5ecf59f3',
            });
            container042.addChild( group037 );


            var groupitem119 = new GroupItem({
               'artifactId' : 'WorkApproval.EditLocationView_workOrder_groupitem_0',
               'id' : 'aw4199fa2c',
            });
            group037.addChild( groupitem119 );


            var text155 = new Text({
               'resourceAttribute' : 'location',
               'lookup' : 'WorkApproval.LocationLookup',
               'editable' : true,
               'artifactId' : 'WorkApproval.EditLocationView_workOrder_groupitem_0_location_Location',
               'id' : 'aw3121946',
               'label' : MessageService.createStaticMessage('Location'),
               'lookupAttribute' : 'location',
               'placeHolder' : MessageService.createStaticMessage('Tap to enter'),
            });
            groupitem119.addChild( text155 );

            var eventHandlers060 = [
               {
                     'method' : 'validateLocation',
                     'artifactId' : 'WorkApproval.EditLocationView_workOrder_groupitem_0_location_Location_eventHandlers_validate_validateLocation',
                     'id' : 'aw57cdcb78',
                     'event' : 'validate',
                     'class' : 'application.handlers.WODetailsHandler',
               },
               {
                     'method' : 'initLocationField',
                     'artifactId' : 'WorkApproval.EditLocationView_workOrder_groupitem_0_location_Location_eventHandlers_render_initLocationField',
                     'id' : 'aw24b4d804',
                     'event' : 'render',
                     'class' : 'application.handlers.WODetailsHandler',
               }
            ];
            text155.eventHandlers = eventHandlers060;

            var text156 = new Text({
               'resourceAttribute' : 'locationdesc',
               'editable' : false,
               'artifactId' : 'WorkApproval.EditLocationView_workOrder_groupitem_0_locationdesc',
               'id' : 'aw290b0ba6',
            });
            groupitem119.addChild( text156 );


            var groupitem120 = new GroupItem({
               'artifactId' : 'WorkApproval.EditLocationView_workOrder_groupitem_1',
               'id' : 'aw369ecaba',
            });
            group037.addChild( groupitem120 );


            var text157 = new Text({
               'resourceAttribute' : 'localLocationLd',
               'cssClass' : 'richText',
               'editable' : false,
               'artifactId' : 'WorkApproval.EditLocationView_workOrder_groupitem_1_locationld',
               'id' : 'aw8e2373cb',
            });
            groupitem120.addChild( text157 );


            var footer006 = new Footer({
               'artifactId' : 'WorkApproval.EditLocationView_footer',
               'id' : 'aw3e4eddae',
            });
            view030.addChild( footer006 );


            var button029 = new Button({
               'layoutInsertAt' : 'button1',
               'artifactId' : 'WorkApproval.EditLocationView_Cancel_button',
               'id' : 'awa79bc876',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers061 = [
               {
                     'method' : 'discardView',
                     'artifactId' : 'WorkApproval.EditLocationView_Cancel_button_eventHandlers_click_discardView',
                     'id' : 'awf0a2c503',
                     'event' : 'click',
                     'class' : 'application.handlers.WODetailsHandler',
               }
            ];
            button029.eventHandlers = eventHandlers061;
            footer006.addChild( button029 );


            var button030 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'layoutInsertAt' : 'button2',
               'artifactId' : 'WorkApproval.EditLocationView_Save_button',
               'id' : 'awd0714523',
               'label' : MessageService.createStaticMessage('Save'),
               'primary' : 'true',
            });
            var eventHandlers062 = [
               {
                     'method' : 'commitActualLocationEntryView',
                     'artifactId' : 'WorkApproval.EditLocationView_Save_button_eventHandlers_click_commitActualLocationEntryView',
                     'id' : 'awcad81e29',
                     'event' : 'click',
                     'class' : 'application.handlers.WODetailsHandler',
               }
            ];
            button030.eventHandlers = eventHandlers062;
            footer006.addChild( button030 );

            var eventHandlers063 = [
               {
                     'method' : 'cleanupEditLocationView',
                     'artifactId' : 'WorkApproval.EditLocationView_eventHandlers_cleanup_cleanupEditLocationView',
                     'id' : 'aw70c2a3f6',
                     'event' : 'cleanup',
                     'class' : 'application.handlers.WODetailsHandler',
               },
               {
                     'method' : 'initEditLocationView',
                     'artifactId' : 'WorkApproval.EditLocationView_eventHandlers_initialize_initEditLocationView',
                     'id' : 'aw9e0ead3d',
                     'event' : 'initialize',
                     'class' : 'application.handlers.WODetailsHandler',
               }
            ];
            view030.eventHandlers = eventHandlers063;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            var lookup001 = new Lookup({
               'resource' : 'domainlogtype',
               'id' : 'WorkApproval.LogTypeLookup',
               'label' : MessageService.createStaticMessage('Select Log Type'),
            });
            ui001.addChild( lookup001 );

            var requiredResources031 = {
               'domainlogtype' : {
                  'reload' : true,
                  'artifactId' : 'WorkApproval.LogTypeLookup_domainlogtype',
                  'id' : 'aw28c7dc61',
               },
            };
            lookup001.addRequiredResources( requiredResources031 );


            var searchAttributes001 = new SearchAttributes({
               'artifactId' : 'WorkApproval.LogTypeLookup_domainlogtype_searchAttributes',
               'id' : 'aw705d186',
            });

            var searchAttribute001 = new SearchAttribute({
               'name' : 'value',
               'artifactId' : 'WorkApproval.LogTypeLookup_domainlogtype_searchAttribute_value',
               'id' : 'aw84dd529b',
            });
            searchAttributes001.addChild( searchAttribute001 );


            var searchAttribute002 = new SearchAttribute({
               'name' : 'description',
               'artifactId' : 'WorkApproval.LogTypeLookup_domainlogtype_searchAttribute_description',
               'id' : 'aw1f0a81a2',
            });
            searchAttributes001.addChild( searchAttribute002 );



            var listItemTemplate009 = new ListItemTemplate({
               'layout' : 'Item1Desc1',
               'artifactId' : 'WorkApproval.LogTypeLookup_domainlogtype_listItemTemplate_Item1Desc1',
               'id' : 'awa3ff1799',
            });

            var listtext032 = new ListText({
               'resourceAttribute' : 'value',
               'cssClass' : 'bold textappearance-medium',
               'layoutInsertAt' : 'item1',
               'artifactId' : 'WorkApproval.LogTypeLookup_domainlogtype_Item1Desc1_value',
               'id' : 'aw3c7b96de',
            });
            listItemTemplate009.addChild( listtext032 );


            var listtext033 = new ListText({
               'resourceAttribute' : 'description',
               'cssClass' : 'bold textappearance-medium',
               'layoutInsertAt' : 'desc1',
               'artifactId' : 'WorkApproval.LogTypeLookup_domainlogtype_Item1Desc1_description',
               'id' : 'awff47bd17',
            });
            listItemTemplate009.addChild( listtext033 );



            var list009 = new List({
               'resource' : 'domainlogtype',
               'listItemTemplate' : listItemTemplate009,
               'artifactId' : 'WorkApproval.LogTypeLookup_domainlogtype_list',
               'id' : 'aw1880feb0',
               'searchAttributes' : searchAttributes001,
            });
            lookup001.addChild( list009 );


            var lookup002 = new Lookup({
               'filterMethod' : 'filterAssetForLookup',
               'resource' : 'additionalasset',
               'filterClass' : 'application.handlers.WODetailsHandler',
               'id' : 'WorkApproval.AssetLookup',
               'label' : MessageService.createStaticMessage('Select Asset'),
            });
            ui001.addChild( lookup002 );

            var requiredResources032 = {
               'additionalasset' : {
                  'artifactId' : 'WorkApproval.AssetLookup_additionalasset',
                  'id' : 'awca497b03',
               },
               'workOrder' : {
                  'artifactId' : 'WorkApproval.AssetLookup_workOrder',
                  'id' : 'aw7625504d',
               },
            };
            lookup002.addRequiredResources( requiredResources032 );


            var searchAttributes002 = new SearchAttributes({
               'artifactId' : 'WorkApproval.AssetLookup_additionalasset_searchAttributes',
               'id' : 'aw5bd3341b',
            });

            var searchAttribute003 = new SearchAttribute({
               'name' : 'assetnum',
               'artifactId' : 'WorkApproval.AssetLookup_additionalasset_searchAttribute_assetnum',
               'id' : 'aw7d893ecf',
            });
            searchAttributes002.addChild( searchAttribute003 );


            var searchAttribute004 = new SearchAttribute({
               'name' : 'description',
               'artifactId' : 'WorkApproval.AssetLookup_additionalasset_searchAttribute_description',
               'id' : 'awb9d625fe',
            });
            searchAttributes002.addChild( searchAttribute004 );


            var searchAttribute005 = new SearchAttribute({
               'name' : 'location',
               'artifactId' : 'WorkApproval.AssetLookup_additionalasset_searchAttribute_location',
               'id' : 'aw9ccfc41b',
            });
            searchAttributes002.addChild( searchAttribute005 );


            var searchAttribute006 = new SearchAttribute({
               'name' : 'locationdesc',
               'artifactId' : 'WorkApproval.AssetLookup_additionalasset_searchAttribute_locationdesc',
               'id' : 'awafd056b8',
            });
            searchAttributes002.addChild( searchAttribute006 );



            var listItemTemplate010 = new ListItemTemplate({
               'layout' : 'Item2Desc2',
               'artifactId' : 'WorkApproval.AssetLookup_additionalasset_listItemTemplate_Item2Desc2',
               'id' : 'aw1abe90d1',
            });

            var listtext034 = new ListText({
               'resourceAttribute' : 'assetnum',
               'cssClass' : 'bold textappearance-medium',
               'layoutInsertAt' : 'item1',
               'artifactId' : 'WorkApproval.AssetLookup_additionalasset_Item2Desc2_assetnum',
               'id' : 'aw45a1a6e',
            });
            listItemTemplate010.addChild( listtext034 );


            var listtext035 = new ListText({
               'resourceAttribute' : 'description',
               'cssClass' : 'bold textappearance-medium',
               'layoutInsertAt' : 'desc1',
               'artifactId' : 'WorkApproval.AssetLookup_additionalasset_Item2Desc2_description',
               'id' : 'aw8f5e7018',
            });
            listItemTemplate010.addChild( listtext035 );


            var listtext036 = new ListText({
               'resourceAttribute' : 'location',
               'layoutInsertAt' : 'item2',
               'artifactId' : 'WorkApproval.AssetLookup_additionalasset_Item2Desc2_location',
               'id' : 'awe51ce0ba',
            });
            listItemTemplate010.addChild( listtext036 );


            var listtext037 = new ListText({
               'resourceAttribute' : 'locationdesc',
               'layoutInsertAt' : 'desc2',
               'artifactId' : 'WorkApproval.AssetLookup_additionalasset_Item2Desc2_locationdesc',
               'id' : 'awe68f99a0',
            });
            listItemTemplate010.addChild( listtext037 );



            var list010 = new List({
               'resource' : 'additionalasset',
               'listItemTemplate' : listItemTemplate010,
               'artifactId' : 'WorkApproval.AssetLookup_additionalasset_list',
               'id' : 'awac2d5cc5',
               'searchAttributes' : searchAttributes002,
            });
            lookup002.addChild( list010 );


            var returnAttributes001 = new ReturnAttributes({
               'artifactId' : 'WorkApproval.AssetLookup_returnAttributes',
               'id' : 'awcb95bfe4',
            });
            lookup002.addChild( returnAttributes001 );


            var returnAttribute001 = new ReturnAttribute({
               'targetAttribute' : 'asset',
               'artifactId' : 'WorkApproval.AssetLookup_assetnum_asset',
               'id' : 'awb5173d7f',
               'sourceAttribute' : 'assetnum',
            });
            returnAttributes001.addChild( returnAttribute001 );


            var returnAttribute002 = new ReturnAttribute({
               'targetAttribute' : 'assetdesc',
               'artifactId' : 'WorkApproval.AssetLookup_description_assetdesc',
               'id' : 'awb4d130c',
               'sourceAttribute' : 'description',
            });
            returnAttributes001.addChild( returnAttribute002 );


            var lookup003 = new Lookup({
               'filterMethod' : 'filterLocationForLookup',
               'resource' : 'additionallocations',
               'filterClass' : 'application.handlers.WODetailsHandler',
               'id' : 'WorkApproval.LocationLookup',
               'label' : MessageService.createStaticMessage('Select Location'),
            });
            ui001.addChild( lookup003 );

            var requiredResources033 = {
               'additionallocations' : {
                  'artifactId' : 'WorkApproval.LocationLookup_additionallocations',
                  'id' : 'aw121ea9f0',
               },
            };
            lookup003.addRequiredResources( requiredResources033 );


            var searchAttributes003 = new SearchAttributes({
               'artifactId' : 'WorkApproval.LocationLookup_additionallocations_searchAttributes',
               'id' : 'aw47ccbb96',
            });

            var searchAttribute007 = new SearchAttribute({
               'name' : 'location',
               'artifactId' : 'WorkApproval.LocationLookup_additionallocations_searchAttribute_location',
               'id' : 'aw7d3f04c6',
            });
            searchAttributes003.addChild( searchAttribute007 );


            var searchAttribute008 = new SearchAttribute({
               'name' : 'description',
               'artifactId' : 'WorkApproval.LocationLookup_additionallocations_searchAttribute_description',
               'id' : 'aw4ac0a62e',
            });
            searchAttributes003.addChild( searchAttribute008 );



            var listItemTemplate011 = new ListItemTemplate({
               'layout' : 'Item1Desc1',
               'artifactId' : 'WorkApproval.LocationLookup_additionallocations_listItemTemplate_Item1Desc1',
               'id' : 'awf6353015',
            });

            var listtext038 = new ListText({
               'resourceAttribute' : 'location',
               'cssClass' : 'bold textappearance-medium',
               'layoutInsertAt' : 'item1',
               'artifactId' : 'WorkApproval.LocationLookup_additionallocations_Item1Desc1_location',
               'id' : 'awc7a8307e',
            });
            listItemTemplate011.addChild( listtext038 );


            var listtext039 = new ListText({
               'resourceAttribute' : 'description',
               'cssClass' : 'bold textappearance-medium',
               'layoutInsertAt' : 'desc1',
               'artifactId' : 'WorkApproval.LocationLookup_additionallocations_Item1Desc1_description',
               'id' : 'aw54ccfc2c',
            });
            listItemTemplate011.addChild( listtext039 );



            var list011 = new List({
               'resource' : 'additionallocations',
               'listItemTemplate' : listItemTemplate011,
               'artifactId' : 'WorkApproval.LocationLookup_additionallocations_list',
               'id' : 'awff67078',
               'searchAttributes' : searchAttributes003,
            });
            lookup003.addChild( list011 );


            var returnAttributes002 = new ReturnAttributes({
               'artifactId' : 'WorkApproval.LocationLookup_returnAttributes',
               'id' : 'aw11842000',
            });
            lookup003.addChild( returnAttributes002 );


            var returnAttribute003 = new ReturnAttribute({
               'targetAttribute' : 'location',
               'artifactId' : 'WorkApproval.LocationLookup_location_location',
               'id' : 'awf1ad1036',
               'sourceAttribute' : 'location',
            });
            returnAttributes002.addChild( returnAttribute003 );


            var returnAttribute004 = new ReturnAttribute({
               'targetAttribute' : 'locationdesc',
               'artifactId' : 'WorkApproval.LocationLookup_description_locationdesc',
               'id' : 'aw91537a7c',
               'sourceAttribute' : 'description',
            });
            returnAttributes002.addChild( returnAttribute004 );


            var lookup004 = new Lookup({
               'filterMethod' : 'filterWOStatus',
               'resource' : 'domainwostatus',
               'filterClass' : 'application.handlers.StatusChangeHandler',
               'id' : 'WorkApproval.statusLookup',
               'label' : MessageService.createStaticMessage('Work Order Status'),
            });
            ui001.addChild( lookup004 );

            var requiredResources034 = {
               'domainwostatus' : {
                  'artifactId' : 'WorkApproval.statusLookup_domainwostatus',
                  'id' : 'aw6d8958d4',
               },
               'workOrder' : {
                  'artifactId' : 'WorkApproval.statusLookup_workOrder',
                  'id' : 'awf2ef5d52',
                  'related' : {
                     'actuallaborlist' : {
                        'artifactId' : 'WorkApproval.statusLookup_workOrder_actuallaborlist',
                        'id' : 'aw86c178a3',
                     },
                  },
               },
            };
            lookup004.addRequiredResources( requiredResources034 );


            var listItemTemplate012 = new ListItemTemplate({
               'layout' : 'Item1Desc1',
               'artifactId' : 'WorkApproval.statusLookup_domainwostatus_listItemTemplate_Item1Desc1',
               'id' : 'awe7c20f0c',
            });

            var listtext040 = new ListText({
               'resourceAttribute' : 'value',
               'cssClass' : 'bold textappearance-medium',
               'layoutInsertAt' : 'item1',
               'artifactId' : 'WorkApproval.statusLookup_domainwostatus_Item1Desc1_value',
               'id' : 'aw21f541da',
            });
            listItemTemplate012.addChild( listtext040 );


            var listtext041 = new ListText({
               'resourceAttribute' : 'description',
               'cssClass' : 'bold textappearance-medium',
               'layoutInsertAt' : 'desc1',
               'artifactId' : 'WorkApproval.statusLookup_domainwostatus_Item1Desc1_description',
               'id' : 'aw467bad63',
            });
            listItemTemplate012.addChild( listtext041 );



            var list012 = new List({
               'resource' : 'domainwostatus',
               'listItemTemplate' : listItemTemplate012,
               'artifactId' : 'WorkApproval.statusLookup_domainwostatus_list',
               'id' : 'aw55964332',
            });
            lookup004.addChild( list012 );


            var returnAttributes003 = new ReturnAttributes({
               'artifactId' : 'WorkApproval.statusLookup_returnAttributes',
               'id' : 'aw2703910b',
            });
            lookup004.addChild( returnAttributes003 );


            var returnAttribute005 = new ReturnAttribute({
               'targetAttribute' : 'status',
               'artifactId' : 'WorkApproval.statusLookup_value_status',
               'id' : 'aw34f08f04',
               'sourceAttribute' : 'value',
            });
            returnAttributes003.addChild( returnAttribute005 );


            var returnAttribute006 = new ReturnAttribute({
               'targetAttribute' : 'statusdesc',
               'artifactId' : 'WorkApproval.statusLookup_description_statusdesc',
               'id' : 'awe570de28',
               'sourceAttribute' : 'description',
            });
            returnAttributes003.addChild( returnAttribute006 );


            var lookup005 = new Lookup({
               'filterMethod' : 'filterTaskStatus',
               'resource' : 'domainwostatus',
               'filterClass' : 'application.handlers.StatusChangeHandler',
               'id' : 'WorkApproval.taskStatusLookup',
               'label' : MessageService.createStaticMessage('Task Status'),
            });
            ui001.addChild( lookup005 );

            var requiredResources035 = {
               'domainwostatus' : {
                  'artifactId' : 'WorkApproval.taskStatusLookup_domainwostatus',
                  'id' : 'aw12cd0b92',
               },
               'workOrder' : {
                  'artifactId' : 'WorkApproval.taskStatusLookup_workOrder',
                  'id' : 'awb175e29f',
                  'related' : {
                     'actuallaborlist' : {
                        'artifactId' : 'WorkApproval.taskStatusLookup_workOrder_actuallaborlist',
                        'id' : 'aw1c114773',
                     },
                     'tasklist' : {
                        'artifactId' : 'WorkApproval.taskStatusLookup_workOrder_tasklist',
                        'id' : 'awf3feccaa',
                     },
                  },
               },
            };
            lookup005.addRequiredResources( requiredResources035 );


            var listItemTemplate013 = new ListItemTemplate({
               'layout' : 'Item1Desc1',
               'artifactId' : 'WorkApproval.taskStatusLookup_domainwostatus_listItemTemplate_Item1Desc1',
               'id' : 'aw9f430728',
            });

            var listtext042 = new ListText({
               'resourceAttribute' : 'value',
               'cssClass' : 'bold textappearance-medium',
               'layoutInsertAt' : 'item1',
               'artifactId' : 'WorkApproval.taskStatusLookup_domainwostatus_Item1Desc1_value',
               'id' : 'awc66af61d',
            });
            listItemTemplate013.addChild( listtext042 );


            var listtext043 = new ListText({
               'resourceAttribute' : 'description',
               'cssClass' : 'bold textappearance-medium',
               'layoutInsertAt' : 'desc1',
               'artifactId' : 'WorkApproval.taskStatusLookup_domainwostatus_Item1Desc1_description',
               'id' : 'awa1ff60bc',
            });
            listItemTemplate013.addChild( listtext043 );



            var list013 = new List({
               'resource' : 'domainwostatus',
               'listItemTemplate' : listItemTemplate013,
               'artifactId' : 'WorkApproval.taskStatusLookup_domainwostatus_list',
               'id' : 'aw84a90eb2',
            });
            lookup005.addChild( list013 );


            var returnAttributes004 = new ReturnAttributes({
               'artifactId' : 'WorkApproval.taskStatusLookup_returnAttributes',
               'id' : 'aw73420682',
            });
            lookup005.addChild( returnAttributes004 );


            var returnAttribute007 = new ReturnAttribute({
               'targetAttribute' : 'status',
               'artifactId' : 'WorkApproval.taskStatusLookup_value_status',
               'id' : 'awde004279',
               'sourceAttribute' : 'value',
            });
            returnAttributes004.addChild( returnAttribute007 );


            var returnAttribute008 = new ReturnAttribute({
               'targetAttribute' : 'statusdesc',
               'artifactId' : 'WorkApproval.taskStatusLookup_description_statusdesc',
               'id' : 'awf7f4d90c',
               'sourceAttribute' : 'description',
            });
            returnAttributes004.addChild( returnAttribute008 );


            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'Platform.AttachmentInfoView', false);
               trackTimer.startTracking();
            }

            var view031 = new View({
               'resource' : 'PlatformAttachmentInfoResource',
               'id' : 'Platform.AttachmentInfoView',
               'label' : MessageService.createStaticMessage('Attachment Details'),
            });
            ui001.addChild( view031 );

            var requiredResources036 = {
               'PlatformAttachmentInfoResource' : {
                  'reload' : true,
                  'artifactId' : 'Platform.AttachmentInfoView_PlatformAttachmentInfoResource',
                  'id' : 'awedbd920b',
               },
            };
            view031.addRequiredResources( requiredResources036 );

            var container043 = new Container({
               'resource' : 'PlatformAttachmentInfoResource',
               'artifactId' : 'Platform.AttachmentInfoView_container_0',
               'id' : 'aw22b80d5f',
            });
            view031.addChild( container043 );


            var group038 = new Group({
               'artifactId' : 'Platform.AttachmentInfoView_group_0',
               'id' : 'aw80e7b381',
            });
            container043.addChild( group038 );


            var groupitem121 = new GroupItem({
               'artifactId' : 'Platform.AttachmentInfoView_PlatformAttachmentInfoResource_groupitem_0',
               'id' : 'aw15768e0',
            });
            group038.addChild( groupitem121 );


            var text158 = new Text({
               'resourceAttribute' : 'name',
               'editable' : true,
               'artifactId' : 'Platform.AttachmentInfoView_PlatformAttachmentInfoResource_groupitem_0_name_Name',
               'id' : 'awddf675f4',
               'label' : MessageService.createStaticMessage('Name'),
               'required' : true,
            });
            groupitem121.addChild( text158 );


            var groupitem122 = new GroupItem({
               'artifactId' : 'Platform.AttachmentInfoView_PlatformAttachmentInfoResource_groupitem_1',
               'id' : 'aw76505876',
            });
            group038.addChild( groupitem122 );


            var text159 = new Text({
               'resourceAttribute' : 'description',
               'editable' : true,
               'artifactId' : 'Platform.AttachmentInfoView_PlatformAttachmentInfoResource_groupitem_1_description_Description',
               'id' : 'awc2735258',
               'label' : MessageService.createStaticMessage('Description'),
               'placeHolder' : MessageService.createStaticMessage('Tap to enter'),
            });
            groupitem122.addChild( text159 );


            var groupitem123 = new GroupItem({
               'artifactId' : 'Platform.AttachmentInfoView_PlatformAttachmentInfoResource_groupitem_2',
               'id' : 'awef5909cc',
            });
            group038.addChild( groupitem123 );


            var text160 = new Text({
               'resourceAttribute' : 'category',
               'lookup' : 'PlatformAttachmentIn.CategoryLookup',
               'editable' : false,
               'artifactId' : 'Platform.AttachmentInfoView_PlatformAttachmentInfoResource_groupitem_2_category_Folder',
               'id' : 'aw3a5ae064',
               'label' : MessageService.createStaticMessage('Folder'),
               'lookupAttribute' : 'folderName',
               'placeHolder' : MessageService.createStaticMessage('Tap to enter'),
            });
            groupitem123.addChild( text160 );

            var eventHandlers064 = [
               {
                     'method' : 'renderCategory',
                     'artifactId' : 'Platform.AttachmentInfoView_PlatformAttachmentInfoResource_groupitem_2_category_Folder_eventHandlers_render_renderCategory',
                     'id' : 'awa205ff23',
                     'event' : 'render',
                     'class' : 'platform.handlers.AttachmentHandler',
               }
            ];
            text160.eventHandlers = eventHandlers064;

            var groupitem124 = new GroupItem({
               'artifactId' : 'Platform.AttachmentInfoView_PlatformAttachmentInfoResource_groupitem_3',
               'id' : 'aw985e395a',
            });
            group038.addChild( groupitem124 );


            var text161 = new Text({
               'resourceAttribute' : 'fileType',
               'editable' : false,
               'artifactId' : 'Platform.AttachmentInfoView_PlatformAttachmentInfoResource_groupitem_3_fileType_FileType',
               'id' : 'awf0b55f9',
               'label' : MessageService.createStaticMessage('File Type'),
            });
            groupitem124.addChild( text161 );


            var groupitem125 = new GroupItem({
               'artifactId' : 'Platform.AttachmentInfoView_PlatformAttachmentInfoResource_groupitem_4',
               'id' : 'aw63aacf9',
            });
            group038.addChild( groupitem125 );


            var text162 = new Text({
               'resourceAttribute' : 'fileSize',
               'editable' : false,
               'artifactId' : 'Platform.AttachmentInfoView_PlatformAttachmentInfoResource_groupitem_4_fileSize_FileSizeKB',
               'id' : 'awa8aac05f',
               'label' : MessageService.createStaticMessage('File Size (KB)'),
            });
            groupitem125.addChild( text162 );


            var footer007 = new Footer({
               'artifactId' : 'Platform.AttachmentInfoView_footer',
               'id' : 'awad3a6a43',
            });
            view031.addChild( footer007 );


            var button031 = new Button({
               'artifactId' : 'Platform.AttachmentInfoView_Cancel_button',
               'id' : 'aw61842429',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers065 = [
               {
                     'method' : 'handleBackButtonAttachmentDetailsView',
                     'artifactId' : 'Platform.AttachmentInfoView_Cancel_button_eventHandlers_click_handleBackButtonAttachmentDetailsView',
                     'id' : 'aw2e660b65',
                     'event' : 'click',
                     'class' : 'platform.handlers.AttachmentHandler',
               }
            ];
            button031.eventHandlers = eventHandlers065;
            footer007.addChild( button031 );


            var button032 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'Platform.AttachmentInfoView_Save_button',
               'id' : 'aw8904293b',
               'label' : MessageService.createStaticMessage('Save'),
            });
            var eventHandlers066 = [
               {
                     'method' : 'commitAttachmentEntry',
                     'artifactId' : 'Platform.AttachmentInfoView_Save_button_eventHandlers_click_commitAttachmentEntry',
                     'id' : 'awbff90b7f',
                     'event' : 'click',
                     'class' : 'platform.handlers.AttachmentHandler',
               }
            ];
            button032.eventHandlers = eventHandlers066;
            footer007.addChild( button032 );

            var eventHandlers067 = [
               {
                     'method' : 'init',
                     'artifactId' : 'Platform.AttachmentInfoView_eventHandlers_initialize_init',
                     'id' : 'awbe3d1849',
                     'event' : 'initialize',
                     'class' : 'platform.handlers.AttachmentHandler',
               },
               {
                     'method' : 'cancelAttachmentDetailsView',
                     'artifactId' : 'Platform.AttachmentInfoView_eventHandlers_cleanup_handleBackButtonAttachmentDetailsView',
                     'id' : 'awb6598e9',
                     'event' : 'cleanup',
                     'class' : 'platform.handlers.AttachmentHandler',
               }
            ];
            view031.eventHandlers = eventHandlers067;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'Platform.AttachmentFileDialog', false);
               trackTimer.startTracking();
            }

            var view032 = new View({
               'id' : 'Platform.AttachmentFileDialog',
            });
            ui001.addChild( view032 );


            var footer008 = new Footer({
               'artifactId' : 'Platform.AttachmentFileDialog_footer',
               'id' : 'awb513dc05',
            });
            view032.addChild( footer008 );


            var button033 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'Platform.UnsavedSketch_doNotAllow_button',
               'id' : 'aw150d1bc',
               'label' : MessageService.createStaticMessage('Close'),
            });
            var eventHandlers068 = [
               {
                     'method' : 'closeFileDialog',
                     'artifactId' : 'Platform.AttachmentFileDialog_closeDialog',
                     'id' : 'awc0d2f7fd',
                     'event' : 'click',
                     'class' : 'platform.handlers.AttachmentHandler',
               }
            ];
            button033.eventHandlers = eventHandlers068;
            footer008.addChild( button033 );

            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            var lookup006 = new Lookup({
               'resource' : 'PlatformAttachmentCategoryResource',
               'id' : 'PlatformAttachmentIn.CategoryLookup',
               'label' : MessageService.createStaticMessage('Select Folder'),
            });
            ui001.addChild( lookup006 );

            var requiredResources037 = {
               'PlatformAttachmentCategoryResource' : {
                  'artifactId' : 'PlatformAttachmentIn.CategoryLookup_PlatformAttachmentCategoryResource',
                  'id' : 'aw18cc3542',
               },
            };
            lookup006.addRequiredResources( requiredResources037 );


            var searchAttributes004 = new SearchAttributes({
               'artifactId' : 'PlatformAttachmentIn.CategoryLookup_PlatformAttachmentCategoryResource_searchAttributes',
               'id' : 'awb7d9341f',
            });

            var searchAttribute009 = new SearchAttribute({
               'name' : 'folderName',
               'artifactId' : 'PlatformAttachmentIn.CategoryLookup_PlatformAttachmentCategoryResource_searchAttribute_folderName',
               'id' : 'aw9514e6e6',
            });
            searchAttributes004.addChild( searchAttribute009 );



            var listItemTemplate014 = new ListItemTemplate({
               'layout' : 'Item2Desc2',
               'artifactId' : 'PlatformAttachmentIn.CategoryLookup_PlatformAttachmentCategoryResource_listItemTemplate_Item2Desc2',
               'id' : 'aweb3659e3',
            });

            var listtext044 = new ListText({
               'resourceAttribute' : 'folderName',
               'cssClass' : 'bold textappearance-medium',
               'layoutInsertAt' : 'item1',
               'artifactId' : 'PlatformAttachmentIn.CategoryLookup_PlatformAttachmentCategoryResource_Item2Desc2_folderName',
               'id' : 'aw48fc196b',
            });
            listItemTemplate014.addChild( listtext044 );



            var list014 = new List({
               'resource' : 'PlatformAttachmentCategoryResource',
               'listItemTemplate' : listItemTemplate014,
               'artifactId' : 'PlatformAttachmentIn.CategoryLookup_PlatformAttachmentCategoryResource_list',
               'id' : 'awe6857cc4',
               'searchAttributes' : searchAttributes004,
            });
            lookup006.addChild( list014 );


            var returnAttributes005 = new ReturnAttributes({
               'artifactId' : 'PlatformAttachmentIn.CategoryLookup_returnAttributes',
               'id' : 'aw4860e6b5',
            });
            lookup006.addChild( returnAttributes005 );


            var returnAttribute009 = new ReturnAttribute({
               'targetAttribute' : 'category',
               'artifactId' : 'PlatformAttachmentIn.CategoryLookup_folderName_category',
               'id' : 'awb2f5d728',
               'sourceAttribute' : 'folderName',
            });
            returnAttributes005.addChild( returnAttribute009 );


            var actions004 = new Actions({
               'artifactId' : 'actions',
               'id' : 'aw548f1ef',
            });
            ui001.addChild( actions004 );


            var action008 = new Action({
               'overflow' : true,
               'artifactId' : 'ResetWorkList_action',
               'id' : 'aw956f5d3b',
               'label' : MessageService.createStaticMessage('Reset Work List'),
            });
            actions004.addChild( action008 );

            var eventHandlers069 = [
               {
                     'method' : 'resetWorkList',
                     'artifactId' : 'ResetWorkList_action_eventHandlers_click_findByScan',
                     'id' : 'aw11a2bd29',
                     'event' : 'click',
                     'class' : 'platform.handlers.WorkOfflineHandler',
               },
               {
                     'method' : 'enableResetWorkList',
                     'artifactId' : 'ResetWorkList_action_eventHandlers_render_enableResetWorkList',
                     'id' : 'awfb6356a8',
                     'event' : 'render',
                     'class' : 'platform.handlers.WorkOfflineHandler',
               }
            ];
            action008.eventHandlers = eventHandlers069;

            var action009 = new Action({
               'overflow' : true,
               'artifactId' : 'PseudoOffline_goOffline',
               'id' : 'aw90309912',
               'label' : MessageService.createStaticMessage('Enable Offline Mode'),
            });
            actions004.addChild( action009 );

            var eventHandlers070 = [
               {
                     'method' : 'toggleOfflineMode',
                     'artifactId' : 'PseudoOffline_enableoffline_action_eventHandlers_click',
                     'id' : 'aw33d3b70c',
                     'event' : 'click',
                     'class' : 'platform.handlers.PseudoOfflineModeHandler',
               }
            ];
            action009.eventHandlers = eventHandlers070;

            var action010 = new Action({
               'overflow' : true,
               'transitionTo' : 'Platform.Settings',
               'artifactId' : 'Settings_action',
               'id' : 'awc0b1927e',
               'label' : MessageService.createStaticMessage('Settings'),
            });
            actions004.addChild( action010 );


            var action011 = new Action({
               'overflow' : true,
               'transitionTo' : 'Platform.HelpAbout',
               'artifactId' : 'About_action',
               'id' : 'aw49fae06b',
               'label' : MessageService.createStaticMessage('About'),
            });
            actions004.addChild( action011 );


            var action012 = new Action({
               'overflow' : true,
               'transitionTo' : 'Platform.LogOutPrompt',
               'artifactId' : 'LogOut_action',
               'id' : 'awd566efa2',
               'label' : MessageService.createStaticMessage('Log Out'),
            });
            actions004.addChild( action012 );


            var action013 = new Action({
               'artifactId' : 'action',
               'id' : 'aw47cc8c92',
            });
            actions004.addChild( action013 );

            var eventHandlers071 = [
               {
                     'artifactId' : 'action_eventHandlers_click',
                     'id' : 'aw871940b2',
                     'event' : 'click',
                     'class' : 'platform.handlers.CreateQueryBaseHandler',
               }
            ];
            action013.eventHandlers = eventHandlers071;

            var erroractions001 = new ErrorActions({
               'artifactId' : 'erroractions',
               'id' : 'aw6a5d95e9',
            });
            ui001.addChild( erroractions001 );


            var action014 = new Action({
               'artifactId' : 'UndoChanges_action',
               'id' : 'aw2236d58a',
               'label' : MessageService.createStaticMessage('Undo Changes'),
            });
            erroractions001.addChild( action014 );

            var eventHandlers072 = [
               {
                     'method' : 'confirmClearChanges',
                     'artifactId' : 'UndoChanges_action_eventHandlers_click_confirmClearChanges',
                     'id' : 'awcf857f5c',
                     'event' : 'click',
                     'class' : 'platform.handlers.WorkOfflineHandler',
               }
            ];
            action014.eventHandlers = eventHandlers072;

            var action015 = new Action({
               'artifactId' : 'ResendChanges_action',
               'id' : 'awccf9e70e',
               'label' : MessageService.createStaticMessage('Resend Changes'),
            });
            erroractions001.addChild( action015 );

            var eventHandlers073 = [
               {
                     'method' : 'retryRecordChanges',
                     'artifactId' : 'ResendChanges_action_eventHandlers_click_retryRecordChanges',
                     'id' : 'aw543ac47e',
                     'event' : 'click',
                     'class' : 'platform.handlers.WorkOfflineHandler',
               }
            ];
            action015.eventHandlers = eventHandlers073;
            var eventHandlers074 = [
               {
                     'method' : 'none',
                     'artifactId' : 'eventHandlers_none_none',
                     'id' : 'aw1e2e7ded',
                     'event' : 'none',
                     'class' : 'platform.handlers.LookupHandler',
               }
            ];
            ui001.eventHandlers = eventHandlers074;

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'Platform.emptyview', false);
               trackTimer.startTracking();
            }

            var view033 = new View({
               'showHeader' : false,
               'id' : 'Platform.emptyview',
               'showFooter' : false,
            });
            ui001.addChild( view033 );

            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'Platform.Notifications', false);
               trackTimer.startTracking();
            }

            var view034 = new View({
               'id' : 'Platform.Notifications',
               'label' : MessageService.createStaticMessage('My Notifications'),
               'fullScreen' : 'true',
            });
            ui001.addChild( view034 );

            var requiredResources038 = {
               'osusernotification' : {
                  'reload' : true,
                  'artifactId' : 'Platform.Notifications_osusernotification',
                  'id' : 'awed6a5e70',
               },
               'PlatformTempPushNotification' : {
                  'reload' : true,
                  'artifactId' : 'Platform.Notifications_PlatformTempPushNotification',
                  'id' : 'aw9993c5cb',
               },
            };
            view034.addRequiredResources( requiredResources038 );


            var listItemTemplate015 = new ListItemTemplate({
               'layout' : 'NotificationList',
               'artifactId' : 'Platform.Notifications_listItemTemplate',
               'id' : 'aw718eb447',
            });

            var listtext045 = new ListText({
               'resourceAttribute' : 'uiDate',
               'layoutInsertAt' : 'date1',
               'artifactId' : 'Platform.Notifications_uiDate',
               'id' : 'aw56b07378',
            });
            listItemTemplate015.addChild( listtext045 );


            var listtext046 = new ListText({
               'resourceAttribute' : 'itemnum',
               'layoutInsertAt' : 'item1',
               'artifactId' : 'Platform.Notifications_itemnum',
               'id' : 'aw4dbbd111',
            });
            listItemTemplate015.addChild( listtext046 );


            var listtext047 = new ListText({
               'resourceAttribute' : 'itemDesc',
               'layoutInsertAt' : 'item2',
               'artifactId' : 'Platform.Notifications_itemDesc',
               'id' : 'aw6bac97b9',
            });
            listItemTemplate015.addChild( listtext047 );

            var eventHandlers075 = [
               {
                     'method' : 'openFromMsgHistory',
                     'artifactId' : 'Platform.Notifications_Open_button_eventHandlers_click_FromList',
                     'id' : 'awf03f57bd',
                     'event' : 'click',
                     'class' : 'platform.handlers.PushNotificationDialogHandler',
               },
               {
                     'method' : 'renderMsgHistoryItem',
                     'artifactId' : 'Platform.Notifications_Open_button_eventHandlers_render_FromList',
                     'id' : 'awfd2341e9',
                     'event' : 'render',
                     'class' : 'platform.handlers.PushNotificationDialogHandler',
               }
            ];
            listItemTemplate015.eventHandlers = eventHandlers075;


            var list015 = new List({
               'resource' : 'osusernotification',
               'listItemTemplate' : listItemTemplate015,
               'artifactId' : 'Platform.Notifications_list',
               'id' : 'awb4916253',
               'label' : MessageService.createStaticMessage('List of notifications'),
            });
            view034.addChild( list015 );

            var eventHandlers076 = [
               {
                     'method' : 'renderMsgHistory',
                     'artifactId' : 'Platform.Notifications_eventHandlers_render_FromList',
                     'id' : 'awa8aedc90',
                     'event' : 'render',
                     'class' : 'platform.handlers.PushNotificationDialogHandler',
               }
            ];
            view034.eventHandlers = eventHandlers076;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            var dialog008 = new Dialog({
               'cssClass' : 'dialogDateTimeLookup',
               'resource' : 'PlatformDateLookupResource',
               'id' : 'Platform.DateTimeLookup',
               'label' : MessageService.createStaticMessage('Change Time or Date'),
            });
            ui001.addChild( dialog008 );

            var eventHandlers077 = [
               {
                     'method' : 'initLookup',
                     'artifactId' : 'Platform.DateTimeLookup_eventHandlers_show_initLookup',
                     'id' : 'aw576c44ec',
                     'event' : 'show',
                     'class' : 'platform.handlers.LookupHandler',
               }
            ];
            dialog008.eventHandlers = eventHandlers077;

            var container044 = new Container({
               'artifactId' : 'Platform.DateTimeLookup_container_0',
               'id' : 'aw3cdb37d7',
            });
            dialog008.addChild( container044 );


            var datetimepicker001 = new DateTimePicker({
               'artifactId' : 'Platform.DateTimeLookup_datetimepicker_0',
               'id' : 'aw7d2f0e0d',
            });
            container044.addChild( datetimepicker001 );


            var container045 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.DateTimeLookup_container_1',
               'id' : 'aw4bdc0741',
            });
            dialog008.addChild( container045 );


            var button034 = new Button({
               'artifactId' : 'Platform.DateTimeLookup_Cancel_button',
               'id' : 'aw54d2f1bb',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers078 = [
               {
                     'method' : 'Cancel',
                     'artifactId' : 'Platform.DateTimeLookup_Cancel_button_eventHandlers_click_Cancel',
                     'id' : 'aw5ced0c47',
                     'event' : 'click',
                     'class' : 'platform.handlers.LookupHandler',
               }
            ];
            button034.eventHandlers = eventHandlers078;
            container045.addChild( button034 );


            var button035 = new Button({
               'artifactId' : 'Platform.DateTimeLookup_Clear_button',
               'id' : 'awfd1238bd',
               'label' : MessageService.createStaticMessage('Clear'),
            });
            var eventHandlers079 = [
               {
                     'method' : 'Clear',
                     'artifactId' : 'Platform.DateTimeLookup_Clear_button_eventHandlers_click_Clear',
                     'id' : 'aw47510f1f',
                     'event' : 'click',
                     'class' : 'platform.handlers.LookupHandler',
               }
            ];
            button035.eventHandlers = eventHandlers079;
            container045.addChild( button035 );


            var button036 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'Platform.DateTimeLookup_OK_button',
               'id' : 'awb1e0d280',
               'label' : MessageService.createStaticMessage('OK'),
               'primary' : 'true',
            });
            var eventHandlers080 = [
               {
                     'method' : 'SetSelection',
                     'artifactId' : 'Platform.DateTimeLookup_OK_button_eventHandlers_click_SetSelection',
                     'id' : 'aw6c08b2ff',
                     'event' : 'click',
                     'class' : 'platform.handlers.LookupHandler',
               }
            ];
            button036.eventHandlers = eventHandlers080;
            container045.addChild( button036 );


            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'Platform.HelpAbout', false);
               trackTimer.startTracking();
            }

            var view035 = new View({
               'resource' : 'PlatformLoginResource',
               'id' : 'Platform.HelpAbout',
               'label' : MessageService.createStaticMessage('About'),
               'fullScreen' : 'true',
            });
            ui001.addChild( view035 );


            var container046 = new Container({
               'cssClass' : 'platformHelpAboutContainer',
               'artifactId' : 'Platform.HelpAbout_container_0',
               'id' : 'awf8c0259e',
            });
            view035.addChild( container046 );


            var image003 = new Image({
               'image' : 'ibmLogoDark.svg',
               'artifactId' : 'Platform.HelpAbout_image_0',
               'id' : 'awfebf608a',
            });
            container046.addChild( image003 );


            var text163 = new Text({
               'resourceAttribute' : 'appName',
               'cssClass' : 'productName bold textappearance-large',
               'editable' : false,
               'artifactId' : 'Platform.HelpAbout_container_0_appName',
               'id' : 'aw27632fa8',
            });
            container046.addChild( text163 );


            var text164 = new Text({
               'cssClass' : 'version',
               'editable' : false,
               'artifactId' : 'Platform.HelpAbout_container_0_Version7.5.2.1',
               'id' : 'awf060501a',
               'value' : MessageService.createStaticMessage('Version 7.6.4.0'),
            });
            container046.addChild( text164 );


            var text165 = new Text({
               'cssClass' : 'build',
               'editable' : false,
               'artifactId' : 'Platform.HelpAbout_container_0_Buildnumberbuild',
               'id' : 'awd289f042',
               'value' : MessageService.createStaticMessage('Build number @build@'),
            });
            container046.addChild( text165 );


            var text166 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.HelpAbout_container_0_LicensedMaterials-',
               'id' : 'aw31046f88',
               'value' : MessageService.createStaticMessage('Licensed Materials - Property of IBM. \u00A9IBM Corp. 2020. IBM, the IBM logo, and ibm.com are trademarks of IBM Corp., registered in many jurisdictions worldwide. Other product and service names might be trademarks of IBM or other companies. A current list of IBM trademarks is available on the Web at www.ibm.com\/legal\/copytrade.shtml. This Program is licensed under the terms of the license agreement for the Program. Please read this agreement carefully before using the Program. By using the Program, you agree to these terms.'),
            });
            container046.addChild( text166 );


            var group039 = new Group({
               'debugOnly' : 'true',
               'artifactId' : 'Platform.Settings_group_2',
               'id' : 'awc5ac5572',
            });
            container046.addChild( group039 );


            var groupitem126 = new GroupItem({
               'layout' : 'ScreenInfo',
               'cssClass' : 'screenInfo',
               'artifactId' : 'Platform.Settings_screenInfo_item',
               'id' : 'aw5de3d82',
            });
            group039.addChild( groupitem126 );


            var text167 = new Text({
               'cssClass' : 'textappearance-large',
               'layoutInsertAt' : 'title',
               'artifactId' : 'Platform.Settings_screenInfo_title',
               'id' : 'awd295621c',
               'value' : MessageService.createStaticMessage('Screen Information'),
            });
            groupitem126.addChild( text167 );


            var text168 = new Text({
               'resourceAttribute' : 'ppi',
               'resource' : 'DeviceSizeResource',
               'editable' : false,
               'layoutInsertAt' : 'pixels',
               'artifactId' : 'Platform.Settings_screenInfo_ppi_text',
               'id' : 'aw4219624',
               'label' : MessageService.createStaticMessage('PPI'),
            });
            groupitem126.addChild( text168 );


            var text169 = new Text({
               'resourceAttribute' : 'width',
               'resource' : 'DeviceSizeResource',
               'editable' : false,
               'layoutInsertAt' : 'width',
               'artifactId' : 'Platform.Settings_screenInfo_width_text',
               'id' : 'aw6564040e',
               'label' : MessageService.createStaticMessage('Width'),
            });
            groupitem126.addChild( text169 );


            var text170 = new Text({
               'resourceAttribute' : 'height',
               'resource' : 'DeviceSizeResource',
               'editable' : false,
               'layoutInsertAt' : 'height',
               'artifactId' : 'Platform.Settings_screenInfo_height_text',
               'id' : 'awcd6ab682',
               'label' : MessageService.createStaticMessage('Height'),
            });
            groupitem126.addChild( text170 );


            var text171 = new Text({
               'resourceAttribute' : 'layoutSize',
               'resource' : 'DeviceSizeResource',
               'editable' : false,
               'layoutInsertAt' : 'size',
               'artifactId' : 'Platform.Settings_screenInfo_layout_text',
               'id' : 'awd74c1b0',
               'label' : MessageService.createStaticMessage('Layout Size'),
            });
            groupitem126.addChild( text171 );


            var text172 = new Text({
               'resourceAttribute' : 'orientation',
               'resource' : 'DeviceSizeResource',
               'editable' : false,
               'layoutInsertAt' : 'orientation',
               'artifactId' : 'Platform.Settings_screenInfo_orientation_text',
               'id' : 'aw22df9e6f',
               'label' : MessageService.createStaticMessage('Orientation'),
            });
            groupitem126.addChild( text172 );


            var text173 = new Text({
               'resourceAttribute' : 'density',
               'resource' : 'DeviceSizeResource',
               'editable' : false,
               'layoutInsertAt' : 'density',
               'artifactId' : 'Platform.Settings_screenInfo_density_text',
               'id' : 'aw6b4b20e2',
               'label' : MessageService.createStaticMessage('Density'),
            });
            groupitem126.addChild( text173 );


            var text174 = new Text({
               'resourceAttribute' : 'pane0_layoutSize',
               'resource' : 'DeviceSizeResource',
               'editable' : false,
               'layoutInsertAt' : 'pane0',
               'artifactId' : 'Platform.Settings_screenInfo_pane0',
               'id' : 'aw39d3d4a7',
               'label' : MessageService.createStaticMessage('Pane 1 Size'),
            });
            groupitem126.addChild( text174 );


            var text175 = new Text({
               'resourceAttribute' : 'pane1_layoutSize',
               'resource' : 'DeviceSizeResource',
               'editable' : false,
               'layoutInsertAt' : 'pane1',
               'artifactId' : 'Platform.Settings_screenInfo_pane1',
               'id' : 'aw4ed4e431',
               'label' : MessageService.createStaticMessage('Pane 2 Size'),
            });
            groupitem126.addChild( text175 );

            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'Platform.Settings', false);
               trackTimer.startTracking();
            }

            var view036 = new View({
               'id' : 'Platform.Settings',
               'label' : MessageService.createStaticMessage('Settings'),
               'fullScreen' : 'true',
            });
            ui001.addChild( view036 );

            var requiredResources039 = {
               'LastADDownload' : {
                  'artifactId' : 'Platform.Settings_LastADDownload',
                  'id' : 'aw879343e2',
               },
            };
            view036.addRequiredResources( requiredResources039 );

            var actions005 = new Actions({
               'artifactId' : 'Platform.Settings_actions',
               'id' : 'awb3f56d3b',
            });
            view036.addChild( actions005 );


            var action016 = new Action({
               'overflow' : true,
               'artifactId' : 'Platform.Settings_RefreshSystemData_action',
               'id' : 'awccb0ee65',
               'label' : MessageService.createStaticMessage('Refresh System Data'),
            });
            actions005.addChild( action016 );

            var eventHandlers081 = [
               {
                     'method' : 'openDownloadSystemDataDialog',
                     'artifactId' : 'Platform.Settings_RefreshSystemData_action_eventHandlers_click_downloadSystemData',
                     'id' : 'aw490b2801',
                     'event' : 'click',
                     'class' : 'platform.handlers.SettingsHandler',
               },
               {
                     'method' : 'renderDownloadSytemDataActionButton',
                     'artifactId' : 'Platform.Settings_RefreshSystemData_action_eventHandlers_render_renderDownloadSytemDataActionButton',
                     'id' : 'awa42bdfcc',
                     'event' : 'render',
                     'class' : 'platform.handlers.SettingsHandler',
               }
            ];
            action016.eventHandlers = eventHandlers081;

            var container047 = new Container({
               'resource' : 'LastADDownload',
               'artifactId' : 'Platform.Settings_container_0',
               'id' : 'aw74ff68b5',
            });
            view036.addChild( container047 );


            var group040 = new Group({
               'artifactId' : 'Platform.Settings_group_0',
               'id' : 'aw2ba2345e',
            });
            container047.addChild( group040 );


            var groupitem127 = new GroupItem({
               'transitionTo' : 'Platform.ChangePassword',
               'artifactId' : 'Platform.Settings_LastADDownload_groupitem_Platform.ChangePassword_0',
               'id' : 'awd48342a3',
            });
            group040.addChild( groupitem127 );


            var text176 = new Text({
               'cssClass' : 'relatedRecords',
               'artifactId' : 'Platform.Settings_LastADDownload_groupitem_Platform.ChangePassword_0_ChangePassword',
               'id' : 'aw6c14924a',
               'value' : MessageService.createStaticMessage('Change Password'),
            });
            groupitem127.addChild( text176 );

            var eventHandlers082 = [
               {
                     'method' : 'enableChangePasswordFunction',
                     'artifactId' : 'Platform.Settings_LastADDownload_groupitem_Platform.ChangePassword_0_eventHandlers_render_enableChangePasswordFunction',
                     'id' : 'awa81f4a5',
                     'event' : 'render',
                     'class' : 'platform.handlers.ChangePasswordHandler',
               }
            ];
            groupitem127.eventHandlers = eventHandlers082;

            var groupitem128 = new GroupItem({
               'artifactId' : 'Platform.Settings_LastADDownload_groupitem_0',
               'id' : 'aw82635ebb',
            });
            group040.addChild( groupitem128 );


            var text177 = new Text({
               'cssClass' : 'relatedRecords',
               'artifactId' : 'Platform.Settings_LastADDownload_groupitem_0_RefreshLookupData',
               'id' : 'awcddf2167',
               'value' : MessageService.createStaticMessage('Refresh Lookup Data'),
            });
            groupitem128.addChild( text177 );


            var text178 = new Text({
               'resourceAttribute' : 'downloadStatus',
               'editable' : false,
               'artifactId' : 'Platform.Settings_LastADDownload_groupitem_0_downloadStatus',
               'id' : 'aw8a1673e3',
            });
            groupitem128.addChild( text178 );

            var eventHandlers083 = [
               {
                     'method' : 'renderLastDownload',
                     'artifactId' : 'Platform.Settings_LastADDownload_groupitem_0_downloadStatus_eventHandlers_render_renderLastDownload',
                     'id' : 'aw72547fb7',
                     'event' : 'render',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               }
            ];
            text178.eventHandlers = eventHandlers083;

            var text179 = new Text({
               'cssClass' : 'textappearance-small',
               'editable' : false,
               'artifactId' : 'Platform.Settings_LastADDownload_groupitem_0_Updatesthelookupd',
               'id' : 'aw38a24bec',
               'value' : MessageService.createStaticMessage('Updates the lookup data on your device. Lookup data includes objects, such as assets and locations, that can be added to records.'),
            });
            groupitem128.addChild( text179 );

            var eventHandlers084 = [
               {
                     'method' : 'refreshAdditionalData',
                     'artifactId' : 'Platform.Settings_LastADDownload_groupitem_0_eventHandlers_click_refreshAdditionalData',
                     'id' : 'aw93ad06fe',
                     'event' : 'click',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               }
            ];
            groupitem128.eventHandlers = eventHandlers084;

            var groupitem129 = new GroupItem({
               'artifactId' : 'Platform.Settings_LastADDownload_groupitem_3_Number_of_day_to_sync',
               'id' : 'aw97e66cd6',
            });
            group040.addChild( groupitem129 );


            var text180 = new Text({
               'resourceAttribute' : 'numberOfDaysToSync',
               'editable' : true,
               'artifactId' : 'Platform.Settings_LastADDownload_text_Number_of_day_to_sync',
               'id' : 'aw69a517e3',
               'label' : MessageService.createStaticMessage('How often changes need to be refresh in days:'),
            });
            groupitem129.addChild( text180 );

            var eventHandlers085 = [
               {
                     'method' : 'renderDayToSYnc',
                     'artifactId' : 'Platform.Settings_LastADDownload_text_Number_of_day_to_sync_eventHandlers_renderDayToSYnc',
                     'id' : 'awdc11c959',
                     'event' : 'render',
                     'class' : 'platform.handlers.SettingsHandler',
               },
               {
                     'method' : 'saveDayToSync',
                     'artifactId' : 'Platform.Settings_LastADDownload_text_Number_of_day_to_sync_eventHandlers_saveDayToSYnc',
                     'id' : 'aw57729721',
                     'event' : 'validate',
                     'class' : 'platform.handlers.SettingsHandler',
               }
            ];
            text180.eventHandlers = eventHandlers085;

            var groupitem130 = new GroupItem({
               'transitionTo' : 'Platform.AdvancedSettings',
               'artifactId' : 'Platform.Settings_LastADDownload_groupitem_Platform.AdvancedSettings_0',
               'id' : 'aw741c4d60',
            });
            group040.addChild( groupitem130 );


            var text181 = new Text({
               'cssClass' : 'relatedRecords',
               'artifactId' : 'Platform.Settings_LastADDownload_groupitem_Platform.AdvancedSettings_0_AdvancedSettings',
               'id' : 'aw2d662633',
               'value' : MessageService.createStaticMessage('Advanced Settings'),
            });
            groupitem130.addChild( text181 );


            var container048 = new Container({
               'artifactId' : 'ConnectionContainer',
               'id' : 'awef0b2658',
            });
            view036.addChild( container048 );


            var group041 = new Group({
               'artifactId' : 'Platform.Settings.ConnectionManagement.group',
               'id' : 'aw9ad5002d',
            });
            container048.addChild( group041 );


            var groupitem131 = new GroupItem({
               'layout' : 'ConnectionManagementLayout',
               'artifactId' : 'Platform.Settings.ConnectionManagement.groupItem1',
               'id' : 'aw81b0980b',
            });
            group041.addChild( groupitem131 );


            var text182 = new Text({
               'cssClass' : 'relatedRecords',
               'layoutInsertAt' : 'Title',
               'artifactId' : 'Platform.Settings.ConnectionManagement.Title',
               'id' : 'aw1de21387',
               'value' : MessageService.createStaticMessage('Connection Behavior'),
            });
            groupitem131.addChild( text182 );


            var text183 = new Text({
               'cssClass' : 'wrap-content',
               'layoutInsertAt' : 'description',
               'artifactId' : 'Platform.Settings.ConnectionManagement.Description',
               'id' : 'aw6b506a6f',
               'value' : MessageService.createStaticMessage('Specifies which network connections should enable the application to work online'),
            });
            groupitem131.addChild( text183 );


            var radiobutton001 = new RadioButton({
               'cssClass' : 'firstradiobutton',
               'name' : 'Connectiongrp',
               'layoutInsertAt' : 'button1',
               'artifactId' : 'Platform.Settings.ConnectionManagement.Button.AllConnections',
               'id' : 'awcb83aecb',
               'label' : MessageService.createStaticMessage('All Types'),
            });
            groupitem131.addChild( radiobutton001 );

            var eventHandlers086 = [
               {
                     'method' : 'renderConnetionManagementSetting',
                     'artifactId' : 'Platform.Settings.ConnectionManagement.AllConnection.EventHandler1',
                     'id' : 'awe9d7776d',
                     'event' : 'render',
                     'class' : 'platform.handlers.SettingsHandler',
               },
               {
                     'method' : 'connetionManagementSetting',
                     'artifactId' : 'Platform.Settings.allCOnnection.click.EventHandler',
                     'id' : 'aw76203443',
                     'event' : 'click',
                     'class' : 'platform.handlers.SettingsHandler',
               }
            ];
            radiobutton001.eventHandlers = eventHandlers086;

            var radiobutton002 = new RadioButton({
               'name' : 'Connectiongrp',
               'layoutInsertAt' : 'button2',
               'artifactId' : 'Platform.Settings.ConnectionManagement.Button.WiFi',
               'id' : 'aw42dec2bb',
               'label' : MessageService.createStaticMessage('Only WiFi'),
            });
            groupitem131.addChild( radiobutton002 );

            var eventHandlers087 = [
               {
                     'method' : 'renderConnetionManagementSetting',
                     'artifactId' : 'Platform.Settings.ConnectionManagement.AllConnection.EventHandler2',
                     'id' : 'aw70de26d7',
                     'event' : 'render',
                     'class' : 'platform.handlers.SettingsHandler',
               },
               {
                     'method' : 'connetionManagementSetting',
                     'artifactId' : 'Platform.Settings.WiFi.click.EventHandler',
                     'id' : 'aw183e4c0c',
                     'event' : 'click',
                     'class' : 'platform.handlers.SettingsHandler',
               }
            ];
            radiobutton002.eventHandlers = eventHandlers087;

            var radiobutton003 = new RadioButton({
               'name' : 'Connectiongrp',
               'layoutInsertAt' : 'button3',
               'artifactId' : 'Platform.Settings.ConnectionManagement.Button.Cellular',
               'id' : 'aw7032481d',
               'label' : MessageService.createStaticMessage('Only Cellular'),
            });
            groupitem131.addChild( radiobutton003 );

            var eventHandlers088 = [
               {
                     'method' : 'renderConnetionManagementSetting',
                     'artifactId' : 'Platform.Settings.ConnectionManagement.AllConnection.EventHandler3',
                     'id' : 'aw7d91641',
                     'event' : 'render',
                     'class' : 'platform.handlers.SettingsHandler',
               },
               {
                     'method' : 'connetionManagementSetting',
                     'artifactId' : 'Platform.Settings.ConnectionManagement.Cellular.EventHandler',
                     'id' : 'aw2a978e73',
                     'event' : 'click',
                     'class' : 'platform.handlers.SettingsHandler',
               }
            ];
            radiobutton003.eventHandlers = eventHandlers088;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'Platform.AdvancedSettings', false);
               trackTimer.startTracking();
            }

            var view037 = new View({
               'id' : 'Platform.AdvancedSettings',
               'label' : MessageService.createStaticMessage('Settings'),
            });
            ui001.addChild( view037 );


            var container049 = new Container({
               'artifactId' : 'Platform.AdvancedSettings_container_0',
               'id' : 'aw5c13274d',
            });
            view037.addChild( container049 );


            var group042 = new Group({
               'artifactId' : 'Platform.AdvancedSettings_group_0',
               'id' : 'awebdfb82c',
            });
            container049.addChild( group042 );


            var groupitem132 = new GroupItem({
               'transitionTo' : 'Platform.TimeTrackReport',
               'artifactId' : 'Platform.AdvancedSettings_groupitem_Platform.TimeTrackReport_0',
               'id' : 'awba4384a8',
            });
            group042.addChild( groupitem132 );


            var text184 = new Text({
               'cssClass' : 'relatedRecords',
               'artifactId' : 'Platform.AdvancedSettings_groupitem_Platform.TimeTrackReport_0_TrackPerformanceDa',
               'id' : 'awc0a6dde7',
               'value' : MessageService.createStaticMessage('Track Performance Data'),
            });
            groupitem132.addChild( text184 );


            var text185 = new Text({
               'cssClass' : 'red-text',
               'editable' : false,
               'artifactId' : 'Platform.AdvancedSettings_groupitem_Platform.TimeTrackReport_0_Thisoptionusesmem',
               'id' : 'aw4367e95f',
               'value' : MessageService.createStaticMessage('This option uses memory and might slow the performance of your device. Disable performance tracking when you are done.'),
            });
            groupitem132.addChild( text185 );


            var groupitem133 = new GroupItem({
               'transitionTo' : 'Platform.LoggerReport',
               'artifactId' : 'Platform.AdvancedSettings_groupitem_Platform.LoggerReport_0',
               'id' : 'aw10ca73e0',
            });
            group042.addChild( groupitem133 );


            var text186 = new Text({
               'cssClass' : 'relatedRecords',
               'artifactId' : 'Platform.AdvancedSettings_groupitem_Platform.LoggerReport_0_Logging',
               'id' : 'awffa3ff9c',
               'value' : MessageService.createStaticMessage('Logging'),
            });
            groupitem133.addChild( text186 );


            var text187 = new Text({
               'cssClass' : 'red-text',
               'editable' : false,
               'artifactId' : 'Platform.AdvancedSettings_groupitem_Platform.LoggerReport_0_Thisoptionusesmem',
               'id' : 'aw30da1efa',
               'value' : MessageService.createStaticMessage('This option uses memory and might slow the performance of your device. Disable logging when you are done.'),
            });
            groupitem133.addChild( text187 );

            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'Platform.LoggerReport', false);
               trackTimer.startTracking();
            }

            var view038 = new View({
               'cssClass' : 'loggerReport',
               'scrollDir' : 'vh',
               'id' : 'Platform.LoggerReport',
               'label' : MessageService.createStaticMessage('Logging Data'),
            });
            ui001.addChild( view038 );


            var actions006 = new Actions({
               'artifactId' : 'Platform.LoggerReport_actions',
               'id' : 'aw5b090344',
            });
            view038.addChild( actions006 );


            var action017 = new Action({
               'overflow' : true,
               'artifactId' : 'Platform.LoggerReport_EnableErrorLogging_action',
               'id' : 'awc05e82b4',
               'label' : MessageService.createStaticMessage('Enable Error Logging'),
            });
            actions006.addChild( action017 );

            var eventHandlers089 = [
               {
                     'method' : 'enableDisableLoggerErro',
                     'artifactId' : 'Platform.LoggerReport_EnableErrorLogging_action_eventHandlers_click_enableDisableLoggerErro',
                     'id' : 'awf5ad7151',
                     'event' : 'click',
                     'class' : 'platform.logging.handler.LoggerReportHandler',
               },
               {
                     'method' : 'setLabelError',
                     'artifactId' : 'Platform.LoggerReport_EnableErrorLogging_action_eventHandlers_render_setLabelError',
                     'id' : 'aw4faa4e07',
                     'event' : 'render',
                     'class' : 'platform.logging.handler.LoggerReportHandler',
               }
            ];
            action017.eventHandlers = eventHandlers089;

            var action018 = new Action({
               'overflow' : true,
               'artifactId' : 'Platform.LoggerReport_EnableInfoLogging_action',
               'id' : 'aw6d618335',
               'label' : MessageService.createStaticMessage('Enable Info Logging'),
            });
            actions006.addChild( action018 );

            var eventHandlers090 = [
               {
                     'method' : 'enableDisableLoggerInfo',
                     'artifactId' : 'Platform.LoggerReport_EnableInfoLogging_action_eventHandlers_click_enableDisableLoggerInfo',
                     'id' : 'aw164710f9',
                     'event' : 'click',
                     'class' : 'platform.logging.handler.LoggerReportHandler',
               },
               {
                     'method' : 'setLabelInfo',
                     'artifactId' : 'Platform.LoggerReport_EnableInfoLogging_action_eventHandlers_render_setLabelInfo',
                     'id' : 'awc8b2e890',
                     'event' : 'render',
                     'class' : 'platform.logging.handler.LoggerReportHandler',
               }
            ];
            action018.eventHandlers = eventHandlers090;

            var action019 = new Action({
               'overflow' : true,
               'artifactId' : 'Platform.LoggerReport_EnableDebugLogging_action',
               'id' : 'awaa11689b',
               'label' : MessageService.createStaticMessage('Enable Debug Logging'),
            });
            actions006.addChild( action019 );

            var eventHandlers091 = [
               {
                     'method' : 'enableDisableLoggerDebug',
                     'artifactId' : 'Platform.LoggerReport_EnableDebugLogging_action_eventHandlers_click_enableDisableLoggerDebug',
                     'id' : 'aw49ea32aa',
                     'event' : 'click',
                     'class' : 'platform.logging.handler.LoggerReportHandler',
               },
               {
                     'method' : 'setLabelDebug',
                     'artifactId' : 'Platform.LoggerReport_EnableDebugLogging_action_eventHandlers_render_setLabelDebug',
                     'id' : 'aw1cc86c8a',
                     'event' : 'render',
                     'class' : 'platform.logging.handler.LoggerReportHandler',
               }
            ];
            action019.eventHandlers = eventHandlers091;

            var action020 = new Action({
               'overflow' : true,
               'transitionTo' : 'Platform.TransLoggerReport',
               'artifactId' : 'Platform.LoggerReport_ViewTransactionLog_action',
               'id' : 'awdaed3d40',
               'label' : MessageService.createStaticMessage('View Transaction Log'),
            });
            actions006.addChild( action020 );


            var action021 = new Action({
               'overflow' : true,
               'artifactId' : 'Platform.LoggerReport_ClearLogData_action',
               'id' : 'awb6d3895c',
               'label' : MessageService.createStaticMessage('Clear Log Data'),
            });
            actions006.addChild( action021 );

            var eventHandlers092 = [
               {
                     'method' : 'clear',
                     'artifactId' : 'Platform.LoggerReport_ClearLogData_action_eventHandlers_click_clear',
                     'id' : 'aw10958c5',
                     'event' : 'click',
                     'class' : 'platform.logging.handler.LoggerReportHandler',
               }
            ];
            action021.eventHandlers = eventHandlers092;

            var action022 = new Action({
               'overflow' : true,
               'artifactId' : 'Platform.LoggerReport_UploadLog_action',
               'id' : 'aw7510fce3',
               'label' : MessageService.createStaticMessage('Save Log'),
            });
            actions006.addChild( action022 );

            var eventHandlers093 = [
               {
                     'method' : 'showIfConnected',
                     'artifactId' : 'Platform.LoggerReport_UploadLog_action_eventHandlers_render_uploadCurrent',
                     'id' : 'aw4d53a4f5',
                     'event' : 'render',
                     'class' : 'platform.logging.handler.LoggerReportHandler',
               },
               {
                     'method' : 'uploadCurrent',
                     'artifactId' : 'Platform.LoggerReport_UploadLog_action_eventHandlers_click_uploadCurrent',
                     'id' : 'aw2b172289',
                     'event' : 'click',
                     'class' : 'platform.logging.handler.LoggerReportHandler',
               }
            ];
            action022.eventHandlers = eventHandlers093;

            var action023 = new Action({
               'overflow' : true,
               'artifactId' : 'Platform.LoggerReport_EmailLog_action',
               'id' : 'aw90d8a401',
               'label' : MessageService.createStaticMessage('Email Log'),
            });
            actions006.addChild( action023 );

            var eventHandlers094 = [
               {
                     'method' : 'emailCurrent',
                     'artifactId' : 'Platform.LoggerReport_EmailLog_action_eventHandlers_click_emailCurrent',
                     'id' : 'awf10881b9',
                     'event' : 'click',
                     'class' : 'platform.logging.handler.LoggerReportHandler',
               }
            ];
            action023.eventHandlers = eventHandlers094;
            var eventHandlers095 = [
               {
                     'method' : 'renderLoggerReport',
                     'artifactId' : 'Platform.LoggerReport_eventHandlers_show_renderLoggerReport',
                     'id' : 'aw9b7c5c73',
                     'event' : 'show',
                     'class' : 'platform.logging.handler.LoggerReportHandler',
               }
            ];
            view038.eventHandlers = eventHandlers095;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'Platform.TransLoggerReport', false);
               trackTimer.startTracking();
            }

            var view039 = new View({
               'scrollDir' : 'vh',
               'id' : 'Platform.TransLoggerReport',
               'label' : MessageService.createStaticMessage('Logging Data'),
            });
            ui001.addChild( view039 );


            var actions007 = new Actions({
               'artifactId' : 'Platform.TransLoggerReport_actions',
               'id' : 'aw49b00040',
            });
            view039.addChild( actions007 );


            var action024 = new Action({
               'overflow' : true,
               'artifactId' : 'Platform.TransLoggerReport_ClearLogData_action',
               'id' : 'awdce21e26',
               'label' : MessageService.createStaticMessage('Clear Log Data'),
            });
            actions007.addChild( action024 );

            var eventHandlers096 = [
               {
                     'method' : 'clearTransLog',
                     'artifactId' : 'Platform.TransLoggerReport_ClearLogData_action_eventHandlers_click_clear',
                     'id' : 'aw71c2398e',
                     'event' : 'click',
                     'class' : 'platform.logging.handler.LoggerReportHandler',
               }
            ];
            action024.eventHandlers = eventHandlers096;

            var action025 = new Action({
               'overflow' : true,
               'artifactId' : 'Platform.TransLoggerReport_EmailLog_action',
               'id' : 'aw29f3639',
               'label' : MessageService.createStaticMessage('Email Log'),
            });
            actions007.addChild( action025 );

            var eventHandlers097 = [
               {
                     'method' : 'emailCurrentTranslog',
                     'artifactId' : 'Platform.TransLoggerReport_EmailLog_action_eventHandlers_click_emailCurrent',
                     'id' : 'awfd97a236',
                     'event' : 'click',
                     'class' : 'platform.logging.handler.LoggerReportHandler',
               }
            ];
            action025.eventHandlers = eventHandlers097;
            var eventHandlers098 = [
               {
                     'method' : 'renderTransLoggerReport',
                     'artifactId' : 'Platform.TransLoggerReport_eventHandlers_show_renderTransLoggerReport',
                     'id' : 'aw4261a98a',
                     'event' : 'show',
                     'class' : 'platform.logging.handler.LoggerReportHandler',
               }
            ];
            view039.eventHandlers = eventHandlers098;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'Platform.ChangePassword', false);
               trackTimer.startTracking();
            }

            var view040 = new View({
               'resource' : 'PlatformChangePasswordForm',
               'id' : 'Platform.ChangePassword',
               'label' : MessageService.createStaticMessage('Change Password'),
            });
            ui001.addChild( view040 );


            var container050 = new Container({
               'cssClass' : 'changePasswordForm',
               'artifactId' : 'Platform.ChangePassword_container_0',
               'id' : 'awf7c2a2a',
            });
            view040.addChild( container050 );


            var text188 = new Text({
               'resourceAttribute' : 'errorMsg',
               'cssClass' : 'errorMsg',
               'editable' : false,
               'artifactId' : 'Platform.ChangePassword_container_0_errorMsg',
               'id' : 'aw3ed16fe1',
            });
            container050.addChild( text188 );


            var text189 = new Text({
               'resourceAttribute' : 'infoMsg',
               'cssClass' : 'infoMsg',
               'editable' : false,
               'artifactId' : 'Platform.ChangePassword_container_0_infoMsg',
               'id' : 'awe28ebedd',
            });
            container050.addChild( text189 );


            var text190 = new Text({
               'border' : 'true',
               'resourceAttribute' : 'currentpassword',
               'editable' : true,
               'artifactId' : 'Platform.ChangePassword_container_0_currentpassword',
               'id' : 'aw7df0b045',
               'type' : 'password',
               'placeHolder' : MessageService.createStaticMessage('Current password'),
            });
            container050.addChild( text190 );

            var eventHandlers099 = [
               {
                     'method' : 'hidePasswordField',
                     'artifactId' : 'Platform.ChangePassword_container_0_currentpassword_eventHandlers_render_hidePasswordField',
                     'id' : 'aw27f3eacb',
                     'event' : 'render',
                     'class' : 'platform.handlers.ChangePasswordHandler',
               }
            ];
            text190.eventHandlers = eventHandlers099;

            var text191 = new Text({
               'border' : 'true',
               'resourceAttribute' : 'newpassword',
               'editable' : true,
               'artifactId' : 'Platform.ChangePassword_container_0_newpassword',
               'id' : 'aw618d08b5',
               'type' : 'password',
               'placeHolder' : MessageService.createStaticMessage('New password'),
            });
            container050.addChild( text191 );


            var text192 = new Text({
               'border' : 'true',
               'resourceAttribute' : 'confirmnewpassword',
               'editable' : true,
               'artifactId' : 'Platform.ChangePassword_container_0_confirmnewpassword',
               'id' : 'awd274537a',
               'type' : 'password',
               'placeHolder' : MessageService.createStaticMessage('Confirm password'),
            });
            container050.addChild( text192 );


            var button037 = new Button({
               'artifactId' : 'Platform.ChangePassword_Cancel_button',
               'id' : 'aw96c63135',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers100 = [
               {
                     'method' : 'cancelPasswordClickHandler',
                     'artifactId' : 'Platform.ChangePassword_Cancel_button_eventHandlers_click_cancelPasswordClickHandler',
                     'id' : 'aw7492b621',
                     'event' : 'click',
                     'class' : 'platform.handlers.ChangePasswordHandler',
               }
            ];
            button037.eventHandlers = eventHandlers100;
            container050.addChild( button037 );


            var button038 = new Button({
               'artifactId' : 'Platform.ChangePassword_Change_button',
               'id' : 'aw5cd0477f',
               'label' : MessageService.createStaticMessage('Change'),
               'primary' : 'true',
            });
            var eventHandlers101 = [
               {
                     'method' : 'changePasswordClickHandler',
                     'artifactId' : 'Platform.ChangePassword_Change_button_eventHandlers_click_changePasswordClickHandler',
                     'id' : 'awfdba8feb',
                     'event' : 'click',
                     'class' : 'platform.handlers.ChangePasswordHandler',
               }
            ];
            button038.eventHandlers = eventHandlers101;
            container050.addChild( button038 );

            var eventHandlers102 = [
               {
                     'method' : 'initializeChangePasswordView',
                     'artifactId' : 'Platform.ChangePassword_eventHandlers_show_initializeChangePasswordView',
                     'id' : 'awbbd173b',
                     'event' : 'show',
                     'class' : 'platform.handlers.ChangePasswordHandler',
               },
               {
                     'method' : 'changePasswordBack',
                     'artifactId' : 'Platform.ChangePassword_eventHandlers_back_changePasswordBack',
                     'id' : 'awc25c9010',
                     'event' : 'back',
                     'class' : 'platform.handlers.ChangePasswordHandler',
               }
            ];
            view040.eventHandlers = eventHandlers102;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'Platform.RetrieveOldPassword', false);
               trackTimer.startTracking();
            }

            var view041 = new View({
               'resource' : 'PlatformChangePasswordForm',
               'showHeader' : false,
               'showOverflow' : false,
               'id' : 'Platform.RetrieveOldPassword',
               'label' : MessageService.createStaticMessage('Recover App Data'),
            });
            ui001.addChild( view041 );


            var container051 = new Container({
               'cssClass' : 'changePasswordForm',
               'artifactId' : 'Platform.RetrieveOldPassword_container_0',
               'id' : 'awecdef66d',
            });
            view041.addChild( container051 );


            var text193 = new Text({
               'artifactId' : 'Platform.RetrieveOldPassword_container_0_Enterthepasswordt',
               'id' : 'aw14ebf03b',
               'value' : MessageService.createStaticMessage('Enter the password that you last used to log in to the app. If you do not have this password, you must reset the app before you can log in.'),
            });
            container051.addChild( text193 );


            var text194 = new Text({
               'resourceAttribute' : 'errorMsg',
               'cssClass' : 'errorMsg',
               'editable' : false,
               'artifactId' : 'Platform.RetrieveOldPassword_container_0_errorMsg',
               'id' : 'aw9574c917',
            });
            container051.addChild( text194 );


            var text195 = new Text({
               'border' : 'true',
               'resourceAttribute' : 'currentpassword',
               'editable' : true,
               'artifactId' : 'Platform.RetrieveOldPassword_container_0_currentpassword',
               'id' : 'aw97b6c3b7',
               'type' : 'password',
               'placeHolder' : MessageService.createStaticMessage('Previous password'),
            });
            container051.addChild( text195 );


            var button039 = new Button({
               'artifactId' : 'Platform.RetrieveOldPassword_Recover_button',
               'id' : 'aw3a0ff2',
               'label' : MessageService.createStaticMessage('Recover'),
               'primary' : 'true',
            });
            var eventHandlers103 = [
               {
                     'method' : 'recoverOldPasswordClickHandler',
                     'artifactId' : 'Platform.RetrieveOldPassword_Recover_button_eventHandlers_click_recoverOldPasswordClickHandler',
                     'id' : 'awecb18d1c',
                     'event' : 'click',
                     'class' : 'platform.handlers.ChangePasswordHandler',
               }
            ];
            button039.eventHandlers = eventHandlers103;
            container051.addChild( button039 );


            var button040 = new Button({
               'artifactId' : 'Platform.RetrieveOldPassword_Reset_button',
               'id' : 'aw8bb551dc',
               'label' : MessageService.createStaticMessage('Reset'),
            });
            var eventHandlers104 = [
               {
                     'method' : 'resetStorageClickHandler',
                     'artifactId' : 'Platform.RetrieveOldPassword_Reset_button_eventHandlers_click_resetStorageClickHandler',
                     'id' : 'awfe7a73d2',
                     'event' : 'click',
                     'class' : 'platform.handlers.ChangePasswordHandler',
               }
            ];
            button040.eventHandlers = eventHandlers104;
            container051.addChild( button040 );

            var eventHandlers105 = [
               {
                     'method' : 'initializeRetrieveOldPasswordView',
                     'artifactId' : 'Platform.RetrieveOldPassword_eventHandlers_show_initializeRetrieveOldPasswordView',
                     'id' : 'aw26f17c5a',
                     'event' : 'show',
                     'class' : 'platform.handlers.ChangePasswordHandler',
               }
            ];
            view041.eventHandlers = eventHandlers105;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            var dialog009 = new Dialog({
               'closeOnBackgroundClick' : 'true',
               'id' : 'Platform.ConfirmResetDataStore',
            });
            ui001.addChild( dialog009 );


            var container052 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.ConfirmResetDataStore_container_0',
               'id' : 'awacb7e535',
            });
            dialog009.addChild( container052 );


            var text196 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.ConfirmResetDataStore_container_0_WarningAllappdat',
               'id' : 'aw68bdf3e8',
               'value' : MessageService.createStaticMessage('Warning! All app data on the device will be cleared. Any data that has not been sent to the server will be lost.'),
            });
            container052.addChild( text196 );


            var container053 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.ConfirmResetDataStore_container_1',
               'id' : 'awdbb0d5a3',
            });
            dialog009.addChild( container053 );


            var button041 = new Button({
               'cssClass' : 'dialogButton',
               'artifactId' : 'Platform.ConfirmResetDataStore_Continue_button',
               'id' : 'awba645d10',
               'label' : MessageService.createStaticMessage('Continue'),
            });
            var eventHandlers106 = [
               {
                     'method' : 'resetDataStoreClickHandler',
                     'artifactId' : 'Platform.ConfirmResetDataStore_Continue_button_eventHandlers_click_resetDataStoreClickHandler',
                     'id' : 'aw5074e6c8',
                     'event' : 'click',
                     'class' : 'platform.handlers.ChangePasswordHandler',
               }
            ];
            button041.eventHandlers = eventHandlers106;
            container053.addChild( button041 );


            var button042 = new Button({
               'cssClass' : 'dialogButton',
               'artifactId' : 'Platform.ConfirmResetDataStore_Cancel_button',
               'id' : 'aw50474341',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers107 = [
               {
                     'method' : 'cancelResetDataStoreClickHandler',
                     'artifactId' : 'Platform.ConfirmResetDataStore_Cancel_button_eventHandlers_click_cancelResetDataStoreClickHandler',
                     'id' : 'awda7121b8',
                     'event' : 'click',
                     'class' : 'platform.handlers.ChangePasswordHandler',
               }
            ];
            button042.eventHandlers = eventHandlers107;
            container053.addChild( button042 );


            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'Platform.TimeTrackReport', false);
               trackTimer.startTracking();
            }

            var view042 = new View({
               'cssClass' : 'loggerReport',
               'scrollDir' : 'vh',
               'id' : 'Platform.TimeTrackReport',
               'label' : MessageService.createStaticMessage('Performance Data'),
            });
            ui001.addChild( view042 );

            var requiredResources040 = {
               'timeTrack' : {
                  'artifactId' : 'Platform.TimeTrackReport_timeTrack',
                  'id' : 'aw8d707cee',
               },
            };
            view042.addRequiredResources( requiredResources040 );

            var actions008 = new Actions({
               'artifactId' : 'Platform.TimeTrackReport_actions',
               'id' : 'aw9d9a4864',
            });
            view042.addChild( actions008 );


            var action026 = new Action({
               'overflow' : true,
               'artifactId' : 'Platform.TimeTrackReport_EnablePerformanceTracking_action',
               'id' : 'aw34736a63',
               'label' : MessageService.createStaticMessage('Enable Performance Tracking'),
            });
            actions008.addChild( action026 );

            var eventHandlers108 = [
               {
                     'method' : 'enableDisableTT',
                     'artifactId' : 'Platform.TimeTrackReport_EnablePerformanceTracking_action_eventHandlers_click_enableDisableTT',
                     'id' : 'aw10972127',
                     'event' : 'click',
                     'class' : 'platform.performance.handler.TimeTrackHandler',
               },
               {
                     'method' : 'setLabel',
                     'artifactId' : 'Platform.TimeTrackReport_EnablePerformanceTracking_action_eventHandlers_render_setLabel',
                     'id' : 'awf9abf636',
                     'event' : 'render',
                     'class' : 'platform.performance.handler.TimeTrackHandler',
               }
            ];
            action026.eventHandlers = eventHandlers108;

            var action027 = new Action({
               'overflow' : true,
               'artifactId' : 'Platform.TimeTrackReport_ClearPerformanceData_action',
               'id' : 'aw1edf54cf',
               'label' : MessageService.createStaticMessage('Clear Performance Data'),
            });
            actions008.addChild( action027 );

            var eventHandlers109 = [
               {
                     'method' : 'clear',
                     'artifactId' : 'Platform.TimeTrackReport_ClearPerformanceData_action_eventHandlers_click_clear',
                     'id' : 'aw85273d1b',
                     'event' : 'click',
                     'class' : 'platform.performance.handler.TimeTrackHandler',
               }
            ];
            action027.eventHandlers = eventHandlers109;

            var action028 = new Action({
               'overflow' : true,
               'artifactId' : 'Platform.TimeTrackReport_EmailReport_action',
               'id' : 'aw6ff8fae1',
               'label' : MessageService.createStaticMessage('Email Report'),
            });
            actions008.addChild( action028 );

            var eventHandlers110 = [
               {
                     'method' : 'emailCurrent',
                     'artifactId' : 'Platform.TimeTrackReport_EmailReport_action_eventHandlers_click_emailCurrent',
                     'id' : 'awc00583a0',
                     'event' : 'click',
                     'class' : 'platform.performance.handler.TimeTrackHandler',
               }
            ];
            action028.eventHandlers = eventHandlers110;
            var eventHandlers111 = [
               {
                     'method' : 'renderTT',
                     'artifactId' : 'Platform.TimeTrackReport_eventHandlers_show_renderTT',
                     'id' : 'awca05a315',
                     'event' : 'show',
                     'class' : 'platform.performance.handler.TimeTrackHandler',
               }
            ];
            view042.eventHandlers = eventHandlers111;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            var dialog010 = new Dialog({
               'closeOnBackgroundClick' : 'true',
               'id' : 'Platform.ListLongPressDialog',
            });
            ui001.addChild( dialog010 );



            var listItemTemplate016 = new ListItemTemplate({
               'cssClass' : 'dialogListItem textappearance-medium',
               'artifactId' : 'Platform.ListLongPressDialog_PlatformLongPressResource_listItemTemplate',
               'id' : 'awefd72fd8',
            });

            var listtext048 = new ListText({
               'resourceAttribute' : 'label',
               'artifactId' : 'Platform.ListLongPressDialog_PlatformLongPressResource_label',
               'id' : 'awe2e495b2',
            });
            listItemTemplate016.addChild( listtext048 );



            var list016 = new List({
               'resource' : 'PlatformLongPressResource',
               'showHeader' : false,
               'listItemTemplate' : listItemTemplate016,
               'artifactId' : 'Platform.ListLongPressDialog_PlatformLongPressResource_list',
               'id' : 'aw64ff84d9',
               'queryBase' : '',
            });
            dialog010.addChild( list016 );


            var dialog011 = new Dialog({
               'id' : 'Platform.LoadingAdditionalData',
            });
            ui001.addChild( dialog011 );


            var container054 = new Container({
               'artifactId' : 'Platform.LoadingAdditionalData_container_0',
               'id' : 'aw48b509d9',
            });
            dialog011.addChild( container054 );


            var text197 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.LoadingAdditionalData_container_0_Downloadinglookupd',
               'id' : 'aw4cec47c0',
               'value' : MessageService.createStaticMessage('Downloading lookup data.'),
            });
            container054.addChild( text197 );


            var button043 = new Button({
               'artifactId' : 'Platform.LoadingAdditionalData_Cancel_button',
               'id' : 'awb30b5f0',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers112 = [
               {
                     'method' : 'cancelADDownload',
                     'artifactId' : 'Platform.LoadingAdditionalData_Cancel_button_eventHandlers_click_cancelADDownload',
                     'id' : 'awc41dac4c',
                     'event' : 'click',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               }
            ];
            button043.eventHandlers = eventHandlers112;
            container054.addChild( button043 );


            var dialog012 = new Dialog({
               'id' : 'Platform.AdditionalDataNoConn',
            });
            ui001.addChild( dialog012 );


            var container055 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.AdditionalDataNoConn_container_0',
               'id' : 'aw666da461',
            });
            dialog012.addChild( container055 );


            var text198 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.AdditionalDataNoConn_container_0_Lookupdatacouldno',
               'id' : 'aw96b90fd8',
               'value' : MessageService.createStaticMessage('Lookup data could not be downloaded. Go to Settings > Refresh Lookup Data when you are online.'),
            });
            container055.addChild( text198 );


            var container056 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.AdditionalDataNoConn_container_1',
               'id' : 'aw116a94f7',
            });
            dialog012.addChild( container056 );


            var button044 = new Button({
               'artifactId' : 'Platform.AdditionalDataNoConn_OK_button',
               'id' : 'aw9b370278',
               'label' : MessageService.createStaticMessage('OK'),
            });
            var eventHandlers113 = [
               {
                     'method' : 'closeDialogAndShowDefaultViewIfNeeded',
                     'artifactId' : 'Platform.AdditionalDataNoConn_OK_button_eventHandlers_click_closeDialogAndShowDefaultViewIfNeeded',
                     'id' : 'aw108159b3',
                     'event' : 'click',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               }
            ];
            button044.eventHandlers = eventHandlers113;
            container056.addChild( button044 );


            var dialog013 = new Dialog({
               'id' : 'Platform.ConfirmReloadWorkList',
            });
            ui001.addChild( dialog013 );


            var container057 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.ConfirmReloadWorkList_container_0',
               'id' : 'aw2054aa9e',
            });
            dialog013.addChild( container057 );


            var text199 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.ConfirmReloadWorkList_container_0_Doyouwanttoclose',
               'id' : 'aw83f81a4b',
               'value' : MessageService.createStaticMessage('Reloading the work list takes time if you are downloading large amounts of data.  Are you sure that you want to continue?'),
            });
            container057.addChild( text199 );


            var container058 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.ConfirmReloadWorkList_container_1',
               'id' : 'aw57539a08',
            });
            dialog013.addChild( container058 );


            var button045 = new Button({
               'cssClass' : 'dialogButton',
               'artifactId' : 'Platform.ConfirmReloadWorkList_Yes_button',
               'id' : 'aw5bc89627',
               'label' : MessageService.createStaticMessage('Yes'),
            });
            var eventHandlers114 = [
               {
                     'method' : 'reloadConfirmed',
                     'artifactId' : 'Platform.ConfirmReloadWorkList_Yes_button_eventHandlers_click_processDialog',
                     'id' : 'awafdb701f',
                     'event' : 'click',
                     'class' : 'platform.handlers.WorkOfflineHandler',
               }
            ];
            button045.eventHandlers = eventHandlers114;
            container058.addChild( button045 );


            var button046 = new Button({
               'cssClass' : 'mblPrimaryButton dialogButton',
               'artifactId' : 'Platform.ConfirmReloadWorkList_No_button',
               'id' : 'aw4487e9e7',
               'label' : MessageService.createStaticMessage('No'),
            });
            var eventHandlers115 = [
               {
                     'method' : 'closeDialog',
                     'artifactId' : 'Platform.ConfirmReloadWorkList_No_button_eventHandlers_click_closeDialog',
                     'id' : 'aw56d1743',
                     'event' : 'click',
                     'class' : 'platform.handlers.DialogHandler',
               }
            ];
            button046.eventHandlers = eventHandlers115;
            container058.addChild( button046 );


            var dialog014 = new Dialog({
               'resource' : 'PlatformProgressResource',
               'id' : 'Platform.ReloadingCurrentWorklist',
            });
            ui001.addChild( dialog014 );


            var container059 = new Container({
               'cssClass' : 'mblSimpleMessageText',
               'artifactId' : 'Platform.ReloadCurrentWorklist_container_0',
               'id' : 'awce0c0b72',
            });
            dialog014.addChild( container059 );


            var text200 = new Text({
               'resourceAttribute' : 'progressMsg',
               'editable' : false,
               'artifactId' : 'Platform.ReloadCurrentWorklist_container_0_progressMsg',
               'id' : 'awaa894933',
            });
            container059.addChild( text200 );


            var dialog015 = new Dialog({
               'id' : 'Platform.AdditionalDataFailed',
            });
            ui001.addChild( dialog015 );


            var container060 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.AdditionalDataFailed.container',
               'id' : 'aw275627fb',
            });
            dialog015.addChild( container060 );


            var text201 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.AdditionalDataFailed.text',
               'id' : 'awb25e5b66',
               'value' : MessageService.createStaticMessage('Lookup data could not be downloaded. If you are connected, go to Settings > Refresh Lookup Data.'),
            });
            container060.addChild( text201 );


            var container061 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.AdditionalDataFailed.container2',
               'id' : 'aw309dc3be',
            });
            dialog015.addChild( container061 );


            var button047 = new Button({
               'artifactId' : 'Platform.AdditionalDataFailed.button',
               'id' : 'aw39111677',
               'label' : MessageService.createStaticMessage('OK'),
            });
            var eventHandlers116 = [
               {
                     'method' : 'closeDialogAndShowDefaultViewIfNeeded',
                     'artifactId' : 'Platform.AdditionalDataFailed.eventHandler',
                     'id' : 'awacbc5440',
                     'event' : 'click',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               }
            ];
            button047.eventHandlers = eventHandlers116;
            container061.addChild( button047 );


            var dialog016 = new Dialog({
               'resource' : 'PlatformProgressResource',
               'id' : 'Platform.LoadingSystemData',
            });
            ui001.addChild( dialog016 );


            var container062 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.LoadingSystemData_container_0',
               'id' : 'aw13d3cc6a',
            });
            dialog016.addChild( container062 );


            var text202 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.LoadingSystemData_container_0_Downloadingsystemd',
               'id' : 'awfc1b5f79',
               'value' : MessageService.createStaticMessage('Downloading system data.'),
            });
            container062.addChild( text202 );


            var text203 = new Text({
               'resourceAttribute' : 'progressMsg',
               'editable' : false,
               'artifactId' : 'Platform.LoadingSystemData_container_0_progressMsg',
               'id' : 'aw635d9968',
            });
            container062.addChild( text203 );


            var dialog017 = new Dialog({
               'id' : 'Platform.LoadAdditionalDataYesNo',
            });
            ui001.addChild( dialog017 );


            var container063 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.LoadAdditionalDataYesNo_container_0',
               'id' : 'aw22834650',
            });
            dialog017.addChild( container063 );


            var text204 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.LoadAdditionalDataYesNo_container_0_Thelookupdatafor',
               'id' : 'aw89be3f27',
               'value' : MessageService.createStaticMessage('The lookup data for this app must be downloaded. Download it now or later?'),
            });
            container063.addChild( text204 );

            var eventHandlers117 = [
               {
                     'method' : 'theLookupdataText',
                     'artifactId' : 'Platform.LoadAdditionalDataYesNo_container_0_Thelookupdatafor_eventHandlers_render_setAdditionalDownloadText',
                     'id' : 'aw9051ca24',
                     'event' : 'render',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               }
            ];
            text204.eventHandlers = eventHandlers117;

            var text205 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.LoadAdditionalDataYesNo_container_0_Retrylookupdatafor',
               'id' : 'awb287d1cc',
               'value' : MessageService.createStaticMessage('Lookup data was partially downloaded. Click Retry to download the remaining lookup data. Click Reset to refresh all of the lookup data. Click Close if you are through downloading lookup data.'),
            });
            container063.addChild( text205 );

            var eventHandlers118 = [
               {
                     'method' : 'retrylookupdataText',
                     'artifactId' : 'Platform.LoadAdditionalDataYesNo_container_0_Retrylookupdatafor_eventHandlers_render_setAdditionalDownloadText',
                     'id' : 'aw5ad2ed31',
                     'event' : 'render',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               }
            ];
            text205.eventHandlers = eventHandlers118;

            var text206 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.LoadAdditionalDataYesNo_container_0_Whenrunninginabr',
               'id' : 'awb757e4d5',
               'value' : MessageService.createStaticMessage('When running in a browser, a maximum of 200 records are downloaded per lookup.'),
            });
            container063.addChild( text206 );

            var eventHandlers119 = [
               {
                     'method' : 'showInPreview',
                     'artifactId' : 'Platform.LoadAdditionalDataYesNo_container_0_Whenrunninginabr_eventHandlers_render_showInPreview',
                     'id' : 'awb7d271e9',
                     'event' : 'render',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               }
            ];
            text206.eventHandlers = eventHandlers119;

            var container064 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.LoadAdditionalDataYesNo_container_1',
               'id' : 'aw558476c6',
            });
            dialog017.addChild( container064 );


            var button048 = new Button({
               'cssClass' : 'dialogButton',
               'artifactId' : 'Platform.LoadAdditionalDataYesNo_Later_button',
               'id' : 'awa2501fe3',
               'label' : MessageService.createStaticMessage('Later'),
            });
            var eventHandlers120 = [
               {
                     'method' : 'closeDialogAndShowDefaultViewIfNeeded',
                     'artifactId' : 'Platform.LoadAdditionalDataYesNo_Later_button_eventHandlers_click_closeDialogAndShowDefaultViewIfNeeded',
                     'id' : 'aw257121b',
                     'event' : 'click',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               },
               {
                     'method' : 'setBtLabelLaterOrCancel',
                     'artifactId' : 'Platform.LoadAdditionalDataYesNo_Retry_button_eventHandlers_render_setBtLabelLaterOrCancel',
                     'id' : 'aw6ece4695',
                     'event' : 'render',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               }
            ];
            button048.eventHandlers = eventHandlers120;
            container064.addChild( button048 );


            var button049 = new Button({
               'cssClass' : 'mblPrimaryButton dialogButton',
               'artifactId' : 'Platform.LoadAdditionalDataYesNo_Now_button',
               'id' : 'aw35a14c11',
               'label' : MessageService.createStaticMessage('Now'),
            });
            var eventHandlers121 = [
               {
                     'method' : 'confirmADDownload',
                     'artifactId' : 'Platform.LoadAdditionalDataYesNo_Now_button_eventHandlers_click_confirmADDownload',
                     'id' : 'aw7df27335',
                     'event' : 'click',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               },
               {
                     'method' : 'setBtLabelNowOrRefresh',
                     'artifactId' : 'Platform.LoadAdditionalDataYesNo_Retry_button_eventHandlers_render_setBtLabelNowOrRefresh',
                     'id' : 'aw83fe125f',
                     'event' : 'render',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               }
            ];
            button049.eventHandlers = eventHandlers121;
            container064.addChild( button049 );


            var button050 = new Button({
               'cssClass' : 'mblPrimaryButton dialogButton',
               'artifactId' : 'Platform.LoadAdditionalDataYesNo_Retry_button',
               'id' : 'aw626b616d',
               'label' : MessageService.createStaticMessage('Retry'),
            });
            var eventHandlers122 = [
               {
                     'method' : 'retryADDownload',
                     'artifactId' : 'Platform.LoadAdditionalDataYesNo_Retry_button_eventHandlers_click_retryADDownload',
                     'id' : 'aw7bef6fb1',
                     'event' : 'click',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               },
               {
                     'method' : 'renderRetryButton',
                     'artifactId' : 'Platform.LoadAdditionalDataYesNo_Retry_button_eventHandlers_render_retryADDownload',
                     'id' : 'awfa4998f7',
                     'event' : 'render',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               }
            ];
            button050.eventHandlers = eventHandlers122;
            container064.addChild( button050 );


            var dialog018 = new Dialog({
               'id' : 'Platform.LoadAdditionalDataDeltaDownload',
            });
            ui001.addChild( dialog018 );


            var container065 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.LoadAdditionalDataDeltaDownload_container_0',
               'id' : 'aw79883531',
            });
            dialog018.addChild( container065 );


            var text207 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.LoadAdditionalDataDeltaDownload_container_0_Thelookupdatafor',
               'id' : 'aw3d94f20f',
               'value' : MessageService.createStaticMessage('Click Changes to download only lookup data changes.'),
            });
            container065.addChild( text207 );


            var text208 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.LoadAdditionalDataDeltaDownload_container_0_Retrylookupdatafor',
               'id' : 'awa0f7541',
               'value' : MessageService.createStaticMessage('Click All to download all the lookup data.'),
            });
            container065.addChild( text208 );


            var text209 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.LoadAdditionalDataDeltaDownload_container_0_cancel',
               'id' : 'aw62270e4c',
               'value' : MessageService.createStaticMessage('Click Cancel to cancel the lookup download.'),
            });
            container065.addChild( text209 );


            var text210 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.LoadAdditionalDataDeltaDownload_container_0_action',
               'id' : 'aw73fd47ac',
               'value' : MessageService.createStaticMessage('Which refresh do you want to perform?'),
            });
            container065.addChild( text210 );


            var text211 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.LoadAdditionalDataDeltaDownload_container_0_Whenrunninginabr',
               'id' : 'aw37d29fd',
               'value' : MessageService.createStaticMessage('When running in a browser, a maximum of 200 records are downloaded per lookup.'),
            });
            container065.addChild( text211 );

            var eventHandlers123 = [
               {
                     'method' : 'showInPreview',
                     'artifactId' : 'Platform.LoadAdditionalDataDeltaDownload_container_0_Whenrunninginabr_eventHandlers_render_showInPreview',
                     'id' : 'aw1edf10f3',
                     'event' : 'render',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               }
            ];
            text211.eventHandlers = eventHandlers123;

            var container066 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.LoadAdditionalDataDeltaDownload_container_1',
               'id' : 'awe8f05a7',
            });
            dialog018.addChild( container066 );


            var button051 = new Button({
               'artifactId' : 'Platform.LoadAdditionalDataDeltaDownload_Cancel_button',
               'id' : 'awb2f881ae',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers124 = [
               {
                     'method' : 'closeDialogAndShowDefaultViewIfNeeded',
                     'artifactId' : 'Platform.LoadAdditionalDataDeltaDownload_Later_button_eventHandlers_click_closeDialogAndShowDefaultViewIfNeeded',
                     'id' : 'awcaa29f5a',
                     'event' : 'click',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               }
            ];
            button051.eventHandlers = eventHandlers124;
            container066.addChild( button051 );


            var button052 = new Button({
               'artifactId' : 'Platform.LoadAdditionalDataDeltaDownload_RefreshAll_button',
               'id' : 'aw8ab2882',
               'label' : MessageService.createStaticMessage('All'),
            });
            var eventHandlers125 = [
               {
                     'method' : 'confirmADDownload',
                     'artifactId' : 'Platform.LoadAdditionalDataDeltaDownload_Now_button_eventHandlers_click_confirmADDownload',
                     'id' : 'awa5526bd4',
                     'event' : 'click',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               }
            ];
            button052.eventHandlers = eventHandlers125;
            container066.addChild( button052 );


            var button053 = new Button({
               'cssClass' : 'mblPrimaryButton dialogButton',
               'artifactId' : 'Platform.LoadAdditionalDataDeltaDownload_RefreshChanges_button',
               'id' : 'aw9c0cf49a',
               'label' : MessageService.createStaticMessage('Changes'),
            });
            var eventHandlers126 = [
               {
                     'method' : 'confirmADDeltaDownload',
                     'artifactId' : 'Platform.LoadAdditionalDataDeltaDownload_Later_button_eventHandlers_click_confirmADDeltaDownload',
                     'id' : 'aw46619626',
                     'event' : 'click',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               }
            ];
            button053.eventHandlers = eventHandlers126;
            container066.addChild( button053 );


            var dialog019 = new Dialog({
               'id' : 'Platform.LoadSystemDataDeltaDownload',
            });
            ui001.addChild( dialog019 );


            var container067 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.LoadSystemDataDeltaDownload_container_0',
               'id' : 'aw47beed1c',
            });
            dialog019.addChild( container067 );


            var text212 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.LoadSystemDataDeltaDownload_container_0_Thelookupdatafor',
               'id' : 'aw682ebd2f',
               'value' : MessageService.createStaticMessage('Click Changes to download only the system data changes.'),
            });
            container067.addChild( text212 );


            var text213 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.LoadSystemDataDeltaDownload_container_0_Retrylookupdatafor',
               'id' : 'aw79e85858',
               'value' : MessageService.createStaticMessage('Click All to download all the system data.'),
            });
            container067.addChild( text213 );


            var text214 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.LoadSystemDataDeltaDownload_container_0_cancel',
               'id' : 'awcb50ae6',
               'value' : MessageService.createStaticMessage('Click Cancel to cancel the system download.'),
            });
            container067.addChild( text214 );


            var text215 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.LoadSystemDataDeltaDownload_container_0_action',
               'id' : 'aw1d6f4306',
               'value' : MessageService.createStaticMessage('Which refresh do you want to perform?'),
            });
            container067.addChild( text215 );


            var text216 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.LoadSystemDataDeltaDownload_container_0_Whenrunninginabr',
               'id' : 'aw56c766dd',
               'value' : MessageService.createStaticMessage('When running in a browser, a maximum of 200 records are downloaded per System.'),
            });
            container067.addChild( text216 );

            var eventHandlers127 = [
               {
                     'method' : 'showInPreview',
                     'artifactId' : 'Platform.LoadSystemDataDeltaDownload_container_0_Whenrunninginabr_eventHandlers_render_showInPreview',
                     'id' : 'aw37b2ac2a',
                     'event' : 'render',
                     'class' : 'platform.handlers.AdditionalDataDialogHandler',
               }
            ];
            text216.eventHandlers = eventHandlers127;

            var container068 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.LoadSystemDataDeltaDownload_container_1',
               'id' : 'aw30b9dd8a',
            });
            dialog019.addChild( container068 );


            var button054 = new Button({
               'artifactId' : 'Platform.LoadSystemDataDeltaDownload_Cancel_button',
               'id' : 'aw1adabf91',
               'label' : MessageService.createStaticMessage('cancel'),
            });
            var eventHandlers128 = [
               {
                     'method' : 'closeDialogAndShowDefaultViewIfNeeded',
                     'artifactId' : 'Platform.LoadSystemDataDeltaDownload_Later_button_eventHandlers_click_closeDialogAndShowDefaultViewIfNeeded',
                     'id' : 'aw2569598a',
                     'event' : 'click',
                     'class' : 'platform.handlers.SettingsHandler',
               }
            ];
            button054.eventHandlers = eventHandlers128;
            container068.addChild( button054 );


            var button055 = new Button({
               'artifactId' : 'Platform.LoadSystemDataDeltaDownload_RefreshAll_button',
               'id' : 'awf1a96515',
               'label' : MessageService.createStaticMessage('All'),
            });
            var eventHandlers129 = [
               {
                     'method' : 'downloadSystemData',
                     'artifactId' : 'Platform.LoadSystemDataDeltaDownload_Now_button_eventHandlers_click_confirmdownloadSystemData',
                     'id' : 'aw8d600b10',
                     'event' : 'click',
                     'class' : 'platform.handlers.SettingsHandler',
               }
            ];
            button055.eventHandlers = eventHandlers129;
            container068.addChild( button055 );


            var button056 = new Button({
               'cssClass' : 'mblPrimaryButton dialogButton',
               'artifactId' : 'Platform.LoadSystemDataDeltaDownload_RefreshChanges_button',
               'id' : 'aw328e1b2e',
               'label' : MessageService.createStaticMessage('Changes'),
            });
            var eventHandlers130 = [
               {
                     'method' : 'confirmSystemDataDeltaDownload',
                     'artifactId' : 'Platform.LoadSystemDataDeltaDownload_Later_button_eventHandlers_click_confirmSystemDataDeltaDownload',
                     'id' : 'awbd23e928',
                     'event' : 'click',
                     'class' : 'platform.handlers.SettingsHandler',
               }
            ];
            button056.eventHandlers = eventHandlers130;
            container068.addChild( button056 );


            var dialog020 = new Dialog({
               'id' : 'Platform.ExitApplicationPrompt',
            });
            ui001.addChild( dialog020 );


            var container069 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.ExitApplicationPrompt_container_0',
               'id' : 'aw71d2ddca',
            });
            dialog020.addChild( container069 );


            var text217 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.ExitApplicationPrompt_container_0_Doyouwanttoclose',
               'id' : 'aw4e0184c3',
               'value' : MessageService.createStaticMessage('Do you want to close the app?'),
            });
            container069.addChild( text217 );


            var container070 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.ExitApplicationPrompt_container_1',
               'id' : 'aw6d5ed5c',
            });
            dialog020.addChild( container070 );


            var button057 = new Button({
               'cssClass' : 'dialogButton',
               'artifactId' : 'Platform.ExitApplicationPrompt_Yes_button',
               'id' : 'aw3bff816',
               'label' : MessageService.createStaticMessage('Yes'),
            });
            var eventHandlers131 = [
               {
                     'method' : 'processDialog',
                     'artifactId' : 'Platform.ExitApplicationPrompt_Yes_button_eventHandlers_click_processDialog',
                     'id' : 'awfa220200',
                     'event' : 'click',
                     'class' : 'platform.handlers.DialogHandler',
               }
            ];
            button057.eventHandlers = eventHandlers131;
            container070.addChild( button057 );


            var button058 = new Button({
               'cssClass' : 'mblPrimaryButton dialogButton',
               'artifactId' : 'Platform.ExitApplicationPrompt_No_button',
               'id' : 'aw5ba5c9da',
               'label' : MessageService.createStaticMessage('No'),
            });
            var eventHandlers132 = [
               {
                     'method' : 'closeDialog',
                     'artifactId' : 'Platform.ExitApplicationPrompt_No_button_eventHandlers_click_closeDialog',
                     'id' : 'aw5256cc3',
                     'event' : 'click',
                     'class' : 'platform.handlers.DialogHandler',
               }
            ];
            button058.eventHandlers = eventHandlers132;
            container070.addChild( button058 );


            var dialog021 = new Dialog({
               'id' : 'Platform.LogOutPrompt',
            });
            ui001.addChild( dialog021 );


            var container071 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.LogOutPrompt_container_0',
               'id' : 'awcf20d41b',
            });
            dialog021.addChild( container071 );


            var text218 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.LogOutPrompt_container_0_Doyouwanttologo',
               'id' : 'aw15a96005',
               'value' : MessageService.createStaticMessage('Do you want to log out of the app?'),
            });
            container071.addChild( text218 );


            var container072 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.LogOutPrompt_container_1',
               'id' : 'awb827e48d',
            });
            dialog021.addChild( container072 );


            var button059 = new Button({
               'cssClass' : 'dialogButton',
               'artifactId' : 'Platform.LogOutPrompt_No_button',
               'id' : 'awfbbbd446',
               'label' : MessageService.createStaticMessage('No'),
            });
            var eventHandlers133 = [
               {
                     'method' : 'closeDialog',
                     'artifactId' : 'Platform.LogOutPrompt_No_button_eventHandlers_click_closeDialog',
                     'id' : 'aw364ad2c7',
                     'event' : 'click',
                     'class' : 'platform.handlers.DialogHandler',
               }
            ];
            button059.eventHandlers = eventHandlers133;
            container072.addChild( button059 );


            var button060 = new Button({
               'cssClass' : 'mblPrimaryButton dialogButton',
               'artifactId' : 'Platform.LogOutPrompt_Yes_button',
               'id' : 'awfaa63964',
               'label' : MessageService.createStaticMessage('Yes'),
            });
            var eventHandlers134 = [
               {
                     'method' : 'logoutDialog',
                     'artifactId' : 'Platform.LogOutPrompt_Yes_button_eventHandlers_click_logoutDialog',
                     'id' : 'aw82db52a6',
                     'event' : 'click',
                     'class' : 'platform.handlers.DialogHandler',
               }
            ];
            button060.eventHandlers = eventHandlers134;
            container072.addChild( button060 );


            var dialog022 = new Dialog({
               'cssClass' : 'dialogDurationLookup',
               'resource' : 'PlatformDateLookupResource',
               'id' : 'Platform.DurationLookup',
               'label' : MessageService.createStaticMessage('Change Duration'),
            });
            ui001.addChild( dialog022 );

            var eventHandlers135 = [
               {
                     'method' : 'initLookup',
                     'artifactId' : 'Platform.DurationLookup_eventHandlers_show_initLookup',
                     'id' : 'aw2898d5b1',
                     'event' : 'show',
                     'class' : 'platform.handlers.LookupHandler',
               }
            ];
            dialog022.eventHandlers = eventHandlers135;

            var container073 = new Container({
               'artifactId' : 'Platform.DurationLookup_container_0',
               'id' : 'awc7b6d6e2',
            });
            dialog022.addChild( container073 );


            var durationpicker001 = new DurationPicker({
               'artifactId' : 'Platform.DurationLookup_durationpicker_0',
               'id' : 'awbdafea4f',
            });
            container073.addChild( durationpicker001 );


            var container074 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.DurationLookup_container_1',
               'id' : 'awb0b1e674',
            });
            dialog022.addChild( container074 );


            var button061 = new Button({
               'artifactId' : 'Platform.DurationLookup_Cancel_button',
               'id' : 'aw21ee1a8e',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers136 = [
               {
                     'method' : 'Cancel',
                     'artifactId' : 'Platform.DurationLookup_Cancel_button_eventHandlers_click_Cancel',
                     'id' : 'aw7fc46e19',
                     'event' : 'click',
                     'class' : 'platform.handlers.LookupHandler',
               }
            ];
            button061.eventHandlers = eventHandlers136;
            container074.addChild( button061 );


            var button062 = new Button({
               'artifactId' : 'Platform.DurationLookup_Clear_button',
               'id' : 'awab5a917f',
               'label' : MessageService.createStaticMessage('Clear'),
            });
            var eventHandlers137 = [
               {
                     'method' : 'Clear',
                     'artifactId' : 'Platform.DurationLookup_Clear_button_eventHandlers_click_Clear',
                     'id' : 'aw4d23bc8f',
                     'event' : 'click',
                     'class' : 'platform.handlers.LookupHandler',
               }
            ];
            button062.eventHandlers = eventHandlers137;
            container074.addChild( button062 );


            var button063 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'Platform.DurationLookup_OK_button',
               'id' : 'aw7a6484f6',
               'label' : MessageService.createStaticMessage('OK'),
               'primary' : 'true',
            });
            var eventHandlers138 = [
               {
                     'method' : 'SetSelection',
                     'artifactId' : 'Platform.DurationLookup_OK_button_eventHandlers_click_SetSelection',
                     'id' : 'aweb8ce178',
                     'event' : 'click',
                     'class' : 'platform.handlers.LookupHandler',
               }
            ];
            button063.eventHandlers = eventHandlers138;
            container074.addChild( button063 );


            var dialog023 = new Dialog({
               'id' : 'Platform.CancelDownload',
            });
            ui001.addChild( dialog023 );


            var container075 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.CancelDownload_container_0',
               'id' : 'awf839de44',
            });
            dialog023.addChild( container075 );


            var text219 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.CancelDownload_container_0_Doyouwanttostop',
               'id' : 'awdb2316b3',
               'value' : MessageService.createStaticMessage('Do you want to stop downloading work list records?'),
            });
            container075.addChild( text219 );


            var container076 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.CancelDownload_container_1',
               'id' : 'aw8f3eeed2',
            });
            dialog023.addChild( container076 );


            var button064 = new Button({
               'cssClass' : 'mblPrimaryButton dialogButton',
               'artifactId' : 'Platform.CancelDownload_Yes_button',
               'id' : 'aw3b97968f',
               'label' : MessageService.createStaticMessage('Yes'),
            });
            var eventHandlers139 = [
               {
                     'method' : 'cancelDownload',
                     'artifactId' : 'Platform.CancelDownload_Yes_button_eventHandlers_click_cancelDownload',
                     'id' : 'awadc6ff1d',
                     'event' : 'click',
                     'class' : 'platform.handlers.WorkOfflineHandler',
               }
            ];
            button064.eventHandlers = eventHandlers139;
            container076.addChild( button064 );


            var button065 = new Button({
               'cssClass' : 'dialogButton',
               'artifactId' : 'Platform.CancelDownload_No_button',
               'id' : 'awab099478',
               'label' : MessageService.createStaticMessage('No'),
            });
            var eventHandlers140 = [
               {
                     'method' : 'closeDialog',
                     'artifactId' : 'Platform.CancelDownload_No_button_eventHandlers_click_closeDialog',
                     'id' : 'aw9ceda703',
                     'event' : 'click',
                     'class' : 'platform.handlers.DialogHandler',
               }
            ];
            button065.eventHandlers = eventHandlers140;
            container076.addChild( button065 );


            var dialog024 = new Dialog({
               'id' : 'Platform.ConfirmClearChanges',
            });
            ui001.addChild( dialog024 );


            var container077 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.ConfirmClearChanges_container_0',
               'id' : 'aw3965500f',
            });
            dialog024.addChild( container077 );


            var text220 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.ConfirmClearChanges_container_0_Changesthathaveno',
               'id' : 'aw66e22f87',
               'value' : MessageService.createStaticMessage('Changes that have not been sent to the server will be discarded.'),
            });
            container077.addChild( text220 );


            var container078 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.ConfirmClearChanges_container_1',
               'id' : 'aw4e626099',
            });
            dialog024.addChild( container078 );


            var button066 = new Button({
               'artifactId' : 'Platform.ConfirmClearChanges_Cancel_button',
               'id' : 'awcee54fe9',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers141 = [
               {
                     'method' : 'cancelClearChanges',
                     'artifactId' : 'Platform.ConfirmClearChanges_Cancel_button_eventHandlers_click_cancelClearChanges',
                     'id' : 'awb208eba2',
                     'event' : 'click',
                     'class' : 'platform.handlers.WorkOfflineHandler',
               }
            ];
            button066.eventHandlers = eventHandlers141;
            container078.addChild( button066 );


            var button067 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'Platform.ConfirmClearChanges_OK_button',
               'id' : 'aw8a3b05f2',
               'label' : MessageService.createStaticMessage('OK'),
            });
            var eventHandlers142 = [
               {
                     'method' : 'doClearChanges',
                     'artifactId' : 'Platform.ConfirmClearChanges_OK_button_eventHandlers_click_doClearChanges',
                     'id' : 'aw32f778d4',
                     'event' : 'click',
                     'class' : 'platform.handlers.WorkOfflineHandler',
               }
            ];
            button067.eventHandlers = eventHandlers142;
            container078.addChild( button067 );


            var dialog025 = new Dialog({
               'resource' : 'PlatformProgressResource',
               'id' : 'Platform.DownloadCurrentWorklist',
            });
            ui001.addChild( dialog025 );


            var container079 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.DownloadCurrentWorklist_container_0',
               'id' : 'awfd35c5df',
            });
            dialog025.addChild( container079 );


            var text221 = new Text({
               'resourceAttribute' : 'progressMsg',
               'editable' : false,
               'artifactId' : 'Platform.DownloadCurrentWorklist_container_0_progressMsg',
               'id' : 'aw3c55ae56',
            });
            container079.addChild( text221 );


            var container080 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.DownloadCurrentWorklist_container_1',
               'id' : 'aw8a32f549',
            });
            dialog025.addChild( container080 );


            var button068 = new Button({
               'artifactId' : 'Platform.DownloadCurrentWorklist_Cancel_button',
               'id' : 'awcfb8296d',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers143 = [
               {
                     'method' : 'cancelDownload',
                     'artifactId' : 'Platform.DownloadCurrentWorklist_Cancel_button_eventHandlers_click_cancelDownload',
                     'id' : 'aw5541afbb',
                     'event' : 'click',
                     'class' : 'platform.handlers.WorkOfflineHandler',
               }
            ];
            button068.eventHandlers = eventHandlers143;
            container080.addChild( button068 );


            var dialog026 = new Dialog({
               'id' : 'Platform.NoRecordFoundDialog',
            });
            ui001.addChild( dialog026 );


            var container081 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.NoRecordFoundDialog_container_0',
               'id' : 'awa73a1c57',
            });
            dialog026.addChild( container081 );


            var text222 = new Text({
               'artifactId' : 'Platform.NoRecordFoundDialog_container_0_Stopthetimeronwo',
               'id' : 'awd6cf8f25',
               'value' : MessageService.createStaticMessage('No record was found. If you are working offline, try downloading worklist when online to access your workorder'),
            });
            container081.addChild( text222 );


            var container082 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.NoRecordFoundDialog_container_1',
               'id' : 'awd03d2cc1',
            });
            dialog026.addChild( container082 );


            var button069 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'Platform.NoRecordFoundDialog_OK_button',
               'id' : 'aw3de0cad2',
               'label' : MessageService.createStaticMessage('Close'),
            });
            var eventHandlers144 = [
               {
                     'method' : 'closeNoRecord',
                     'artifactId' : 'Platform.NoRecordFoundDialog_OK_button_multiple',
                     'id' : 'aw41a4b840',
                     'event' : 'click',
                     'class' : 'platform.handlers.PushNotificationDialogHandler',
               }
            ];
            button069.eventHandlers = eventHandlers144;
            container082.addChild( button069 );


            var dialog027 = new Dialog({
               'id' : 'Platform.MultiplePushNotificationDialog',
            });
            ui001.addChild( dialog027 );


            var container083 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.MultiplePushNotificationDialog_container_0',
               'id' : 'aw7b338e5e',
            });
            dialog027.addChild( container083 );


            var text223 = new Text({
               'artifactId' : 'Platform.MultiplePushNotificationDialog_container_0_Stopthetimeronwo',
               'id' : 'aw72fc5fcc',
               'value' : MessageService.createStaticMessage('Multiple notification were recieved. Go to notification view to access them.'),
            });
            container083.addChild( text223 );


            var container084 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.MultiplePushNotificationDialog_container_1',
               'id' : 'awc34bec8',
            });
            dialog027.addChild( container084 );


            var button070 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'Platform.MultiplePushNotificationDialog_OK_button',
               'id' : 'awc2c9277e',
               'label' : MessageService.createStaticMessage('Close'),
            });
            var eventHandlers145 = [
               {
                     'method' : 'close',
                     'artifactId' : 'Platform.MultiplePushNotificationDialog_OK_button_multiple',
                     'id' : 'awe5002e8b',
                     'event' : 'click',
                     'class' : 'platform.handlers.PushNotificationDialogHandler',
               }
            ];
            button070.eventHandlers = eventHandlers145;
            container084.addChild( button070 );


            var dialog028 = new Dialog({
               'resource' : 'PlatformTempPushNotification',
               'id' : 'Platform.PushNotificationDialog',
            });
            ui001.addChild( dialog028 );


            var container085 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.PushNotificationDialog_container_0',
               'id' : 'awb0eedc9',
            });
            dialog028.addChild( container085 );


            var text224 = new Text({
               'artifactId' : 'Platform.PushNotificationDialog_container_0_Stopthetimeronwo',
               'id' : 'aw35fc28ff',
               'value' : MessageService.createDynamicMessage('{0} {1} {2}', 'platform.handlers.PushNotificationDialogHandler', 'resolveMessageProps'),
               'resolverFunction' : 'resolveMessageProps',
               'resolverClass' : 'platform.handlers.PushNotificationDialogHandler',
            });
            container085.addChild( text224 );


            var container086 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.PushNotificationDialog_container_1',
               'id' : 'aw7c09dd5f',
            });
            dialog028.addChild( container086 );


            var button071 = new Button({
               'artifactId' : 'Platform.PushNotificationDialog_Open_button',
               'id' : 'aw4151795',
               'label' : MessageService.createStaticMessage('Open'),
            });
            var eventHandlers146 = [
               {
                     'method' : 'openRecord',
                     'artifactId' : 'Platform.PushNotificationDialog_Open_button_eventHandlers_click_WOStartedDialogNoClickHandler',
                     'id' : 'aw32cc643',
                     'event' : 'click',
                     'class' : 'platform.handlers.PushNotificationDialogHandler',
               },
               {
                     'method' : 'renderOpen',
                     'artifactId' : 'Platform.PushNotificationDialog_Open_button_eventHandlers_render_RenderOpenButton',
                     'id' : 'awff1adc93',
                     'event' : 'render',
                     'class' : 'platform.handlers.PushNotificationDialogHandler',
               }
            ];
            button071.eventHandlers = eventHandlers146;
            container086.addChild( button071 );


            var button072 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'Platform.PushNotificationDialog_OK_button',
               'id' : 'aw3d64070a',
               'label' : MessageService.createStaticMessage('OK'),
            });
            var eventHandlers147 = [
               {
                     'method' : 'close',
                     'artifactId' : 'Platform.PushNotificationDialog_OK_button_eventHandlers_click_WOStartedDialogYesClickHandler',
                     'id' : 'aw40f88c32',
                     'event' : 'click',
                     'class' : 'platform.handlers.PushNotificationDialogHandler',
               }
            ];
            button072.eventHandlers = eventHandlers147;
            container086.addChild( button072 );


            var dialog029 = new Dialog({
               'resource' : 'PlatformDemoModeResource',
               'id' : 'Platform.DemoDownloadWarning',
            });
            ui001.addChild( dialog029 );


            var container087 = new Container({
               'cssClass' : 'mblSimpleDialogText',
               'artifactId' : 'Platform.DemoDownloadWarning_container_0',
               'id' : 'awf840ab79',
            });
            dialog029.addChild( container087 );


            var text225 = new Text({
               'editable' : false,
               'artifactId' : 'Platform.DemoDownloadWarning_container_0_progressMsg',
               'id' : 'awf3cb0903',
               'value' : MessageService.createStaticMessage('MessageText'),
            });
            container087.addChild( text225 );


            var container088 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.DemoDownloadWarning_container_1',
               'id' : 'aw8f479bef',
            });
            dialog029.addChild( container088 );


            var button073 = new Button({
               'artifactId' : 'Platform.DemoDownloadWarning_Continue_button',
               'id' : 'aw2659f8c8',
               'label' : MessageService.createStaticMessage('Continue'),
            });
            var eventHandlers148 = [
               {
                     'method' : 'doClearChanges',
                     'artifactId' : 'Platform.DemoDownloadWarning_Continue_button_eventHandlers_click_doClearChanges',
                     'id' : 'awbdf1879f',
                     'event' : 'click',
                     'class' : 'platform.handlers.WorkOfflineHandler',
               }
            ];
            button073.eventHandlers = eventHandlers148;
            container088.addChild( button073 );


            var button074 = new Button({
               'artifactId' : 'Platform.DemoDownloadWarning_Cancel_button',
               'id' : 'aw9def7b28',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers149 = [
               {
                     'method' : 'cancelDownload',
                     'artifactId' : 'Platform.DemoDownloadWarning_Cancel_button_eventHandlers_click_cancelDownload',
                     'id' : 'awd4960a86',
                     'event' : 'click',
                     'class' : 'platform.handlers.WorkOfflineHandler',
               }
            ];
            button074.eventHandlers = eventHandlers149;
            container088.addChild( button074 );


            var dialog030 = new Dialog({
               'resource' : 'PlatformEsigResource',
               'id' : 'Platform.EsigLoginView',
               'label' : MessageService.createStaticMessage('Electronic Signature Authentication'),
            });
            ui001.addChild( dialog030 );

            var requiredResources041 = {
               'attemptResultDomain' : {
                  'enableFeatureByProperty' : 'esig.enabled',
                  'artifactId' : 'Platform.EsigLoginView_attemptResultDomain',
                  'id' : 'aw3c53638b',
               },
            };
            dialog030.addRequiredResources( requiredResources041 );

            var container089 = new Container({
               'artifactId' : 'Platform.EsigLoginView_container_0',
               'id' : 'aw44fd9611',
            });
            dialog030.addChild( container089 );


            var group043 = new Group({
               'artifactId' : 'Platform.EsigLoginView_group_0',
               'id' : 'aw7bf6135f',
            });
            container089.addChild( group043 );


            var groupitem134 = new GroupItem({
               'artifactId' : 'Platform.EsigLoginView_group_0_groupitem_1',
               'id' : 'aw209714b9',
            });
            group043.addChild( groupitem134 );


            var text226 = new Text({
               'border' : 'true',
               'resourceAttribute' : 'userName',
               'cssClass' : 'loginUsername',
               'editable' : false,
               'artifactId' : 'Platform.EsigLoginView_container_0_username',
               'id' : 'aw15aabb30',
               'label' : MessageService.createStaticMessage('User Name'),
               'placeHolder' : MessageService.createStaticMessage('User name'),
            });
            groupitem134.addChild( text226 );


            var text227 = new Text({
               'border' : 'true',
               'resourceAttribute' : 'password',
               'cssClass' : 'loginPassword',
               'editable' : true,
               'artifactId' : 'Platform.EsigLoginView_container_0_password',
               'id' : 'awd836fb92',
               'label' : MessageService.createStaticMessage('Password'),
               'type' : 'password',
               'placeHolder' : MessageService.createStaticMessage('Password'),
               'required' : true,
            });
            groupitem134.addChild( text227 );


            var text228 = new Text({
               'resourceAttribute' : 'reason',
               'cssClass' : 'loginUsername',
               'editable' : true,
               'artifactId' : 'Platform.EsigLoginView_container_0_reason',
               'id' : 'aw6ccf562d',
               'label' : MessageService.createStaticMessage('Reason for Change'),
               'placeHolder' : MessageService.createStaticMessage('Reason for Change'),
               'required' : true,
            });
            groupitem134.addChild( text228 );


            var container090 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.EsigLoginView_footer',
               'id' : 'aw68d6d11c',
            });
            dialog030.addChild( container090 );


            var button075 = new Button({
               'artifactId' : 'Platform.EsigLoginView_Cancel_button',
               'id' : 'aw68a36a2b',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers150 = [
               {
                     'method' : 'cancelEsig',
                     'artifactId' : 'Platform.EsigLoginView_Cancel_button_eventHandlers_click_cancelEsig',
                     'id' : 'awdba9800d',
                     'event' : 'click',
                     'class' : 'platform.handlers.EsigHandler',
               }
            ];
            button075.eventHandlers = eventHandlers150;
            container090.addChild( button075 );


            var button076 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'Platform.EsigLoginView_Save_button',
               'id' : 'awef41b275',
               'label' : MessageService.createStaticMessage('OK'),
               'primary' : 'true',
            });
            var eventHandlers151 = [
               {
                     'method' : 'submitEsig',
                     'artifactId' : 'Platform.EsigLoginView_Save_button_eventHandlers_click_submitEsig',
                     'id' : 'awa9f3497f',
                     'event' : 'click',
                     'class' : 'platform.handlers.EsigHandler',
               }
            ];
            button076.eventHandlers = eventHandlers151;
            container090.addChild( button076 );

            var eventHandlers152 = [
               {
                     'method' : 'initializeEsig',
                     'artifactId' : 'Platform.EsigLoginView_eventHandlers_show_initializeEsig',
                     'id' : 'aw681e6384',
                     'event' : 'show',
                     'class' : 'platform.handlers.EsigHandler',
               }
            ];
            dialog030.eventHandlers = eventHandlers152;

            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating View: ' + 'Platform.Signature', false);
               trackTimer.startTracking();
            }

            var view043 = new View({
               'id' : 'Platform.Signature',
               'label' : MessageService.createStaticMessage('Capture Real Signature'),
            });
            ui001.addChild( view043 );

            var requiredResources042 = {
               'PlatformAttachmentInfoResource' : {
                  'artifactId' : 'Platform.Signature_PlatformAttachmentInfoResource',
                  'id' : 'aw8cc44736',
               },
            };
            view043.addRequiredResources( requiredResources042 );

            var footer009 = new Footer({
               'artifactId' : 'Platform.Signature_footer',
               'id' : 'aw16b9ee39',
            });
            view043.addChild( footer009 );


            var button077 = new Button({
               'artifactId' : 'Platform.Signature_Cancel_button',
               'id' : 'aw9088fe5b',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers153 = [
               {
                     'method' : 'cancelSignature',
                     'artifactId' : 'Platform.Signature_Cancel_button_eventHandlers_click_handleBackButtonClickEditAssetView',
                     'id' : 'awc27cd6a4',
                     'event' : 'click',
                     'class' : 'platform.signature.handler.SignatureHandler',
               }
            ];
            button077.eventHandlers = eventHandlers153;
            footer009.addChild( button077 );


            var button078 = new Button({
               'artifactId' : 'Platform.Signature_Clear_button',
               'id' : 'awc6576044',
               'label' : MessageService.createStaticMessage('Clear'),
            });
            var eventHandlers154 = [
               {
                     'method' : 'clearSignature',
                     'artifactId' : 'Platform.Signature_Clear_button_eventHandlers_click_handleBackButtonClickEditAssetView',
                     'id' : 'aw90653ab1',
                     'event' : 'click',
                     'class' : 'platform.signature.handler.SignatureHandler',
               }
            ];
            button078.eventHandlers = eventHandlers154;
            footer009.addChild( button078 );


            var button079 = new Button({
               'cssClass' : 'mblPrimaryButton',
               'artifactId' : 'Platform.Signature_Save_button',
               'id' : 'awbc1f2293',
               'label' : MessageService.createStaticMessage('Save'),
               'primary' : 'true',
            });
            var eventHandlers155 = [
               {
                     'method' : 'saveSignature',
                     'artifactId' : 'Platform.Signature_Save_button_eventHandlers_click_saveSignature',
                     'id' : 'aw7d8e432b',
                     'event' : 'click',
                     'class' : 'platform.signature.handler.SignatureHandler',
               }
            ];
            button079.eventHandlers = eventHandlers155;
            footer009.addChild( button079 );

            var eventHandlers156 = [
               {
                     'method' : 'initSignature',
                     'artifactId' : 'Platform.Signature_eventHandlers_show_initStopWorkView',
                     'id' : 'awb8cf4cb7',
                     'event' : 'initialize',
                     'class' : 'platform.signature.handler.SignatureHandler',
               }
            ];
            view043.eventHandlers = eventHandlers156;
            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }

            var dialog031 = new Dialog({
               'id' : 'Platform.SignatureDialog',
            });
            ui001.addChild( dialog031 );


            var container091 = new Container({
               'cssClass' : 'mblSimpleDialogFooter',
               'artifactId' : 'Platform.SignatureDialog_container_buttons',
               'id' : 'aw91450791',
            });
            dialog031.addChild( container091 );


            var button080 = new Button({
               'cssClass' : 'dialogButton',
               'artifactId' : 'Platform.SignatureDialog_container_buttons_Cancel_button',
               'id' : 'aw51ebe6e8',
               'label' : MessageService.createStaticMessage('Cancel'),
            });
            var eventHandlers157 = [
               {
                     'method' : 'cancelSignatureDialog',
                     'artifactId' : 'Platform.SignatureDialog_container_buttons_Cancel_button_eventHandlers_click_handleBackButtonClickEditAssetView',
                     'id' : 'aw198ca753',
                     'event' : 'click',
                     'class' : 'platform.signature.handler.SignatureHandler',
               }
            ];
            button080.eventHandlers = eventHandlers157;
            container091.addChild( button080 );


            var button081 = new Button({
               'cssClass' : 'dialogButton',
               'artifactId' : 'Platform.SignatureDialog_container_buttons_clear_button',
               'id' : 'awdc63a382',
               'label' : MessageService.createStaticMessage('Clear'),
            });
            var eventHandlers158 = [
               {
                     'method' : 'clearSignature',
                     'artifactId' : 'Platform.SignatureDialog_container_buttons_clear_button_eventHandlers_click_handleBackButtonClickEditAssetView',
                     'id' : 'aw72eacc40',
                     'event' : 'click',
                     'class' : 'platform.signature.handler.SignatureHandler',
               }
            ];
            button081.eventHandlers = eventHandlers158;
            container091.addChild( button081 );


            var button082 = new Button({
               'cssClass' : 'mblPrimaryButton dialogButton',
               'artifactId' : 'Platform.SignatureDialog_container_buttons_Save_button',
               'id' : 'awd4941650',
               'label' : MessageService.createStaticMessage('Save'),
               'primary' : 'true',
            });
            var eventHandlers159 = [
               {
                     'method' : 'saveSignature',
                     'artifactId' : 'Platform.SignatureDialog_container_buttons_Save_button_eventHandlers_click_saveSignature',
                     'id' : 'awa59c7577',
                     'event' : 'click',
                     'class' : 'platform.signature.handler.SignatureHandler',
               }
            ];
            button082.eventHandlers = eventHandlers159;
            container091.addChild( button082 );

            var eventHandlers160 = [
               {
                     'method' : 'initSignature',
                     'artifactId' : 'Platform.SignatureDialog_eventHandlers_show_initStopWorkView',
                     'id' : 'aw71e7bce4',
                     'event' : 'show',
                     'class' : 'platform.signature.handler.SignatureHandler',
               }
            ];
            dialog031.eventHandlers = eventHandlers160;
            app001.addHandler( {name : 'application.handlers.StatusChangeHandler', 'class': new StatusChangeHandler()} );
            app001.addHandler( {name : 'application.handlers.WODetailsHandler', 'class': new WODetailsHandler()} );
            app001.addHandler( {name : 'application.handlers.WOListHandler', 'class': new WOListHandler()} );
            app001.addHandler( {name : 'application.handlers.WorkLogHandler', 'class': new WorkLogHandler()} );
            app001.addHandler( {name : 'platform.handlers.AdditionalDataDialogHandler', 'class': new AdditionalDataDialogHandler()} );
            app001.addHandler( {name : 'platform.handlers.AttachmentHandler', 'class': new AttachmentHandler()} );
            app001.addHandler( {name : 'platform.handlers.ChangePasswordHandler', 'class': new ChangePasswordHandler()} );
            app001.addHandler( {name : 'platform.handlers.CreateQueryBaseHandler', 'class': new CreateQueryBaseHandler()} );
            app001.addHandler( {name : 'platform.handlers.DialogHandler', 'class': new DialogHandler()} );
            app001.addHandler( {name : 'platform.handlers.EsigHandler', 'class': new EsigHandler()} );
            app001.addHandler( {name : 'platform.handlers.LoginHandler', 'class': new LoginHandler()} );
            app001.addHandler( {name : 'platform.handlers.LookupHandler', 'class': new LookupHandler()} );
            app001.addHandler( {name : 'platform.handlers.PseudoOfflineModeHandler', 'class': new PseudoOfflineModeHandler()} );
            app001.addHandler( {name : 'platform.handlers.PushNotificationDialogHandler', 'class': new PushNotificationDialogHandler()} );
            app001.addHandler( {name : 'platform.handlers.SSOHandler', 'class': new SSOHandler()} );
            app001.addHandler( {name : 'platform.handlers.SettingsHandler', 'class': new SettingsHandler()} );
            app001.addHandler( {name : 'platform.handlers.WorkOfflineHandler', 'class': new WorkOfflineHandler()} );
            app001.addHandler( {name : 'platform.handlers._ApplicationHandlerBase', 'class': new _ApplicationHandlerBase()} );
            app001.addHandler( {name : 'platform.logging.handler.LoggerReportHandler', 'class': new LoggerReportHandler()} );
            app001.addHandler( {name : 'platform.performance.handler.TimeTrackHandler', 'class': new TimeTrackHandler()} );
            app001.addHandler( {name : 'platform.signature.handler.SignatureHandler', 'class': new SignatureHandler()} );


            if (trackTimeEnabled) {
               var trackTimer = new TrackTime('ApplicationUIBuilder', 'build', 'Creating Resources in ApplicationUIBuilder', false);
               trackTimer.startTracking();
            }
            var that001 = this;
            all([
               app001.createResource(null, null, 'PlatformDemoModeResource'),
               app001.createResource(null, null, 'LastADDownload'),
               app001.createResource(null, null, 'DeviceSizeResource'),
               app001.createResource(null, null, 'SSODialogResource'),
               app001.createResource(null, null, 'PlatformLongPressResource'),
               app001.createResource(null, null, 'PlatformDateLookupResource')
            ]).then(
               function(){
                  that001.addApplication( app001 );
               }
            );

            if (trackTimeEnabled) {
               trackTimer.stopTracking();
            }
            console.log('Finished Creating App');
         }
      });
});
