define(
//begin v1.x content
{
	"PEN_symbol": "S/."
}
//end v1.x content
);