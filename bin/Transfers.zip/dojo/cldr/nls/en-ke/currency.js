define(
//begin v1.x content
{
	"KES_symbol": "Ksh",
	"USD_symbol": "US$"
}
//end v1.x content
);