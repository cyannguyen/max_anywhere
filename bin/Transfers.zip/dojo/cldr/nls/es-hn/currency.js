define(
//begin v1.x content
{
	"HNL_symbol": "L"
}
//end v1.x content
);