define(
//begin v1.x content
{
	"BOB_symbol": "Bs"
}
//end v1.x content
);