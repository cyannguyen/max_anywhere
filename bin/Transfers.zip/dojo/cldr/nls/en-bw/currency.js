define(
//begin v1.x content
{
	"BWP_symbol": "P",
	"USD_symbol": "US$"
}
//end v1.x content
);