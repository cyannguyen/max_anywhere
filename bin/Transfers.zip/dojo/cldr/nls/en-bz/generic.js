define(
//begin v1.x content
{
	"dateFormat-medium": "dd-MMM-y G",
	"dateFormatItem-yMMMEd": "E dd MMM y",
	"dateFormatItem-yMMMd": "dd MMM y",
	"dateFormatItem-MMMd": "dd MMM",
	"dateFormatItem-MMMEd": "E dd MMM"
}
//end v1.x content
);