define(
//begin v1.x content
{
	"GBP_displayName": "Libra esterlina britânica",
	"CAD_displayName": "Dólar canadiano",
	"USD_displayName": "Dólar dos Estados Unidos"
}
//end v1.x content
);