define(
//begin v1.x content
{
	"dayPeriods-format-abbr-pm": "pm",
	"timeFormat-full": "HH:mm:ss zzzz",
	"timeFormat-medium": "HH:mm:ss",
	"dateFormatItem-MEd": "E dd/MM",
	"dayPeriods-standAlone-wide-am": "am",
	"dayPeriods-standAlone-wide-pm": "pm",
	"dayPeriods-standAlone-abbr-am": "am",
	"dayPeriods-format-wide-am": "am",
	"timeFormat-long": "HH:mm:ss z",
	"timeFormat-short": "HH:mm",
	"dayPeriods-standAlone-abbr-pm": "pm",
	"dayPeriods-format-wide-pm": "pm",
	"dayPeriods-format-abbr-am": "am",
	"dateFormatItem-MMMEd": "E d MMM"
}
//end v1.x content
);