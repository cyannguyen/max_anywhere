define(
//begin v1.x content
{
	"dateFormat-short": "d/M/yy GGGGG",
	"dateFormat-medium": "d MMM, y G",
	"dateFormat-long": "d MMMM, y G",
	"dateFormat-full": "EEEE, d MMMM, y G",
	"dateFormatItem-MMMEd": "E, d MMM"
}
//end v1.x content
);