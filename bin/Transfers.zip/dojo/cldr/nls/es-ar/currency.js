define(
//begin v1.x content
{
	"ARS_symbol": "$"
}
//end v1.x content
);