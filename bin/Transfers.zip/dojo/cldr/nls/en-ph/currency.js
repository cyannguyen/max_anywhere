define(
//begin v1.x content
{
	"PHP_symbol": "₱",
	"PHP_displayName": "Peso",
	"USD_symbol": "US$"
}
//end v1.x content
);