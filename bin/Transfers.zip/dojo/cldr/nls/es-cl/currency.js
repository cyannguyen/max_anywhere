define(
//begin v1.x content
{
	"CLP_symbol": "$"
}
//end v1.x content
);