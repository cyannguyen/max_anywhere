define(
//begin v1.x content
{
	"HKD_displayName": "hongkonški dolar",
	"CNY_displayName": "kineski yuan",
	"JPY_displayName": "japanski jen",
	"JPY_symbol": "JPY",
	"USD_displayName": "američki dolar",
	"CAD_symbol": "CAD",
	"GBP_displayName": "britanska funta",
	"CHF_displayName": "švicarski franak",
	"CNY_symbol": "CNY",
	"EUR_displayName": "euro",
	"GBP_symbol": "GBP",
	"CAD_displayName": "kanadski dolar",
	"USD_symbol": "USD",
	"EUR_symbol": "EUR",
	"AUD_displayName": "australski dolar",
	"CHF_symbol": "CHF",
	"HKD_symbol": "HKD",
	"AUD_symbol": "AUD"
}
//end v1.x content
);