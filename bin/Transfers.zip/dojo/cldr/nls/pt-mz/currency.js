define(
//begin v1.x content
{
	"MZN_symbol": "MTn"
}
//end v1.x content
);