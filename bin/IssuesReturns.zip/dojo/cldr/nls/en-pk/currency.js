define(
//begin v1.x content
{
	"PKR_symbol": "Rs",
	"USD_symbol": "US$"
}
//end v1.x content
);