define(
//begin v1.x content
{
	"CUP_symbol": "$"
}
//end v1.x content
);