define(
//begin v1.x content
{
	"PHP_symbol": "₱"
}
//end v1.x content
);