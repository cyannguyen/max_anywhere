define(
//begin v1.x content
{
	"USD_symbol": "$"
}
//end v1.x content
);