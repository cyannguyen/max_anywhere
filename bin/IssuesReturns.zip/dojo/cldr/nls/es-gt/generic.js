define(
//begin v1.x content
{
	"dateFormat-medium": "d/MM/y G",
	"dateFormat-short": "d/MM/yy GGGGG"
}
//end v1.x content
);