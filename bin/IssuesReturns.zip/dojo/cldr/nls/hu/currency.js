define(
//begin v1.x content
{
	"HKD_displayName": "hongkongi dollár",
	"CNY_displayName": "kínai jüan",
	"JPY_displayName": "japán jen",
	"JPY_symbol": "¥",
	"USD_displayName": "USA-dollár",
	"CAD_symbol": "CAD",
	"GBP_displayName": "brit font",
	"CHF_displayName": "svájci frank",
	"CNY_symbol": "CNY",
	"EUR_displayName": "euró",
	"GBP_symbol": "GBP",
	"CAD_displayName": "kanadai dollár",
	"USD_symbol": "USD",
	"EUR_symbol": "EUR",
	"AUD_displayName": "ausztrál dollár",
	"CHF_symbol": "CHF",
	"HKD_symbol": "HKD",
	"AUD_symbol": "AUD"
}
//end v1.x content
);