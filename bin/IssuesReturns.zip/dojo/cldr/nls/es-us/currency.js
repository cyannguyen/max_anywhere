define(
//begin v1.x content
{
	"JPY_symbol": "¥",
	"USD_symbol": "$"
}
//end v1.x content
);