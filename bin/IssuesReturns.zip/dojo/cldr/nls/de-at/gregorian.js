define(
//begin v1.x content
{
	"months-format-abbr": [
		"Jän",
		"Februar",
		"März",
		"April",
		"Mai",
		"Juni",
		"Juli",
		"August",
		"September",
		"Oktober",
		"November",
		"Dezember"
	],
	"months-format-wide": [
		"Jänner",
		"Februar",
		"März",
		"April",
		"Mai",
		"Juni",
		"Juli",
		"August",
		"September",
		"Oktober",
		"November",
		"Dezember"
	],
	"dateFormat-long": "dd. MMMM y",
	"months-standAlone-abbr": [
		"Jän",
		"Februar",
		"März",
		"April",
		"Mai",
		"Juni",
		"Juli",
		"August",
		"September",
		"Oktober",
		"November",
		"Dezember"
	],
	"months-standAlone-wide": [
		"Jänner",
		"Februar",
		"März",
		"April",
		"Mai",
		"Juni",
		"Juli",
		"August",
		"September",
		"Oktober",
		"November",
		"Dezember"
	],
	"dateFormat-full": "EEEE, dd. MMMM y"
}
//end v1.x content
);