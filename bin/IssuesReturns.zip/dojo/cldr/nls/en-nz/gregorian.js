define(
//begin v1.x content
{
	"dateFormatItem-Md": "d/M",
	"timeFormat-full": "h:mm:ss a zzzz",
	"timeFormat-medium": "h:mm:ss a",
	"dateFormat-medium": "d/MM/y",
	"dateFormatItem-yMd": "d/MM/y",
	"dateFormat-full": "EEEE, d MMMM y",
	"timeFormat-long": "h:mm:ss a z",
	"timeFormat-short": "h:mm a",
	"dateFormat-short": "d/MM/yy",
	"dateFormat-long": "d MMMM y",
	"dateFormatItem-MMMEd": "E, d MMM"
}
//end v1.x content
);