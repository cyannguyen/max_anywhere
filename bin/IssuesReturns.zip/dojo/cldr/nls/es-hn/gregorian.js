define(
//begin v1.x content
{
	"dateFormat-long": "dd 'de' MMMM 'de' y",
	"dateFormat-full": "EEEE dd 'de' MMMM 'de' y"
}
//end v1.x content
);