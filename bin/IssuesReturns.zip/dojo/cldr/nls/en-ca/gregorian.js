define(
//begin v1.x content
{
	"dateFormatItem-yMMMEd": "E, MMM d, y",
	"dateFormatItem-Md": "d/M",
	"dateFormatItem-GyMMMEd": "E, MMM d, y G",
	"dateFormatItem-yMEd": "E, d/M/y",
	"dateFormatItem-MEd": "E, d/M",
	"dateFormatItem-yM": "M/y",
	"dateFormat-medium": "MMM d, y",
	"dateFormatItem-MMdd": "dd/MM",
	"dateFormatItem-MMMd": "MMM d",
	"dateFormatItem-yMd": "d/M/y",
	"dateFormat-full": "EEEE, MMMM d, y",
	"dateFormatItem-yMMMd": "MMM d, y",
	"dateFormat-short": "d/M/yy",
	"dateFormatItem-MMMMd": "MMMM d",
	"dateFormatItem-GyMMMd": "MMM d, y G",
	"dateFormat-long": "MMMM d, y",
	"dateFormatItem-MMMEd": "E, MMM d"
}
//end v1.x content
);