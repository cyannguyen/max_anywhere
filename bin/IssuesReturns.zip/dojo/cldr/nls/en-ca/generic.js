define(
//begin v1.x content
{
	"dateFormatItem-Md": "d/M",
	"dateFormatItem-GyMMMEd": "E, MMM d, y G",
	"dateFormatItem-yyyyMEd": "E, d/M/y GGGGG",
	"dateFormatItem-yyyyMMMd": "MMM d, y G",
	"dateFormatItem-Ed": "d E",
	"dateFormatItem-MEd": "E, d/M",
	"dateFormat-medium": "MMM d, y G",
	"dateFormatItem-MMMd": "MMM d",
	"dateFormatItem-yyyyMd": "d/M/y GGGGG",
	"dateFormat-full": "EEEE, MMMM d, y G",
	"dateFormat-short": "d/M/y GGGGG",
	"dateFormatItem-yyyyM": "M/y GGGGG",
	"dateFormatItem-GyMMMd": "MMM d, y G",
	"dateFormatItem-yyyyMMMEd": "E, MMM d, y G",
	"dateFormat-long": "MMMM d, y G",
	"dateFormatItem-MMMEd": "E, MMM d"
}
//end v1.x content
);