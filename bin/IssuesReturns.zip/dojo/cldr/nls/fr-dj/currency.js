define(
//begin v1.x content
{
	"DJF_symbol": "Fdj"
}
//end v1.x content
);