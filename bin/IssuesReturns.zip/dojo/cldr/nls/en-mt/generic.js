define(
//begin v1.x content
{
	"dateFormat-short": "dd/MM/y GGGGG",
	"dateFormat-medium": "dd MMM y G",
	"dateFormatItem-yMMMEd": "E, dd MMM y",
	"dateFormat-long": "dd MMMM y G",
	"dateFormatItem-yMMMd": "dd MMM y",
	"dateFormatItem-MMMd": "dd MMM",
	"dateFormat-full": "EEEE, d MMMM y G",
	"dateFormatItem-MMMEd": "E, d MMM"
}
//end v1.x content
);