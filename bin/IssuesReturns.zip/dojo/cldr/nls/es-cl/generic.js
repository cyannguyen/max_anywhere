define(
//begin v1.x content
{
	"dateFormatItem-Md": "dd-MM",
	"dateFormatItem-yMEd": "E dd-MM-y",
	"timeFormat-medium": "H:mm:ss",
	"dateFormatItem-MEd": "E, dd-MM",
	"dateFormatItem-yM": "MM-y",
	"dateFormat-medium": "dd-MM-y G",
	"dateFormatItem-yMd": "dd-MM-y",
	"timeFormat-long": "H:mm:ss z",
	"timeFormat-short": "H:mm",
	"dateFormat-short": "dd-MM-yy GGGGG"
}
//end v1.x content
);