define(
//begin v1.x content
{
	"dateFormatItem-yMMMEd": "E, dd MMM y",
	"dateFormatItem-Md": "MM/dd",
	"dateFormatItem-yMEd": "E, y/MM/dd",
	"dateFormatItem-MEd": "E MM/dd",
	"dateFormat-medium": "dd MMM y G",
	"dateFormatItem-MMMd": "dd MMM",
	"dateFormatItem-yMd": "y/MM/dd",
	"dateFormat-full": "EEEE dd MMMM y G",
	"dateFormatItem-yMMMd": "dd MMM y",
	"dateFormat-short": "GGGGG y/MM/dd",
	"dateFormat-long": "dd MMMM y G",
	"dateFormatItem-MMMEd": "E dd MMM"
}
//end v1.x content
);