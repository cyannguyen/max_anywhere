define(
//begin v1.x content
{
	"field-month-relative+0": "Este mes",
	"field-year-relative+0": "Este año",
	"field-week-relative+-1": "Semana pasada",
	"field-month-relative+1": "Mes próximo",
	"field-year-relative+1": "Año próximo",
	"field-week-relative+0": "Esta semana",
	"field-week-relative+1": "Próxima semana",
	"dateFormatItem-yMEd": "E d/M/y G",
	"field-month-relative+-1": "El mes pasado",
	"field-year-relative+-1": "Año pasado"
}
//end v1.x content
);