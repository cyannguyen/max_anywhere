define(
//begin v1.x content
{
	"dateFormatItem-yMMMEd": "E, dd MMM, y",
	"dateFormatItem-Md": "d/M",
	"dateFormatItem-yMEd": "E, d/M/y",
	"dateFormatItem-MEd": "E d/M",
	"dateFormat-medium": "dd MMM,y",
	"dateFormatItem-MMMd": "dd MMM",
	"dateFormatItem-yMd": "d/M/y",
	"dateFormat-full": "EEEE dd MMMM y",
	"dateFormatItem-yMMMd": "dd MMM, y",
	"dateFormat-short": "d/M/y",
	"dateFormat-long": "dd MMMM y",
	"dateFormatItem-MMMEd": "E dd MMM"
}
//end v1.x content
);