define(
//begin v1.x content
{
	"dateFormatItem-yMEd": "E, dd/MM/y",
	"dateFormatItem-yMd": "dd/MM/y",
	"field-hour-short": "h"
}
//end v1.x content
);