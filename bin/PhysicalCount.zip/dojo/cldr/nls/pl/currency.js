define(
//begin v1.x content
{
	"HKD_displayName": "dolar hongkoński",
	"CNY_displayName": "juan chiński",
	"JPY_displayName": "jen japoński",
	"JPY_symbol": "JPY",
	"USD_displayName": "dolar amerykański",
	"CAD_symbol": "CAD",
	"GBP_displayName": "funt szterling",
	"CHF_displayName": "frank szwajcarski",
	"CNY_symbol": "CNY",
	"EUR_displayName": "euro",
	"GBP_symbol": "GBP",
	"CAD_displayName": "dolar kanadyjski",
	"USD_symbol": "USD",
	"EUR_symbol": "€",
	"AUD_displayName": "dolar australijski",
	"CHF_symbol": "CHF",
	"HKD_symbol": "HKD",
	"AUD_symbol": "AUD"
}
//end v1.x content
);