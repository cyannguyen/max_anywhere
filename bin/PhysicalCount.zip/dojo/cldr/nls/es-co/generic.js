define(
//begin v1.x content
{
	"dateFormat-short": "d/MM/yy GGGGG",
	"timeFormat-long": "H:mm:ss z",
	"dateFormat-medium": "d/MM/y G",
	"timeFormat-medium": "H:mm:ss",
	"timeFormat-short": "H:mm"
}
//end v1.x content
);