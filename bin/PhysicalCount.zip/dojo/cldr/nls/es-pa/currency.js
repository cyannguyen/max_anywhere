define(
//begin v1.x content
{
	"PAB_symbol": "B/."
}
//end v1.x content
);