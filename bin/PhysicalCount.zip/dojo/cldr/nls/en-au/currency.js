define(
//begin v1.x content
{
	"USD_symbol": "USD",
	"CAD_symbol": "CAD",
	"GBP_symbol": "GBP",
	"HKD_symbol": "HKD",
	"JPY_symbol": "JPY",
	"AUD_symbol": "$",
	"CNY_symbol": "CNY",
	"EUR_symbol": "EUR"
}
//end v1.x content
);