define(
//begin v1.x content
{
	"RWF_symbol": "RF"
}
//end v1.x content
);