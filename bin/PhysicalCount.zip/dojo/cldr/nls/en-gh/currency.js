define(
//begin v1.x content
{
	"GHS_symbol": "GH₵",
	"USD_symbol": "US$"
}
//end v1.x content
);