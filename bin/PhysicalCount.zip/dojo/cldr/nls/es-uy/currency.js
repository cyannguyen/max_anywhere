define(
//begin v1.x content
{
	"UYU_symbol": "$"
}
//end v1.x content
);