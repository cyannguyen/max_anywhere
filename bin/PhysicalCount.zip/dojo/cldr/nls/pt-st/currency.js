define(
//begin v1.x content
{
	"STD_symbol": "Db"
}
//end v1.x content
);