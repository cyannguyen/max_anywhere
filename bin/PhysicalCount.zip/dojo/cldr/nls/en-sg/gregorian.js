define(
//begin v1.x content
{
	"timeFormat-full": "h:mm:ss a zzzz",
	"timeFormat-medium": "h:mm:ss a",
	"dateFormat-medium": "d MMM, y",
	"dateFormat-full": "EEEE, d MMMM, y",
	"timeFormat-long": "h:mm:ss a z",
	"timeFormat-short": "h:mm a",
	"dateFormat-short": "d/M/yy",
	"dateFormat-long": "d MMMM, y",
	"dateFormatItem-MMMEd": "E, d MMM"
}
//end v1.x content
);