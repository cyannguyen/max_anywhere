define(
//begin v1.x content
{
	"dateFormat-medium": "d-MMM-y G",
	"dateFormat-short": "d/MM/yy GGGGG"
}
//end v1.x content
);