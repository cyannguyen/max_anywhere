define(
//begin v1.x content
{
	"GYD_symbol": "$",
	"USD_symbol": "US$"
}
//end v1.x content
);