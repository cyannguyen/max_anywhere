define(
//begin v1.x content
{
	"TOP_symbol": "T$",
	"USD_symbol": "US$"
}
//end v1.x content
);