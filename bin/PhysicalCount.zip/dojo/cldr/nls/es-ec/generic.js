define(
//begin v1.x content
{
	"timeFormat-medium": "H:mm:ss",
	"timeFormat-short": "H:mm",
	"timeFormat-long": "H:mm:ss z"
}
//end v1.x content
);