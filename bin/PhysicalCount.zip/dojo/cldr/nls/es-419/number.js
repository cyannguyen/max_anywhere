define(
//begin v1.x content
{
	"group": ",",
	"currencyFormat": "¤#,##0.00",
	"decimalFormat-short": "000 B",
	"decimal": "."
}
//end v1.x content
);