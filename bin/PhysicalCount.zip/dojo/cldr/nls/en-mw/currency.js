define(
//begin v1.x content
{
	"MWK_symbol": "MK",
	"USD_symbol": "US$"
}
//end v1.x content
);