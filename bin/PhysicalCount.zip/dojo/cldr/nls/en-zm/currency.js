define(
//begin v1.x content
{
	"ZMK_symbol": "K",
	"ZMW_symbol": "KR",
	"USD_symbol": "US$"
}
//end v1.x content
);