define(
//begin v1.x content
{
	"dateFormatItem-yMMMEd": "E, dd MMM, y",
	"dateFormatItem-Md": "d/M",
	"dateFormatItem-yMEd": "E, d/M/y",
	"dateFormatItem-MEd": "E d/M",
	"dateFormat-medium": "dd MMM,y G",
	"dateFormatItem-MMMd": "dd MMM",
	"dateFormatItem-yMd": "d/M/y",
	"dateFormat-full": "EEEE dd MMMM y G",
	"dateFormatItem-yMMMd": "dd MMM, y",
	"dateFormat-short": "d/M/y GGGGG",
	"dateFormat-long": "dd MMMM y G",
	"dateFormatItem-MMMEd": "E dd MMM"
}
//end v1.x content
);