define(
//begin v1.x content
{
	"CDF_symbol": "FC"
}
//end v1.x content
);