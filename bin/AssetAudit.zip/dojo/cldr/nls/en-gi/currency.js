define(
//begin v1.x content
{
	"GBP_symbol": "GB£",
	"GIP_symbol": "£",
	"USD_symbol": "US$"
}
//end v1.x content
);