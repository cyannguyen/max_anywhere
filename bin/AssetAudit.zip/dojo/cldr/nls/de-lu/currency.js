define(
//begin v1.x content
{
	"LUF_symbol": "F",
	"LUF_decimal": ".",
	"LUF_group": ","
}
//end v1.x content
);