define(
//begin v1.x content
{
	"dateFormatItem-yMMMEd": "E dd MMM y",
	"dateFormatItem-Md": "dd/MM",
	"dateFormatItem-yMEd": "E, dd/MM/y",
	"dateFormatItem-MEd": "E dd/MM",
	"dateFormatItem-yM": "MM/y",
	"dateFormatItem-MMMd": "dd MMM",
	"dateFormatItem-yMd": "dd/MM/y",
	"dateFormat-full": "EEEE dd MMMM y",
	"dateFormatItem-yMMMd": "dd MMM y",
	"dateFormat-short": "dd/MM/yy",
	"dateFormat-long": "dd MMMM y",
	"dateFormatItem-MMMEd": "E dd MMM"
}
//end v1.x content
);