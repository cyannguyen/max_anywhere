define(
//begin v1.x content
{
	"dateFormat-long": "dd. MMMM y G",
	"dateFormat-full": "EEEE, dd. MMMM y G"
}
//end v1.x content
);