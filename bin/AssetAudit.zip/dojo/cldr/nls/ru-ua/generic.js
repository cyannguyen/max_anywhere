define(
//begin v1.x content
{
	"dateFormat-medium": "d MMM y G",
	"timeFormat-long": "HH:mm:ss z",
	"dateFormat-long": "d MMMM y G",
	"timeFormat-medium": "HH:mm:ss",
	"timeFormat-short": "HH:mm",
	"timeFormat-full": "HH:mm:ss zzzz"
}
//end v1.x content
);