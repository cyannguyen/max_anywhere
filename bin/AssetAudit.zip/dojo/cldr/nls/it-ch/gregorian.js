define(
//begin v1.x content
{
	"dateFormat-short": "dd.MM.yy",
	"dateFormat-medium": "d-MMM-y",
	"dateFormat-long": "d MMMM y",
	"timeFormat-full": "HH.mm:ss 'h' zzzz",
	"dateFormat-full": "EEEE, d MMMM y"
}
//end v1.x content
);