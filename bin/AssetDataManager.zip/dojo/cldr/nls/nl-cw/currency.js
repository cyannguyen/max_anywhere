define(
//begin v1.x content
{
	"ANG_symbol": "NAf."
}
//end v1.x content
);