define(
//begin v1.x content
{
	"AOA_symbol": "Kz"
}
//end v1.x content
);