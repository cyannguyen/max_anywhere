define(
//begin v1.x content
{
	"dateFormat-short": "dd/MM/y",
	"dateFormat-medium": "dd MMM y",
	"dateFormatItem-yMMMEd": "E, dd MMM y",
	"dateFormat-long": "dd MMMM y",
	"dateFormatItem-yMMMd": "dd MMM y",
	"dateFormatItem-MMMd": "dd MMM",
	"dateFormat-full": "EEEE, d MMMM y",
	"dateFormatItem-MMMEd": "E, d MMM"
}
//end v1.x content
);