define(
//begin v1.x content
{
	"decimalFormat": "#0.######",
	"infinity": "INF",
	"scientificFormat": "0.000000E+000",
	"perMille": "0/00",
	"percentFormat": "#0%",
	"currencyFormat": "¤ #0.00"
}
//end v1.x content
);