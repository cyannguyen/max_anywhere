define(
//begin v1.x content
{
	"dateFormat-medium": "d-MMM-y",
	"dateFormat-short": "d/MM/yy"
}
//end v1.x content
);