define(
//begin v1.x content
{
	"GNF_symbol": "FG"
}
//end v1.x content
);