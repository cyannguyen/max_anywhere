define(
//begin v1.x content
{
	"HKD_symbol": "$",
	"USD_symbol": "US$"
}
//end v1.x content
);