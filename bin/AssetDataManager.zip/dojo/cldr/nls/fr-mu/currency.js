define(
//begin v1.x content
{
	"MUR_symbol": "Rs"
}
//end v1.x content
);