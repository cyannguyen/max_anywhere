define(
//begin v1.x content
{
	"BYR_symbol": "р.",
	"RUR_symbol": "RUR"
}
//end v1.x content
);