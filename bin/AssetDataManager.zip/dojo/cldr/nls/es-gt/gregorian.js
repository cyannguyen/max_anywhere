define(
//begin v1.x content
{
	"dateFormat-medium": "d/MM/y",
	"dateFormat-short": "d/MM/yy"
}
//end v1.x content
);