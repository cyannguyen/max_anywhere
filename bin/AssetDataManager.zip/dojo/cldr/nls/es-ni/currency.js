define(
//begin v1.x content
{
	"NIO_symbol": "C$"
}
//end v1.x content
);