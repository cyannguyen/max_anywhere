define(
//begin v1.x content
{
	"decimalFormat": "#,##,##0.###",
	"currencyFormat": "¤ #,##,##0.00",
	"percentFormat": "#,##,##0%"
}
//end v1.x content
);