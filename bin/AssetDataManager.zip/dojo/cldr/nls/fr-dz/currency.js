define(
//begin v1.x content
{
	"DZD_symbol": "DA"
}
//end v1.x content
);