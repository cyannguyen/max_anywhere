define(
//begin v1.x content
{
	"KMF_symbol": "CF"
}
//end v1.x content
);