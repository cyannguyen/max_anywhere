define(
//begin v1.x content
{
	"USD_symbol": "US$",
	"VUV_symbol": "VT"
}
//end v1.x content
);