//>>built
define("dijit/nls/ar/loading",({loadingState:"جاري التحميل...",errorState:"عفوا، حدث خطأ"}));