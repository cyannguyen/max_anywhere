/*
 * Licensed Materials - Property of IBM
 * "Restricted Materials of IBM"
 *
 * 5725-M39
 *
 * (C) COPYRIGHT IBM CORP. 2013,2020 All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with
 * IBM Corp. 
 *
 */

define( "platform/translation/Message", 
		[ "dojo/_base/declare"
		     ],
	function(declare, i18n, Messages) {
		
	return  declare("platform.translation.Message",null, {
			//need to get label bundle through dojo stuff
			
			textMsg: ''			
		
		});
		
		
			
	});
